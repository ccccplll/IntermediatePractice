<template>
  <view class="container">
	<input v-model="id" type="text" placeholder="请输入用户名" />
	<input v-model="email" type="text" placeholder="请输入邮箱"/> 
	<input v-model="password" type="password" placeholder="请输入密码" />
	
	<button @click="submit">提交</button>
	  
	
    <button @click="insert">插入数据</button>
    <button @click="select1">固有查询</button>
    <button @click="select2">自定义查询</button>
	<button @click="select3">数据库查询</button>
    <h1></h1>
    <textarea>{{ result }}</textarea>
  </view>
</template>

<script>
export default {
  data() {
    return {
      result: '',
	  id: '',
	  email: '',
	  password: '',	
    };
  },
  methods: {
	submit() {
		uni.request({
		  url: 'http://localhost:3000/',
		  method: 'GET',
		  data: {
			id: this.id,
			email: this.email,
			password: this.password
		  },
		  success: (res) => {
		  	console.log('数据插入成功',res.data);
		  },
		  fail: (err) => {
		  	console.error('插入数据失败',err);
		  }
		})
	},
    insert() {
      uni.request({
        url: 'http://localhost:8081/insert',
        method: 'GET',
        data: {
          name: 'dwx',
          age: 17
        },
        success: (res) => {
          this.result = JSON.stringify(res.data);
        },
        fail: (err) => {
          uni.showToast({
            title: '请求失败',
            icon: 'none'
          });
          console.error(err);
        }
      });
    },
    select1() {
      uni.request({
        url: 'http://localhost:8081/select1',
        method: 'GET',
        success: (res) => {
          this.result = JSON.stringify(res.data);
        },
        fail: (err) => {
          uni.showToast({
            title: '请求失败',
            icon: 'none'
          });
          console.error(err);
        }
      });
    },
    select2() {
      uni.request({
        url: 'http://localhost:8081/select2',
        method: 'GET',
        success: (res) => {
          this.result = JSON.stringify(res.data);
        },
        fail: (err) => {
          uni.showToast({
            title: '请求失败',
            icon: 'none'
          });
          console.error(err);
        }
      });
    },
	select3(){
		uni.request({
			url: 'http://localhost:3000/',
			method:'GET',
			success: (res) => {
				this.result = JSON.stringify(res.data);
			},
			fail: (err) => {
				uni.showToast({
					title:'请求失败',
					icon:'none'
				});
				console.error(err);
			}
		});
	}
  }
};
</script>

<style scoped>
.container {
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-top: 20px;
}
textarea {
  width: 80%;
  height: 200px;
  margin-top: 20px;
}
button {
  margin: 10px;
}
</style>

