var mysql = require('mysql');
var connection = mysql.createConnection({
    host: '192.168.184.237', //host地址
    port:3306, //端口号
    user: 'user2', //连接数据库时的账号
    password: '1234',//连接数据库时的密码
    database: 'weheart_db' //需要连接的数据库
});
module.exports = connection;