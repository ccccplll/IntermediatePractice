var express = require('express');
const connection = require('../database/sql');
var router = express.Router();

/* POST insert data */
router.get("/", function(req, res, next) {
    connection.query("SELECT * FROM administrator", function(error, results, fields) {
        if (error) throw error;
       console.log('The solution is: ', results);
        res.send(results)
    });
 
});

module.exports = router;
