<template>  
  <view class="avatar">  
    <!-- 触发选择图片 -->  
    <button @click="chooseImage">选择图片</button>  
    <!-- 显示图片 -->  
    <image v-if="localImagePath" :src="localImagePath" mode="aspectFill"></image>  
	<button @click="ensure">确认</button>
  </view>  
</template>  
  
<script>  
export default {    
  data() {    
    return {    
      localImagePath: '' // 存储图片的本地路径    
    };    
  },    
  methods: {    
    chooseImage() {    
      uni.chooseImage({    
        count: 1, // 默认9，设置为1代表只选择一张图片    
        sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有    
        sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有    
        success: (res) => {    
          // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片    
          this.localImagePath = res.tempFilePaths[0];  
  
          // 在成功选择图片后，保存图片  
          const fs = uni.getFileSystemManager();  
          const newFilePath = `${uni.env.USER_DATA_PATH}/mySavedImage.jpg`; // 正确使用模板字符串  
  
          fs.saveFile({  
            tempFilePath: res.tempFilePaths[0], // 使用从 res.tempFilePaths 中获取的 tempFilePath  
            filePath: newFilePath,  
            success: function(res) {  
              console.log(res.savedFilePath);  
            },  
            fail: function(err) {  
              console.log(err);  
            }  
          });  
        }    
      });    
    },
	ensure(){
	//console.log(getApp().globalData.path);
	const app = getApp();  
	if (this.localImagePath) {  
		app.globalData.path = this.localImagePath;  
		//console.log(app.globalData.path);    
	// 切换到 tab 页面  
	uni.switchTab({  
		url: "/pages/mine/mine"  
	});  
	} else {  
		console.error('localImagePath is undefined or null');  
	}  
	}
  }    
};
</script> 
  
<style>  
.avatar {  
  display: flex;  
  flex-direction: column;  
  align-items: center;  
  justify-content: center;  
  height: 100vh;  
  padding: 20rpx; 
}  

</style>