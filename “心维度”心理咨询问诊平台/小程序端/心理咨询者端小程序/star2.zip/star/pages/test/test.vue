<template>
	<view class="test">
		<view v-for="(questionn,index) in question" :key="index">
			<label class="t1">{{formatText(questionn.text)}}</label>
			<radio-group @change="radioChange(index, $event.detail.value)">
			  <label class="radio-label" v-for="(optionn,optionIndex) in questionn.option" :key="optionIndex">  
			    <radio :value="optionn.value" :checked="questionn.selected == optionn.value" /> {{optionn.value}} {{optionn.label}}
			  </label>  
			</radio-group>
		</view>
		<button class="submit" @click="submit">交卷</button>
	</view>
</template>

<script>
	export default {
		onLoad() {
			let name = getApp().globalData.userName;
			//const name = encodeURIComponent(this.formData.name); // 对 name 进行 URL 编码
			uni.request({
				url:'http://localhost:3000/selectInfor?name='+encodeURIComponent(name),
				method:'GET',
				success: (res) => {
					console.log(res.data[0]);
					if(res.data){
						this.id = res.data[0].id;
						console.log(this.id);
						//console.log('传递成功', res.data);
					}  else{
						console.log('没有接收到数据');
					}
				},
				fail: (err) => {
					console.error('传递失败', err); 
				}
			});
			this.fetchAllQuestions();
		},
		data() {
			return {
				totalScore: 0,
				condition:'',
				id:'',
				question: [],
				aScore: [],
				bScore: [],
				cScore: [],
				dScore: [],
			};
		},
		methods: {
			async fetchAllQuestions() {
				for (let i = 0; i < 20; i++) {
					try {
						const res = await uni.request({
							url: 'http://localhost:3000/getABCD',
							method: 'GET',
							data: { index: i+1 },
						});
						if (res.statusCode === 200) {
							const newQuestion = {
								text: res.data[0].question_context,
								option: [
									{ value: 'A', label: res.data[0].A },
									{ value: 'B', label: res.data[0].B },
									{ value: 'C', label: res.data[0].C },
									{ value: 'D', label: res.data[0].D },
								],
								selected: '',
							};
							this.question.push(newQuestion);
							this.aScore.push(res.data[0].score_a);
							this.bScore.push(res.data[0].score_b);
							this.cScore.push(res.data[0].score_c);
							this.dScore.push(res.data[0].score_d);
							this.index++;
						} else {
							console.error('Failed to fetch question:', res.statusCode);
						}
					} catch (error) {
						console.error('Error fetching question:', error);
					}
				}
			},
			radioChange(questionIndex, newValue) {
				this.question[questionIndex].selected = newValue;
			},
			async submit() {
				this.totalScore = 0;
				for (let i = 0; i < this.question.length; i++) {
					switch (this.question[i].selected) {
						case 'A':
							this.totalScore += this.aScore[i];
							break;
						case 'B':
							this.totalScore += this.bScore[i];
							break;
						case 'C':
							this.totalScore += this.cScore[i];
							break;
						case 'D':
							this.totalScore += this.dScore[i];
							break;
						default:
							this.totalScore += 0;
					}
				}
				if(this.totalScore >= 90){
				    this.condition = "优秀";
				}else if(this.totalScore >= 80){
				    this.condition = "良好";
				}else if(this.totalScore >= 60){
				    this.condition = "一般";
				}else{
				    this.condition = "差";
				}

					
				const now = new Date();
				const submitTime = this.formatDate(now);
				console.log(this.totalScore, submitTime);
				try {
					const res = await uni.request({
						url: 'http://localhost:3000/submitTest',
						method: 'POST',
						data: {
							u_id:this.id,
							score: this.totalScore,
							t_condition:this.condition,
							time: submitTime,
						},
					});
					if (res.statusCode === 200) {
						console.log('Submission successful:', res.data);
					} else {
						console.error('Submission failed:', res.statusCode);
					}
				} catch (error) {
					console.error('Error during submission:', error);
				}
				// 返回上一个界面
				uni.navigateBack({
					delta: 1 // 返回的页面数，1表示返回上一级页面，可以根据需要调整
				}); 
			},
			formatText(text) {
				return text.replace(/\n/g, ''); // 去掉换行符
			},
			formatDate(date) {
				const pad = (n) => n < 10 ? '0' + n : n;
				return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())} ${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
			},
		}
	}
</script>

<style lang="scss">
.test {
	margin-bottom: 20px;
	display: flex;
	flex-direction: column;
	align-items: flex-start;
	justify-content: first baseline;
	radio-group {
		display: flex;
		flex-direction: column;
		align-items: flex-start;
		justify-content: space-between;
	}
}
.t1 {
	width: 100vw;
	display: block;
	margin-bottom: 5px;
	text-align: left;
}

.radio-label {
	display: flex;
	align-items: center;
	margin-bottom: 10px;
}
</style>
