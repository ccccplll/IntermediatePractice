<template>  
  <view class="container">  
    <view class="title">心维度</view>  
    <view class="subtitle">申请咨询师</view>  
    <view class="steps">  
      <view class="step">  
        <image class="step-icon" src="/static/images/link-icon.png" alt="申请咨询师图标"></image>  
        <view class="step-text">申请咨询师</view>  
      </view>  
      <view class="step">  
        <image class="step-icon" src="/static/images/phone-icon.png" alt="绑定手机图标"></image>  
        <view class="step-text">绑定手机</view>  
      </view>  
      <view class="step">  
        <image class="step-icon" src="/static/images/form-icon.png" alt="填写资料图标"></image>  
        <view class="step-text">填写资料</view>  
      </view>  
      <!-- 假设提交审核没有单独的图标，则不显示 -->  
    </view>  
    <button class="apply-button" open-type="default">我要申请成为咨询师</button>  
  </view>  
</template>  
  
<script setup>
	
</script>
  
<style>  
  .container {  
    padding: 20px;  
    background-color: #E0E0E0; /* 假设背景色为浅灰色 */  
  }  
  .title {  
    font-size: 20px;  
    color: #000000; /* 标题颜色为黑色 */  
    margin-bottom: 10px;  
    text-align: center; /* 标题居中显示 */  
  }  
  .subtitle {  
    font-size: 16px;  
    color: #333333; /* 副标题颜色为深灰色 */  
    margin-bottom: 20px;  
    text-align: center; /* 副标题居中显示 */  
  }  
  .steps {  
    display: flex;  
    flex-direction: column;  
    align-items: center;  
  }  
  .step {  
    display: flex;  
    align-items: center;  
    margin-bottom: 20px;  
  }  
  .step-icon {  
    width: 50px;  
    height: 50px;  
    margin-right: 10px; /* 图标与文字之间添加间距 */  
  }  
  .step-text {  
    font-size: 16px;  
    color: #666666; /* 文字颜色为中等灰色 */  
  }  
  .apply-button {  
    width: 150px;  
    height: 40px;  
    background-color: #409EFF;  
    color: #FFFFFF;  
    border-radius: 10px;  
    margin-top: 20px;  
    display: block; /* 确保按钮独占一行 */  
    margin-left: auto; /* 按钮右对齐 */  
    margin-right: auto; /* 按钮水平居中 */  
  }  
</style>