

## IndexedList 索引列表
> **组件名：uni-indexed-list**
> 代码块： `uIndexedList`


用于展示索引列表。

### [查看文档](https://uniapp.dcloud.io/component/uniui/uni-indexed-list)
#### 如使用过程中有任何问题，或者您对uni-ui有一些好的建议，欢迎加入 uni-ui 交流群：871950839 
