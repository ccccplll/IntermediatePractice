<template>  
  <view class="login-container">  
    <view class="login-header">  
      <text class="title">登录</text>  
    </view>  
    <view class="login-body">  
      <input type="text" class="input-item" placeholder="请输入用户名" v-model="username" />  
      <input type="password" class="input-item" placeholder="请输入密码" v-model="password" />  
      <button class="login-btn" @click="login">登录</button>  
    </view>  
  </view>  
</template>  
  
<script>  
export default {  
  data() {  
    return {  
      username: '',  
      password: '',  
    };  
  },  
  methods: {  
    login() {  
      // 这里应该添加与后端服务器的交互逻辑  
      // 例如，使用uni.request发送POST请求到登录接口  
      // 但为了示例的简洁性，这里只打印用户名和密码  
      console.log('用户名:', this.username);  
      console.log('密码:', this.password);  
  
      // 假设登录成功，你可以在这里进行页面跳转等操作  
      uni.navigateTo({ url: '/pages/index/index' });  
    },  
  },  
};  
</script>  
  
<style scoped>  
.login-container {  
  display: flex;  
  flex-direction: column;  
  align-items: center;  
  justify-content: center;  
  height: 100vh;  
  background-color: #f2f2f2;  
}  
  
.login-header {  
  margin-bottom: 20px;  
}  
  
.title {  
  font-size: 24px;  
  font-weight: bold;  
  color: #333;  
}  
  
.input-item {  
  margin-bottom: 15px;  
  padding: 10px;  
  border: 1px solid #ccc;  
  border-radius: 5px;  
  font-size: 16px;  
}  
  
.login-btn {  
  padding: 10px 20px;  
  background-color: #007aff;  
  color: #fff;  
  border: none;  
  border-radius: 5px;  
  font-size: 16px;  
}  
</style>
