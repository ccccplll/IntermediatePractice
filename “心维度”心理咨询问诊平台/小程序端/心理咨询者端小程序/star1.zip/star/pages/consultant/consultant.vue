<template>  
  <view  @class="container">  
    <image src="../../static/head.png" class="image-style"></image>  
  </view>  
  <view class="jiange">
  <text class="size">{{name}}</text> 
  </view>
  <view style="display:inline" class="jiange" >
	  <text class="color1">{{title}}</text>
	  <text class="color1">{{time}}</text>
      <text class="color1">{{money}}</text>
  </view>
  <view class="jiange">
     <text class="size1">个人简介</text>
  </view>
  <view class="jiange1">
     <text>{{jianjie}}</text>
  </view>
  <view class="jiange">
     <text class="size1">擅长领域</text>
  </view>
  <view class="jiange1">
     <text>{{shanchang}}</text>
  </view>
  <view class="jiange">
     <text class="size1">咨询时间</text>
  </view>
  <view class="jiange1" >
     <text>{{shijian}}-{{shijian1}}</text>
  </view>
  <view class="jiange">
     <text class="size1">联系方式</text>
  </view>
  <view class="jiange1">
     <text>电话：{{phone}}</text>
  </view>
  <view class="jiange1">
  	 <text>邮箱：{{email}}</text>
  </view>
 <view class="line" >
 	<view class="delete">
         <navigator url="../mine/mine">
             <button type="default" plain="true" disabled="isButtonDisabled">语音咨询</button>
         </navigator>
 	</view>
 	<view class="delete">
         <navigator url="../dingdan/dingdan">
             <button type="default" plain="true" disabled="isButtonDisabled1">线下咨询</button>
         </navigator>
     </view>
 </view>
</template>  
  
<script> 
import moment from 'moment'; 
 export default { 
	// onLoad() {  
	     // 读取全局变量中的参数  
	    // const params = this.$global.params;  
	  //   console.log(params);  
	 //  } , 
	 
   data() {  
     return {  
	   isButtonDisabled: false ,// 初始为不禁用   
	   isButtonDisabled1: false ,// 初始为不禁用   
	   email:'',
       name: '',  
       title: '成熟咨询师',  
       time: '',  
       money: '',  
       jianjie: '',  
       shanchang: '',  
       shijian: '', 
	   shijian1:'',
       phone: '',
	   type1:''
     };  
   }, 
	
   methods: { 
     information() {  
           uni.request({
           url: "http://localhost:3000/test00",
           method: 'get',
             success: (res) => {  
               if (res.data) { 
				 this.email=res.data.email||'';
				 this.shijian = moment(res.data.start_time).format('YYYY-MM-DD HH:mm:ss') || '';  
				 this.shijian1 = moment(res.data.finish_time).format('YYYY-MM-DD HH:mm:ss') || '';
				 this.money=(res.data.price||0)+'元/时';
                 this.name = res.data.trueName || '';  
                 this.time = (res.data.accumulatedHour || 0) + '小时经验'; 
                 this.jianjie = res.data.introduction || ''; 
                 this.shanchang = res.data.strength || '';   
                 this.phone = res.data.phoneNumber || ''; 
				 this.type1 = res.data.consult_way||'';
				  console.log(this.type1);
				 if(this.type1=='线下咨询'){
					 this.isButtonDisabled=true;
					 this.isButtonDisabled1=false;
				 }else if(this.type1=='语音咨询'){
					 this.isButtonDisabled1=true;
					 this.isButtonDisabled=false;
				 }else{
					 this.isButtonDisabled=false;
					 this.isButtonDisabled1=false;
				 }
				 
				 
               } else {  
                 console.error('Failed to fetch data:', res);  
               }  
             },  
             fail: (err) => {  
               console.error('Request failed:', err);  
             }  
           });  
         }  
       }, 
		
		
       // 你可以在这里添加mounted钩子来自动调用information方法  
       mounted() {  
         this.information(); // 组件挂载后立即获取数据  
       }
 
 }
</script>  
  
<style lang="scss"> 
 
 .line{
 	  display:flex;
 	  justify-content: space-around;
 	  flex-direction: row;
 	  align-items: center;
 	  margin-top:20%;
 }
 .delete{
 	 width:45%;
 	  
 }
 
.container {  
  display: flex;  
  justify-content: center;  
  align-items: center;  
  height: 30%;  
  flex-direction: column; 
}  
  
.image-style {  
  width: 100px; 
  height: 100px; 
} 
 .jiange{
	 margin-top: 3%;
	 margin-bottom: 3%;
	 margin-left: 1.5%;
 }
 .jiange1{
 	 margin-top: 3%;
 	 margin-bottom: 3%;
	 margin-left: 3%;
 }
.color1{
	background-color: #f9f28b;
	border-color: ghostwhite;
	width:30%;
	margin-top: 3%;
	border-radius: 20%;
	margin-left: 4%;
	justify-content: center;  
}
.size{
	font-size: 23px;
	margin-bottom: 3%;
}
.size1{
	font-size: 18px;
	padding-top: 3%;
}
</style>