<template>  
  <view class="settings-container">  
    <view class="settings-header">  
      <text class="settings-title">心维度</text>  
    </view>  
    <view class="settings-section">  
      <switch class="switch-control" :checked="isPushNotificationsEnabled" @change="handlePushNotificationsChange" />  
      <text class="setting-label">接收推送通知</text>  
    </view>  
    <view class="settings-section">  
      <switch class="switch-control" :checked="isPersonalizedShowcaseEnabled" @change="handlePersonalizedShowcaseChange" />  
      <text class="setting-label">接收个性化展示</text>  
    </view>  
    <view class="settings-section">  
      <text class="setting-label">软件升级</text>  
      <text class="setting-subtitle">当前版本 7.2.5</text>  
    </view>  
    <view class="settings-section">  
      <text class="setting-label">清理缓存</text>  
      <text class="setting-subtitle">5.27MB</text>  
    </view>  
    <view class="settings-footer">  
      <!-- 这里可以添加返回箭头和确定按钮的组件 -->  
      <button class="back-button" @click="goBack">返回</button>  
      <button class="confirm-button" @click="confirmSettings">确定</button>  
    </view>  
  </view>  
</template>  
  
<script>  
export default {  
  data() {  
    return {  
      isPushNotificationsEnabled: true,  
      isPersonalizedShowcaseEnabled: true  
    };  
  },  
  methods: {  
    handlePushNotificationsChange(value) {  
      this.isPushNotificationsEnabled = value;  
      // 这里可以添加处理推送通知开关变化的逻辑  
    },  
    handlePersonalizedShowcaseChange(value) {  
      this.isPersonalizedShowcaseEnabled = value;  
      // 这里可以添加处理个性化展示开关变化的逻辑  
    },  
    goBack() {  
      // 导航回上一个页面的逻辑  
      uni.navigateBack();  
    },  
    confirmSettings() {  
      // 确认设置后的逻辑处理  
      console.log('Settings confirmed');  
    }  
  }  
};  
</script>  
  
<style>  
.settings-container {  
  padding: 10px;  
}  
  
.settings-header {  
  display: flex;  
  justify-content: center;  
  align-items: center;  
  margin-bottom: 15px;  
}  
  
.settings-title {  
  font-size: 18px;  
  font-weight: bold;  
}  
  
.settings-section {  
  display: flex;  
  align-items: center;  
  margin-bottom: 10px;  
}  
  
.switch-control {  
  margin-right: 10px;  
}  
  
.setting-label {  
  font-size: 16px;  
}  
  
.setting-subtitle {  
  font-size: 12px;  
  color: #999;  
}  
  
.settings-footer {  
  display: flex;  
  justify-content: space-between;  
  margin-top: 15px;  
}  
  
.back-button, .confirm-button {  
  padding: 5px 10px;  
  border-radius: 4px;  
  background-color: #009688;  
  color: #fff;  
  text-align: center;  
}  
  
.confirm-button {  
  background-color: #1AAD19;  
}  
</style>