<template>
	<scroll-view :scroll-top="screenTop" scroll-y class="scroll-y" @scrolltoupper="upper" @scrolltolower="lower" @scroll="scroll" @click="consult">
	            <view id="demo1" class="scroll-view-item">
	                <view class="botton-top">                        
	                    <view class="touxiang">
	                        <image src="../../static/top_个人信息.png"></image>
	                    </view>
	                    <view class="right">
	                        <view class="name">张三</view>
	                        <view class="time">3小时经验</view>
	                        <view class="introduce-view">
	                            <view class="introduce">hellohellohellohellohellohellohellohellohellohellohellohellohellohellohellohellohellohellohellohellohellohellohellohello</view>
	                        </view>
	                        <view class="taf">
	                            <view class="price">￥500/时</view>
	                            <view class="function">面/语咨询</view>
	                        </view>
	                    </view>    
	                </view>
	                <view class="address">武汉市</view>
	            </view>
	            <view id="demo2" class="scroll-view-item">B</view>
	            <view id="demo3" class="scroll-view-item">C</view>
	            <view id="demo4" class="scroll-view-item">D</view>
	            <view id="demo5" class="scroll-view-item">E</view>
	        </scroll-view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			consult(){
				uni.navigateTo({
					url:"/pages/consultant/consultant"
				})
			}
		}
	}
</script>

<style lang="scss">
	.scroll-Y {
	            height: 300rpx;
	    }
	    
	    .scroll-view-item {
	        height: 300rpx;
	        display: flex;
	        flex-direction: column;
	        border: 1rpx solid gainsboro;
	        //&:last-child{border-bottom: 0;}
	        .botton-top{
	            width: 100%;
	            height: 258rpx;
	            display: flex;
	            flex-direction: row;
	            align-items: center;
	            //border: 1rpx solid skyblue;
	            .touxiang{
	                width: 160rpx;
	                height: 160rpx;
	                border-radius: 100%;
	                overflow: hidden;
	                margin: 25rpx;
	                //border: 1rpx solid skyblue;
	                image{
	                    width: 100%;
	                    height: 100%;
	                }
	            }
	            .right{
	                display: flex;
	                flex-direction: column;
	                align-items: flex-start;
	                height: 218rpx;
	                padding-top: 25rpx;
	                //border: 1rpx solid skyblue;
	                .name{
	                    padding: 5rpx;
	                    font-size: 40rpx;
	                    //border: 1rpx solid skyblue;
	                }
	                .time{
	                    padding: 5rpx;
	                    font-size: 28rpx;
	                    //border: 1rpx solid skyblue;
	                }
	                .introduce-view{
	                    padding: 5rpx;
	                    //font-size: 30rpx;
	                    overflow: hidden;
	                    white-space: nowrap;
	                    text-overflow: ellipsis;
	                    width: 200px;
	                    //border: 1rpx solid skyblue;
	                    .intriduce{
	                        font-size: 30rpx;
	                    }
	                }
	                .taf{
	                    padding: 5rpx;
	                    display: flex;
	                    flex-direction: row;
	                    align-items: center;
	                    justify-content: space-between;
	                    width: 130px;
	                    //border: 1rpx solid skyblue;
	                    .price{
	                        font-size: 28rpx;
	                        text-align: right;
	                        //border: 1rpx solid skyblue;
	                    }
	                    .function{
	                        font-size: 28rpx;
	                        text-align: right;
	                        //border: 1rpx solid skyblue;
	                    }
	                }
	            }
	        }
	        
	        .address{
	            //border: 1rpx solid skyblue;
	            font-size: 30rpx;
	            text-align: right;
	            padding: 6rpx;
	        }
	    }
 
</style>
