var express = require('express');
var router = express.Router();
var connection=require('../database/sql.js');

router.get("/", function(req, res, next) {  
    // 假设您从查询字符串中获取了一个名为"name"的参数  
    let name = req.query.name; 
    connection.query("SELECT * FROM Consultant WHERE true_name = ?", [name], function(error, results, fields) {  
        if (error) {  
            throw error;  
        }  
        console.log('The solution is: ', results);  
        res.json(results);  
    });  
});

router.get("/test", function(req, res, next) {  
    // 假设您从查询字符串中获取了一个名为"city"的参数  
    let city = req.query.city; 
    connection.query("SELECT * FROM Consultant WHERE city = ?", [city], function(error, results, fields) {  
        if (error) {  
            throw error;  
        }  
        console.log('The solution is: ', results);  
        res.json(results);  
    });  
});

router.get("/test2", function(req, res, next) {  
    // 假设您从查询字符串中获取了一个名为"name"的参数  
    let name1 = req.query.name1; 
    connection.query("SELECT * FROM predecide WHERE price = ?", [name1], function(error, results, fields) {  
        if (error) {  
            throw error;  
        }  
        console.log('The solution is: ', results);  
        res.json(results);  
    });  
});

router.get("/selectInfor",function(req,res,next){
	// 从查询字符串中获取 name 参数  
	let name = req.query.name;  
	// 检查 name 是否存在  
	if (!name) {  
		return res.status(400).send('Missing required query parameter: name');  
	}  
	const sql = "SELECT name, age, city, sex, email, phoneNumber FROM user WHERE name = ?";  
	connection.query(sql, [name], function(error, results, fields) {  
		if (error) {  
			// 发生数据库错误  
			return res.status(500).send(error);  
		}  
		if (results.length === 0) {  
			// 没有找到匹配的用户  
			return res.status(404).send('No user found with that name');  
		}  
		// 发送查询结果  
		res.status(200).send(results);  
	});  
});
  
router.post("/updateUser", async function(req, res, next) {  
    try {  
        const { priName, ...updates } = req.body;  
		console.log(req.body); // 在处理之前打印请求体
		// 验证 name 是否存在且非空  
		if (!priName || priName.trim() === '') {  
			return res.status(400).send({ message: '用户名不能为空' });  
		}  
		if (updates === undefined || updates === null) {  
		    return res.status(400).send({ message: '请求体中的更新字段无效' });  
		}
        // 过滤掉空值  
        const filteredUpdates = Object.keys(updates).reduce((acc, key) => {  
            if (updates[key] !== '') {  
                acc[key] = updates[key];  
            }  
            return acc;  
        }, {});  
		// 如果没有要更新的字段，则直接返回  
		if (Object.keys(filteredUpdates).length === 0) {  
			return res.status(400).send({ message: '没有提供要更新的字段' });  
		}  
		console.log(filteredUpdates); // 在构建 SQL 之前打印
        // 构建 SQL 更新语句  
        const updateQuery = `UPDATE user SET ${Object.keys(filteredUpdates).map(key => `${key} = ?`).join(', ')} WHERE name = ?`;  
        const values = [...Object.values(filteredUpdates), priName];  
		console.log(updateQuery);
        // 执行更新操作  
		connection.query(updateQuery,values,function(error,results,fields){
			if (error) {
			    res.status(500).send(error);  
			} else {  
			    // 这里可以根据results.affectedRows来获取更新了多少行  
			    res.status(200).send(results);  
			}  
		});
        
    } catch (error) {  
        // 捕获并处理任何错误  
        console.error('数据库更新失败:', error);  
        res.status(500).send(error);  
    }  
});  


router.post("/changeInfor", function(req, res, next) {  
    // 假设你只想更新来自请求体的字段，但只针对名为'Bob'的用户  
    // 注意：这里应该验证req.body中的字段是否存在和有效  
    const newName = req.body.name || 'Boo'; // 如果name不存在，则默认为'Boo'  
    const newAge = parseInt(req.body.age, 10) || 18; // 尝试将age转换为整数，默认为18  
    const newCity = req.body.city || '武汉'; // 如果city不存在，则默认为'武汉'  
    const newSex = req.body.sex || '女'; // 如果sex不存在，则默认为'女'  
    const newEmail = req.body.email || '123456@qq.com'; // 如果email不存在，则默认为'123456@qq.com'  
    const newPhoneNumber = req.body.phoneNumber || 123456789; // 如果phoneNumber不存在，则默认为123456789（注意：这取决于你的数据库如何存储phoneNumber）  
  
    const sql = "UPDATE user SET name = ?, age = ?, city = ?, sex = ?, email = ?, phoneNumber = ? WHERE name = 'Bob'";  
    // 注意：这里我们使用了从req.body中提取的值，但只针对'Bob'进行更新  
    // 如果你的业务逻辑需要基于请求体中的name来更新用户，你需要更改WHERE子句  
    connection.query(sql, [newName, newAge, newCity, newSex, newEmail, newPhoneNumber], function(error, results, fields) {  
        if (error) {  
            res.status(500).send(error);  
        } else {  
            // 这里可以根据results.affectedRows来获取更新了多少行  
            res.status(200).send("Data update successfully");  
        }  
    });  
});

router.get("/test3", function(req, res, next) {  
    // 假设您从查询字符串中获取了一个名为"item"的参数  
    let item = req.query.item; 
    connection.query("SELECT * FROM Consultant WHERE skilled_field = ?", [item], function(error, results, fields) {  
        if (error) {  
            throw error;  
        }  
        console.log('The solution is: ', results);  
        res.json(results);  
    });  
});

router.get("/test4", function(req, res, next) {  
    let rawDatetimerange = req.query.datetimerange;  
    try {  
        let datetimerangeArray = JSON.parse(rawDatetimerange);  
        if (datetimerangeArray.length !== 2) {  
            throw new Error('Invalid date range format');  
        }  
        let startDate = datetimerangeArray[0];  
        let endDate = datetimerangeArray[1];    
        connection.query("SELECT * FROM predecide WHERE begin_time BETWEEN ? AND ?", [startDate, endDate], function(error, results, fields) {  
            if (error) {  
                next(error); 
            }  
            console.log('The solution is: ', results);  
            res.json(results);  
        });  
    } catch (e) {  
        res.status(400).send('Invalid date range format');  
    }  
});

router.get("/combined-search", function(req, res, next) {  
    let city = req.query.city;  
    let name1 = req.query.name1;  
    let item = req.query.item;  
    let rawDatetimerange = req.query.datetimerange;  
    let conditions = [];  
    let queryParams = [];  
  
    if (city) {  
        conditions.push("consultant.city = ?");  
        queryParams.push(city);  
    }  
  
    if (name1) {  
        conditions.push("production.price = ?");  
        queryParams.push(name1);   
    }  
    if (item) {  
        conditions.push("consultant.strength = ?");  
        queryParams.push(item);  
    }  
    if (rawDatetimerange) {  
        try {  
            let datetimerangeArray = JSON.parse(rawDatetimerange);  
            if (datetimerangeArray.length !== 2) {  
                throw new Error('Invalid date range format');  
            }  
            let startDate = datetimerangeArray[0];  
            let endDate = datetimerangeArray[1];  
            conditions.push("production.start_time BETWEEN ? AND ?");  
            queryParams.push(startDate, endDate);  
            // 同样，这里混合了两个表，可能需要更复杂的查询逻辑  
        } catch (e) {  
            return res.status(400).send('Invalid date range format');  
        }  
    }  
  
    let query = "SELECT * FROM consultant";  
    if (conditions.some(cond => cond.includes('production'))) {  
        query += " JOIN production ON consultant.id = production.c_id";  
    }  
  
    if (conditions.length > 0) {  
        query += " WHERE " + conditions.join(' OR ');  
    }  
  
    connection.query(query, queryParams, function(error, results, fields) { 
		console.log(error,results)
        if (error) {  
            next(error); 
			 return;
        }  
        res.json(results);  
    });  
});

router.get("/test00", function(req, res, next) {  
	let query = 'SELECT * FROM consultant, production WHERE trueName = "王咪" and production.c_id= consultant.id'
    connection.query(query, function(error, results, fields) { 
		console.log(error,results)
        if (error) {  
            return res.status(500).json({ error: error});  
        }  
        if (results.length > 0) { // 确保查询结果不为空  
            console.log('The solution is: ', results[0]); // 通常我们只会返回一个结果  
            res.json(results[0]); // 发送单个对象而不是数组  
        } else {  
            res.json({ message: 'No data found' }); // 如果没有找到数据，发送一个消息  
        }  
    });  
});


module.exports = router;
