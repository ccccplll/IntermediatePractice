var mysql = require('mysql');
var connection = mysql.createConnection({
    host: 'gz-cynosdbmysql-grp-golzjmnr.sql.tencentcdb.com', //host地址
    port:22876, //端口号
    user: 'root', //连接数据库时的账号
    password: '20050602Zck',//连接数据库时的密码
    database: 'weheart_db' //需要连接的数据库
});
module.exports = connection;
