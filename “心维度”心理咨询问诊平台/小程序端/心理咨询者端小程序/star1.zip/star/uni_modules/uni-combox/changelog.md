## 1.0.1（2021-11-23）
- 优化 label、label-width 属性
## 1.0.0（2021-11-19）
- 优化 组件UI，并提供设计资源，详见:[https://uniapp.dcloud.io/component/uniui/resource](https://uniapp.dcloud.io/component/uniui/resource)
- 文档迁移，详见:[https://uniapp.dcloud.io/component/uniui/uni-combox](https://uniapp.dcloud.io/component/uniui/uni-combox)
## 0.1.0（2021-07-30）
- 组件兼容 vue3，如何创建vue3项目，详见 [uni-app 项目支持 vue3 介绍](https://ask.dcloud.net.cn/article/37834)
## 0.0.6（2021-05-12）
- 新增 组件示例地址
## 0.0.5（2021-04-21）
- 优化 添加依赖 uni-icons, 导入后自动下载依赖
## 0.0.4（2021-02-05）
- 优化 组件引用关系，通过uni_modules引用组件
## 0.0.3（2021-02-04）
- 调整为uni_modules目录规范
