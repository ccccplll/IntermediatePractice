const mysql = require('mysql');

// 创建连接池
const pool = mysql.createPool({
  host: 'gz-cynosdbmysql-grp-golzjmnr.sql.tencentcdb.com',
  port:22876, //端口号
  user: 'root',
  password: '20050602Zck',
  database: 'weheart_db',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

module.exports = pool;
