var express = require('express');
var bodyParser = require('body-parser');
var router = express.Router();
var connection=require('../database/sql.js');
var pool = require('../database/db.js');

router.use(bodyParser.json({ limit: '10mb' })); // 增大请求体大小限制

router.post("/insertMyPage", function(req, res, next) {
    const { u_id, pagetxt, goodcount, publish_time, state, txtcount } = req.body;
    const sql1 = "INSERT INTO page(u_id, image, pagetxt, goodcount, publish_time, state, txtcount) VALUES (?, 'https://img95.699pic.com/xsj/1n/r5/g0.jpg%21/fw/700/watermark/url/L3hzai93YXRlcl9kZXRhaWwyLnBuZw/align/southeast', ?, ?, ?, ?, ?)";
    const sql2 = "INSERT INTO pageliked(u_id, page_id, liked) VALUES (?, ?, 0)";

    // 插入 page 表数据
    connection.query(sql1, [u_id, pagetxt, goodcount, publish_time, state, txtcount], function(error, results, fields) {
        if (error) {
            console.error(error);
            return res.status(500).json({ error: 'Database query error' });
        }
        
        // 获取刚插入数据的 id
        const page_id = results.insertId;

        // 插入 pageliked 表数据
        connection.query(sql2, [u_id, page_id], function(error, results, fields) {
            if (error) {
                console.error(error);
                return res.status(500).json({ error: 'Database query error' });
            }

            console.log('The solution is: ', results);
            res.json(results);
        });
    });
});

router.get("/getRandomPictures", function(req, res, next) {
    const sql = 'SELECT image FROM advertising ORDER BY RAND() LIMIT 4';
    connection.query(sql, function(error, results, fields) {
        if (error) {  
            console.error('Database query error:', error);
            res.status(500).json({ error: error.message });
        } else {  
            // 正确获取数据时，将结果返回给客户端
            res.status(200).json(results);
        }  
    });  
});

router.get("/selectInfor",function(req,res,next){
	// 从查询字符串中获取 name 参数  
	let name = req.query.name;  
	// 检查 name 是否存在  
	if (!name) {  
		return res.status(400).send('Missing required query parameter: name');  
	}  
	const sql = "SELECT id, name, age, city, sex, email, phoneNumber FROM user WHERE name = ?";  
	connection.query(sql, [name], function(error, results, fields) {  
		if (error) {  
			// 发生数据库错误  
			return res.status(500).send(error);  
		}  
		if (results.length === 0) {  
			// 没有找到匹配的用户  
			return res.status(404).send('No user found with that name');  
		}  
		// 发送查询结果  
		res.status(200).send(results);  
	});  
});
  
router.post("/updateUser", async function(req, res, next) {  
    try {  
        const { priName, ...updates } = req.body;  
		console.log(req.body); // 在处理之前打印请求体
		// 验证 name 是否存在且非空  
		if (!priName || priName.trim() === '') {  
			return res.status(400).send({ message: '用户名不能为空' });  
		}  
		if (updates === undefined || updates === null) {  
		    return res.status(400).send({ message: '请求体中的更新字段无效' });  
		}
        // 过滤掉空值  
        const filteredUpdates = Object.keys(updates).reduce((acc, key) => {  
            if (updates[key] !== '') {  
                acc[key] = updates[key];  
            }  
            return acc;  
        }, {});  
		// 如果没有要更新的字段，则直接返回  
		if (Object.keys(filteredUpdates).length === 0) {  
			return res.status(400).send({ message: '没有提供要更新的字段' });  
		}  
		console.log(filteredUpdates); // 在构建 SQL 之前打印
        // 构建 SQL 更新语句  
        const updateQuery = `UPDATE user SET ${Object.keys(filteredUpdates).map(key => `${key} = ?`).join(', ')} WHERE name = ?`;  
        const values = [...Object.values(filteredUpdates), priName];  
		console.log(updateQuery);
        // 执行更新操作  
		connection.query(updateQuery,values,function(error,results,fields){
			if (error) {
			    res.status(500).send(error);  
			} else {  
			    // 这里可以根据results.affectedRows来获取更新了多少行  
			    res.status(200).send(results);  
			}  
		});
        
    } catch (error) {  
        // 捕获并处理任何错误  
        console.error('数据库更新失败:', error);  
        res.status(500).send(error);  
    }  
});  


router.post("/changeInfor", function(req, res, next) {  
    // 假设你只想更新来自请求体的字段，但只针对名为'Bob'的用户  
    // 注意：这里应该验证req.body中的字段是否存在和有效  
    const newName = req.body.name || 'Boo'; // 如果name不存在，则默认为'Boo'  
    const newAge = parseInt(req.body.age, 10) || 18; // 尝试将age转换为整数，默认为18  
    const newCity = req.body.city || '武汉'; // 如果city不存在，则默认为'武汉'  
    const newSex = req.body.sex || '女'; // 如果sex不存在，则默认为'女'  
    const newEmail = req.body.email || '123456@qq.com'; // 如果email不存在，则默认为'123456@qq.com'  
    const newPhoneNumber = req.body.phoneNumber || 123456789; // 如果phoneNumber不存在，则默认为123456789（注意：这取决于你的数据库如何存储phoneNumber）  
  
    const sql = "UPDATE user SET name = ?, age = ?, city = ?, sex = ?, email = ?, phoneNumber = ? WHERE name = 'Bob'";  
    // 注意：这里我们使用了从req.body中提取的值，但只针对'Bob'进行更新  
    // 如果你的业务逻辑需要基于请求体中的name来更新用户，你需要更改WHERE子句  
    connection.query(sql, [newName, newAge, newCity, newSex, newEmail, newPhoneNumber], function(error, results, fields) {  
        if (error) {  
            res.status(500).send(error);  
        } else {  
            // 这里可以根据results.affectedRows来获取更新了多少行  
            res.status(200).send("Data update successfully");  
        }  
    });  
});


router.get("/getAnnouncement",function(req,res,next){
	const index = req.query.index;
	console.log(index);
	const sql = "SELECT context FROM announcement WHERE id = ?";
	connection.query(sql, [index], function(error, results, fields) {
		if (error) {
			console.error(error);
			return res.status(500).json({ error: 'Database query error' });
		}
		console.log('The solution is: ', results);
		
		res.json(results); 
	});
});

router.get("/getOrder", function(req, res, next) {
    const id = req.query.id;
    if (!id) {
        return res.status(400).json({ error: 'User ID is required' });
    }
    const sql = "SELECT a.c_id, a.id, c.avatar, a.state, c.trueName, a.create_time, p.start_time, TIMESTAMPDIFF(SECOND, p.start_time, p.finish_time) AS time, p.price, a.isCommented, p.start_time, p.finish_time FROM appointment a JOIN production p ON a.p_id = p.p_id JOIN consultant c ON a.c_id = c.id WHERE a.u_id = ? AND c.certificationStatus = '已认证'";
    
    connection.query(sql, [id], function(error, results, fields) {
        if (error) {
            console.error(error);
            return res.status(500).json({ error: 'Database query error' });
        }

        const currentTime = new Date();
        const updatedOrders = results.map(order => {
            // 更新待支付订单为已失效
            if (order.state === '待支付' && new Date(order.start_time) < currentTime) {
                order.state = '已失效';

                // 更新数据库中的订单状态
                const updateQuery = 'UPDATE appointment SET state = ? WHERE id = ?';
                connection.query(updateQuery, ['已失效', order.id], (err, updateResult) => {
                    if (err) throw err;
                });
            }

            // 更新待完成订单为已完成
            if (order.state === '待完成' && new Date(order.finish_time) < currentTime) {
                order.state = '已完成';

                // 更新数据库中的订单状态
                const updateQuery = 'UPDATE appointment SET state = ? WHERE id = ?';
                connection.query(updateQuery, ['已完成', order.id], (err, updateResult) => {
                    if (err) throw err;
                });
            }

            return order;
        });

        res.json(updatedOrders); 
    });
});


router.get("/getOrderDetails",function(req,res,next){
	const index = req.query.id;
	const sql = "SELECT c.id, a.p_id, a.state, c.trueName, p.price, TIMESTAMPDIFF(SECOND, p.start_time, p.finish_time) AS time, p.start_time, p.finish_time, c.phoneNumber FROM appointment a JOIN production p ON a.p_id = p.p_id JOIN consultant c ON p.c_id = c.id WHERE a.id = ?";
	connection.query(sql, [index], function(error, results, fields) {
		if (error) {
			console.error(error);
			return res.status(500).json({ error: 'Database query error' });
		}
		console.log('The solution is: ', results);
		
		res.json(results); 
	});
});

router.post("/payOrder", function(req, res, next) {
  const { id, p_id, c_id, create_time } = req.body;
  const checkOrderStatusSql = "SELECT state FROM appointment WHERE id = ?";
  const updateOrderStatusSql = "UPDATE appointment SET state = '待完成' WHERE id = ? AND state = '待支付'";
  const updateOtherOrdersSql = "UPDATE appointment SET state = '已失效' WHERE p_id = ? AND state = '待支付' AND id != ?";
  const updateSql = "UPDATE production SET is_appointed = 1 WHERE p_id = ?";
  const insertSql = "INSERT INTO consultant_message(c_id, context, create_time, type, is_read) VALUES(?, '您有新的预约', ?, '预约提醒', 0)";

  pool.getConnection(function(err, connection) {
    if (err) {
      console.error("Error getting database connection:", err);
      return res.status(500).json({ error: 'Database connection error', details: err });
    }

    connection.beginTransaction(function(err) {
      if (err) {
        connection.release();
        console.error("Error beginning transaction:", err);
        return res.status(500).json({ error: 'Database transaction error', details: err });
      }

      connection.query(checkOrderStatusSql, [id], function(error, results, fields) {
        if (error) {
          return connection.rollback(function() {
            connection.release();
            console.error("Error querying order status:", error);
            res.status(500).json({ error: 'Database query error', details: error });
          });
        }

        if (results.length === 0) {
          connection.release();
          return res.status(404).json({ error: 'Order not found' });
        }

        const orderStatus = results[0].state;

        if (orderStatus === '已失效') {
          connection.release();
          return res.status(400).json({ error: 'Order is already invalid' });
        }

        if (orderStatus !== '待支付') {
          connection.release();
          return res.status(400).json({ error: 'Order cannot be paid' });
        }

        connection.query(updateOrderStatusSql, [id], function(error, results, fields) {
          if (error) {
            return connection.rollback(function() {
              connection.release();
              console.error("Error updating order status:", error);
              res.status(500).json({ error: 'Database query error', details: error });
            });
          }

          if (results.affectedRows === 0) {
            connection.release();
            return res.status(400).json({ error: 'Failed to update order status' });
          }

          connection.query(updateOtherOrdersSql, [p_id, id], function(error, results, fields) {
            if (error) {
              return connection.rollback(function() {
                connection.release();
                console.error("Error updating other orders:", error);
                res.status(500).json({ error: 'Database query error', details: error });
              });
            }

            connection.query(updateSql, [p_id], function(error, results, fields) {
              if (error) {
                return connection.rollback(function() {
                  connection.release();
                  console.error("Error updating production:", error);
                  res.status(500).json({ error: 'Database query error', details: error });
                });
              }

              if (results.affectedRows === 0) {
                connection.release();
                return res.status(400).json({ error: 'Failed to update production' });
              }

              connection.query(insertSql, [c_id, create_time], function(error, results, fields) {
                if (error) {
                  return connection.rollback(function() {
                    connection.release();
                    console.error("Error inserting consultant message:", error);
                    res.status(500).json({ error: 'Database query error', details: error });
                  });
                }

                connection.commit(function(err) {
                  if (err) {
                    return connection.rollback(function() {
                      connection.release();
                      console.error("Error committing transaction:", err);
                      res.status(500).json({ error: 'Database commit error', details: err });
                    });
                  }

                  connection.release();
                  res.json({ success: true, message: 'Order paid and other orders invalidated' });
                });
              });
            });
          });
        });
      });
    });
  });
});

router.post("/updateSee",function(req,res,next){
    const{seeMessage,c_id} = req.body;
	console.log(req.body.seeMessage);
    const sql = "UPDATE consultant SET seemessage=? WHERE id=?";
    connection.query(sql,[seeMessage,c_id],function(error,results,fields){
        if (error) {
            console.error(error);
            return res.status(500).json({ error: 'Database query error' });
        }
        res.send('修改成功'); 
    });
});

router.post("/getPassword", function(req, res, next) {
    const name = req.body.userName;  // 使用req.body获取POST请求的参数
    const sql = "SELECT password FROM user WHERE name = ?";
    connection.query(sql, [name], function(error, results, fields) {
        if (error) {
            console.error(error);
            return res.status(500).json({ error: 'Database query error' });
        }
        
        if (results.length === 0) {
            return res.status(404).json({ error: 'User not found' });
        }
        
        res.json(results); 
    });
});

router.post("/insertUser", function(req, res, next) {
    const { username, password, email } = req.body;
    const sql = "INSERT INTO user (name, password, email) VALUES (?, ?, ?)";
    connection.query(sql, [username, password, email], function(error, results, fields) {
        if (error) {
            console.error(error);
            return res.status(500).json({ error: 'Database insertion error' });
        }
        
        res.status(200).json({ message: 'User registered successfully' });
    });
});

router.get("/getAddress",function(req,res,next){
	const name = req.query.name;
	const sql = 'SELECT city FROM user WHERE name = ?';
	connection.query(sql,[name],function(error,results,fields){
		if (error) {
			console.error(error);
			return res.status(500).json({ error: 'Database query error' });
		}
		console.log('The solution is: ', results);
		res.json(results); 
	})
});

router.get("/getSameCity",function(req,res,next){
	const city = req.query.city;
	const is = "已认证";
	const sql = "SELECT p.p_id, c.avatar, c.trueName, c.accumulatedHour, c.introduction, p.price, p.consult_way,c.city FROM consultant c JOIN production p ON c.id = p.c_id WHERE c.certificationStatus = ? AND p.is_appointed = 0 AND c.city = ? ORDER BY p.start_time ASC";
	connection.query(sql,[is,city],function(error,results,fields){
		if (error) {
			console.error(error);
			return res.status(500).json({ error: 'Database query error' });
		}
		console.log('The solution is: ', results);
		
		res.json(results); 
	})
});

router.get("/getDiffCity",function(req,res,next){
	const city = req.query.city;
	const is = "已认证";
	const sql = "SELECT p.p_id, c.avatar, c.trueName, c.accumulatedHour, c.introduction, p.price, p.consult_way,c.city FROM consultant c JOIN production p ON c.id = p.c_id WHERE c.certificationStatus = ? AND p.is_appointed = 0 AND c.city != ? ORDER BY p.start_time ASC";
	connection.query(sql,[is,city],function(error,results,fields){
		if (error) {
			console.error(error);
			return res.status(500).json({ error: 'Database query error' });
		}
		console.log('The solution is: ', results);
		
		res.json(results); 
	})
});

router.get("/getConsultantDetail",function(req,res,next){
	const id = req.query.p_id;
	const sql = "SELECT c.id, c.avatar, c.trueName, c.accumulatedHour, p.price, c.introduction, c.strength, p.start_time, p.finish_time, c.phoneNumber, c.email, p.consult_way FROM production p JOIN consultant c ON p.c_id = c.id WHERE p_id = ?";
	connection.query(sql,[id],function(error,results,fields){
		if (error) {
			console.error(error);
			return res.status(500).json({ error: 'Database query error' });
		}
		console.log('The solution is: ', results);
		res.json(results); 
	});
});

router.post("/insertOrder",function(req,res,next){
	const{u_id,c_id,p_id,create_time,state,consult_way} = req.body;
	const sql = "INSERT INTO appointment(u_id,c_id,p_id,create_time,state,consult_way,isCommented) VALUES (?,?,?,?,?,?,0)";
	connection.query(sql, [u_id,c_id,p_id,create_time,state,consult_way], function(error,results,fields){
		if (error) {
			console.error(error);
			return res.status(500).json({ error: 'Database query error' });
		}
		console.log('The solution is: ', results);
		res.json(results); 
	});
});

router.post("/deleteOrder",function(req,res,next){
	const{u_id,c_id,p_id} = req.body;
	const sql = "DELETE FROM appointment WHERE u_id = ? AND c_id = ? AND p_id = ?";
	connection.query(sql, [u_id,c_id,p_id], function(error,results,fields){
		if (error) {
			console.error(error);
			return res.status(500).json({ error: 'Database query error' });
		}
		console.log('The solution is: ', results);
		res.json(results); 
	});
});

router.post("/deleteOrder1",function(req,res,next){
	const id = req.body.id;
	const sql = "DELETE FROM appointment WHERE id = ?";
	connection.query(sql, [id], function(error,results,fields){
		if (error) {
			console.error(error);
			return res.status(500).json({ error: 'Database query error' });
		}
		console.log('The solution is: ', results);
		res.json(results); 
	});
});

router.get("/isOrdered", function(req,res,next){
	const{u_id,c_id,p_id} = req.query;
	const sql = "SELECT * FROM appointment WHERE u_id = ? AND c_id = ? AND p_id = ?";
	connection.query(sql, [u_id,c_id,p_id], function(error,results,fields){
		if (error) {
			console.error(error);
			return res.status(500).json({ error: 'Database query error' });
		}
		console.log('The solution is: ', results);
		res.json(results); 
	});
});

router.post("/setState",function(req,res,next){
	const id = req.body.id;
	const sql = "UPDATE appointment SET state = '退款中' WHERE id = ?";
	connection.query(sql, [id], function(error,results,fields){
		if (error) {
			console.error(error);
			return res.status(500).json({ error: 'Database query error' });
		}
		console.log('The solution is: ', results);
		res.json(results); 
	});
});

router.post("/insertRefundApply",function(req,res,next){
	const{a_id,u_id,context,state,submit_time}=req.body;
	const sql = "INSERT INTO refundapply(a_id,u_id,context,state,submit_time) VALUES (?,?,?,?,?)";
	connection.query(sql,[a_id,u_id,context,state,submit_time],function(error,results,fields){
		if (error) {
			console.error(error);
			return res.status(500).json({ error: 'Database query error' });
		}
		console.log('The solution is: ', results);
		res.json(results); 
	});
});

router.post("/insertComment",function(req,res,next){
	const{c_id,score,content,time,appoint_id}=req.body;
	const sql = "INSERT INTO comment(c_id,score,content,time,appoint_id) VALUES (?,?,?,?,?)";
	connection.query(sql,[c_id,score,content,time,appoint_id],function(error,results,fields){
		if (error) {
			console.error(error);
			return res.status(500).json({ error: 'Database query error' });
		}
		console.log('The solution is: ', results);
		res.json(results); 
	});
});

router.post("/isComment",function(req,res,next){
	const id = req.body.id;
	const sql = "UPDATE appointment SET isCommented = 1 WHERE id = ?";
	connection.query(sql,[id],function(error,results,fields){
		if (error) {
			console.error(error);
			return res.status(500).json({ error: 'Database query error' });
		}
		console.log('The solution is: ', results);
		res.json(results); 
	});
});

router.get("/getCommentValue",function(req,res,next){
	const p_id = req.query.p_id;
	const sql = "SELECT appoint_id, score, time, content FROM comment WHERE c_id = (SELECT c_id FROM production WHERE p_id = ?)";
	connection.query(sql,[p_id],function(error,results,fields){
		if (error) {
			console.error(error);
			return res.status(500).json({ error: 'Database query error' });
		}
		console.log('The solution is: ', results);
		res.json(results); 
	});
});

router.get("/getPages",function(req,res,next){
	const sql = "SELECT * FROM page ORDER BY publish_time DESC";
	connection.query(sql,function(error,results,fields){
		if (error) {
			console.error(error);
			return res.status(500).json({ error: 'Database query error' });
		}
		console.log('The solution is: ', results);
		res.json(results); 
	});
});

router.get("/getOnePages",function(req,res,next){
	const id = req.query.id;
	const sql = "SELECT image, pagetxt, goodcount, publish_time, state, txtcount FROM page WHERE id = ?";
	connection.query(sql,[id],function(error,results,fields){
		if (error) {
			console.error(error);
			return res.status(500).json({ error: 'Database query error' });
		}
		console.log('The solution is: ', results);
		res.json(results); 
	});
});

router.post("/changeLiked",function(req,res,next){
	const {u_id,page_id}=req.body;
	const sql = "UPDATE pageliked SET liked = (CASE WHEN liked = 1 THEN 0 ELSE 1 END) WHERE u_id = ? AND page_id = ?";
	connection.query(sql,[u_id,page_id],function(error,results,fields){
		if (error) {
			console.error(error);
			return res.status(500).json({ error: 'Database query error' });
		}
		console.log('The solution is: ', results);
		res.json(results); 
	});
});

router.post("/changeGood",function(req,res,next){
	const {id,goodcount}=req.body;
	const sql = "UPDATE page SET goodcount = ? WHERE id = ?";
	connection.query(sql,[goodcount,id],function(error,results,fields){
		if (error) {
			console.error(error);
			return res.status(500).json({ error: 'Database query error' });
		}
		console.log('The solution is: ', results);
		res.json(results); 
	});
});

router.get("/getAllGood",function(req,res,next){
	const u_id = req.query.u_id;
	const sql = "SELECT page_id,liked FROM pageliked WHERE u_id = ?";
	connection.query(sql,[u_id],function(error,results,fields){
		if (error) {
			console.error(error);
			return res.status(500).json({ error: 'Database query error' });
		}
		console.log('The solution is: ', results);
		res.json(results); 
	});
});

router.get("/getGood",function(req,res,next){
	const {u_id,page_id}=req.query;
	const sql = "SELECT liked FROM pageliked WHERE u_id = ? AND page_id = ?";
	connection.query(sql,[u_id,page_id],function(error,results,fields){
		if (error) {
			console.error(error);
			return res.status(500).json({ error: 'Database query error' });
		}
		console.log('The solution is: ', results);
		res.json(results); 
	});
});

router.get("/getPageComments",function(req,res,next){
	const t_id = req.query.t_id;
	const sql = "SELECT u_id, create_time, content FROM pagecontent WHERE t_id = ? ORDER BY create_time DESC";
	connection.query(sql,[t_id],function(error,results,fields){
		if (error) {
			console.error(error);
			return res.status(500).json({ error: 'Database query error' });
		}
		console.log('The solution is: ', results);
		res.json(results); 
	});
});

router.post("/insertNewComment",function(req,res,next){
	const{t_id,u_id,create_time,content} = req.body;
	const sql = "INSERT INTO pagecontent(t_id,u_id,create_time,content) VALUES(?,?,?,?)";
	connection.query(sql,[t_id,u_id,create_time,content],function(error,results,fields){
		if (error) {
			console.error(error);
			return res.status(500).json({ error: 'Database query error' });
		}
		console.log('The solution is: ', results);
		res.json(results); 
	});
});

router.post("/updateTxtcount",function(req,res,next){
	const{id,txtcount} = req.body;
	const sql = "UPDATE page SET txtcount = ? WHERE id = ?";
	connection.query(sql,[txtcount,id],function(error,results,fields){
		if (error) {
			console.error(error);
			return res.status(500).json({ error: 'Database query error' });
		}
		console.log('The solution is: ', results);
		res.json(results); 
	});
});

router.get("/getAllEssay",function(req,res,next){
    //const index = req.query.index;
    //console.log(index);
	const e_state = '已通过审核';
	console.log(e_state);
    const sql = "SELECT e.id,c.trueName,e.time,e.good,e.title,e.content,i.img_src FROM essay e JOIN consultant c ON e.c_id = c.id JOIN essay_image i ON e.id = i.e_id WHERE e.state=?";
    connection.query(sql,[e_state],function(error, results, fields) {
        if (error) {
            console.error(error);
            return res.status(500).json({ error: 'Database query error' });
        }
        console.log('The solution is: ', results);
        res.json(results); 
    });
});

router.get("/getOneEssay",function(req,res,next){
	const id = req.query.id;
	const sql = "SELECT i.img_src, e.title, c.trueName, e.time, e.content FROM essay e JOIN consultant c ON e.c_id = c.id JOIN essay_image i ON e.id = i.e_id WHERE e.id = ?";
	connection.query(sql,[id],function(error, results, fields) {
	    if (error) {
	        console.error(error);
	        return res.status(500).json({ error: 'Database query error' });
	    }
	    console.log('The solution is: ', results);
	    res.json(results); 
	});
})

router.post("/insertBug", function(req, res, next) {    const { name, bug, email } = req.body;    const sql = "INSERT INTO buglist (name, bug, email) VALUES (?, ?, ?)";    connection.query(sql, [name, bug, email], function(error, results, fields) {        if (error) {            console.error(error);            return res.status(500).json({ error: 'Database insertion error' });        }                res.status(200).json({ message: 'User registered successfully' });    });});

router.get("/getCertificationP",function(req,res,next){
	const p_id = req.query.p_id;
	const sql = "SELECT image FROM apply WHERE a_state = '已审批' AND c_id = (SELECT c_id FROM production WHERE p_id = ?)";
	connection.query(sql,[p_id],function(error,results,fields){
		if (error) {
			console.error(error);
			return res.status(500).json({ error: 'Database query error' });
		}
		console.log('The solution is: ', results);
		res.json(results); 
	});
});

router.get("/getABCD", function(req, res, next) {
	const index = req.query.index; // 从 query 参数中获取 index
	console.log(index);
	const sql = "SELECT * FROM testquestion WHERE id = ?";
	connection.query(sql, [index], function(error, results, fields) {
		if (error) {
			console.error(error);
			return res.status(500).json({ error: 'Database query error' });
		}
		console.log('The solution is: ', results);
		
		results = results.map(item => {
			item.question_context = item.question_context.replace(/\n/g, '');
			return item;
		});
		res.json(results); 
	});
});

router.post("/submitTest",function(req,res,next){
	const{u_id,score,t_condition,time} = req.body;
	const sql = "INSERT INTO test(u_id,score,t_condition,time) VALUES(?,?,?,?)";
	connection.query(sql,[u_id,score,t_condition,time],function(error,results,fields){
		if(error){
			console.error(error);
			return res.status(500).json({ error: 'Database insert error' });
        }
        res.json({ success: true, time: time });
	});
});


//获取消息列表
router.get("/getMessage",function(req,res,next){
    //const index = req.query.index;
    //console.log(index);
	const u_id = req.query.u_id;
    const sql = "SELECT * FROM user_message WHERE u_id=? ORDER BY create_time DESC";
    connection.query(sql,[u_id],function(error, results, fields) {
        if (error) {
            console.error(error);
            return res.status(500).json({ error: 'Database query error' });
        }
        console.log('The solution is: ', results);
        res.json(results); 
    });
});

//给用户发消息
router.post("/sendMessageToUser",function(req,res,next){
    const{u_id,create_time,content} = req.body;
    const sql = "INSERT INTO user_message(u_id,create_time,content,type,is_read) VALUES(?,?,?,?,0)";
    connection.query(sql,[t_id,u_id,create_time,content],function(error,results,fields){
        if (error) {
            console.error(error);
            return res.status(500).json({ error: 'Database query error' });
        }
        console.log('The solution is: ', results);
        res.json(results); 
    });
});
//更新新消息
router.post("/refreshData",function(req,res,next){
    const c_id = req.query.c_id;
    const sql = "SELECT seemessage FROM consultant WHERE id=?";
    connection.query(sql,[c_id],function(error,results,fields){
        if (error) {
            console.error(error);
            return res.status(500).json({ error: 'Database query error' });
        }
        console.log('The solution is: ', results);
        res.json(results); 
    });
});
//给咨询师发消息
router.post("/sendMessageToConsultant",function(req,res,next){
    const{u_id,create_time,content} = req.body;
    const sql = "INSERT INTO user_message(u_id,create_time,content,type,is_read) VALUES(?,?,?,?,0)";
    connection.query(sql,[t_id,u_id,create_time,content],function(error,results,fields){
        if (error) {
            console.error(error);
            return res.status(500).json({ error: 'Database query error' });
        }
        console.log('The solution is: ', results);
        res.json(results); 
    });
});
//咨询师读消息
router.post("/readConsultant",function(req,res,next){
    const id = req.body.id;
    const sql = "UPDATE user_message SET is_read=1 WHERE id=?";
    connection.query(sql,[id],function(error,results,fields){
        if (error) {
            console.error(error);
            return res.status(500).json({ error: 'Database query error' });
        }
        res.send('修改成功'); 
    });
});

//用户取消红点
router.post("/updateSee",function(req,res,next){
    const u_id = req.body.u_id;
    const sql = "UPDATE user SET seemessage='已看过' WHERE id=?";
    connection.query(sql,[u_id],function(error,results,fields){
        if (error) {
            console.error(error);
            return res.status(500).json({ error: 'Database query error' });
        }
        res.send('修改成功'); 
    });
});





router.get("/", function(req, res, next) {  
    // 假设您从查询字符串中获取了一个名为"name"的参数  
	let nameee = req.query.nameee;
	console.log('sos: ', nameee);  
    //let name = req.query.name; 
    connection.query("SELECT * FROM consultant , production WHERE trueName = ? and production.c_id= consultant.id and production.is_appointed=0 and consultant.certificationStatus='已认证'", [nameee], function(error, results, fields) {  
        if (error) {  
            throw error;  
        }  
        console.log('The solution is: ', results);  
        res.json(results);  
    });  
});

router.get("/mmmm", function(req, res, next) {  
    // 假设您从查询字符串中获取了一个名为"name"的参数  
	let username = req.query.userName;
	console.log('sos: ', username);  
    //let name = req.query.name; 
    connection.query("SELECT * FROM user  WHERE name = ? ", [username], function(error, results, fields) {  
        if (error) {  
            throw error;  
        }  
        console.log('The solution is: ', results);  
        res.json(results);  
    });  
});
router.get("/mmmm1", function(req, res, next) {  
    // 假设您从查询字符串中获取了一个名为"name"的参数  
	let username = req.query.username;
	console.log('sos: ', username);  
    //let name = req.query.name; 
    connection.query("SELECT * FROM user  WHERE name = ? ", [username], function(error, results, fields) {  
        if (error) {  
            throw error;  
        }  
        console.log('The solution is: ', results);  
        res.json(results);  
    });  
});

router.get("/test", function(req, res, next) {  
    // 假设您从查询字符串中获取了一个名为"city"的参数  
    let city = req.query.city; 
    connection.query("SELECT * FROM Consultant WHERE city = ?", [city], function(error, results, fields) {  
        if (error) {  
            throw error;  
        }  
        console.log('The solution is: ', results);  
        res.json(results);  
    });  
});

router.get("/test2", function(req, res, next) {  
    // 假设您从查询字符串中获取了一个名为"name"的参数  
    let name1 = req.query.name1; 
    connection.query("SELECT * FROM predecide WHERE price = ?", [name1], function(error, results, fields) {  
        if (error) {  
            throw error;  
        }  
        console.log('The solution is: ', results);  
        res.json(results);  
    });  
});

router.get("/test3", function(req, res, next) {  
    // 假设您从查询字符串中获取了一个名为"item"的参数  
    let item = req.query.item; 
    connection.query("SELECT * FROM Consultant WHERE skilled_field = ?", [item], function(error, results, fields) {  
        if (error) {  
            throw error;  
        }  
        console.log('The solution is: ', results);  
        res.json(results);  
    });  
});

router.get("/test4", function(req, res, next) {  
    let rawDatetimerange = req.query.datetimerange;  
    try {  
        let datetimerangeArray = JSON.parse(rawDatetimerange);  
        if (datetimerangeArray.length !== 2) {  
            throw new Error('Invalid date range format');  
        }  
        let startDate = datetimerangeArray[0];  
        let endDate = datetimerangeArray[1];    
        connection.query("SELECT * FROM predecide WHERE begin_time BETWEEN ? AND ?", [startDate, endDate], function(error, results, fields) {  
            if (error) {  
                next(error); 
            }  
            console.log('The solution is: ', results);  
            res.json(results);  
        });  
    } catch (e) {  
        res.status(400).send('Invalid date range format');  
    }  
});

router.get("/combined-search", function(req, res, next) {  
    let city = req.query.city;  
    let name1 = req.query.name1;  
    let item = req.query.item;  
    let rawDatetimerange = req.query.datetimerange;  
    let conditions = [];  
    let queryParams = [];  
  
    if (city) {  
        conditions.push("consultant.city = ?");  
        queryParams.push(city);  
    }  
  
    if (name1) {  
        conditions.push("production.price = ?");  
        queryParams.push(name1);   
    } 
	 if (item) {  
	         // 确保item不为空或null，并为其两侧添加%作为通配符  
	         let searchTerm = '%' + item + '%';  
	         // 向conditions数组中添加LIKE条件  
	         conditions.push("consultant.strength LIKE ?");  
	         // 将处理后的searchTerm添加到queryParams数组中  
	         queryParams.push(searchTerm);  
	     }
    if (rawDatetimerange) {  
        try {  
            let datetimerangeArray = JSON.parse(rawDatetimerange);  
            if (datetimerangeArray.length !== 2) {  
                throw new Error('Invalid date range format');  
            }  
            let startDate = datetimerangeArray[0];  
            let endDate = datetimerangeArray[1];  
            conditions.push("production.start_time BETWEEN ? AND ?");  
            queryParams.push(startDate, endDate);  
            // 同样，这里混合了两个表，可能需要更复杂的查询逻辑  
        } catch (e) {  
            return res.status(400).send('Invalid date range format');  
        }  
    }  
  
    let query = "SELECT * FROM consultant";  
    if (conditions.some(cond => cond.includes('production'))) {  
        query += " JOIN production ON consultant.id = production.c_id ";  
    }  
  
    if (conditions.length > 0) {  
        query += " where " + conditions.join(' OR ');  
    }  
  if (conditions.some(cond => cond.includes('production'))) {
      query += " and production.is_appointed=0 and consultant.certificationStatus='已认证'";  
  }  
    connection.query(query, queryParams, function(error, results, fields) { 
		console.log(error,results)
        if (error) {  
            next(error); 
			 return;
        }  
        res.json(results);  
    });  
});

router.get("/combined-search1", function(req, res, next) {  
    let city = req.query.city;  
    let name1 = req.query.name1;  
    let item = req.query.item;  
    let rawDatetimerange = req.query.datetimerange;  
    let conditions = [];  
    let queryParams = [];  
  
    if (city) {  
        conditions.push("consultant.city = ?");  
        queryParams.push(city);  
    }  
  
    if (name1) {  
        conditions.push("production.price = ?");  
        queryParams.push(name1);   
    }  
    if (item) {  
        conditions.push("consultant.strength = ?");  
        queryParams.push(item);  
    }  
    if (rawDatetimerange) {  
        try {  
            let datetimerangeArray = JSON.parse(rawDatetimerange);  
            if (datetimerangeArray.length !== 2) {  
                throw new Error('Invalid date range format');  
            }  
            let startDate = datetimerangeArray[0];  
            let endDate = datetimerangeArray[1];  
            conditions.push("production.start_time BETWEEN ? AND ?");  
            queryParams.push(startDate, endDate);  
            // 同样，这里混合了两个表，可能需要更复杂的查询逻辑  
        } catch (e) {  
            return res.status(400).send('Invalid date range format');  
        }  
    }  
  
    let query = "SELECT * FROM consultant";  
    if (conditions.some(cond => cond.includes('production'))) {  
        query += " JOIN production ON consultant.id = production.c_id ";  
    }  
  
    if (conditions.length > 0) {  
        query += " where " + conditions.join(' OR ');  
    }  
  if (conditions.some(cond => cond.includes('production'))) {
      query += " and production.is_appointed=0 ";  
  }  
    connection.query(query, queryParams, function(error, results, fields) { 
		console.log(error,results)
        if (error) {  
            next(error); 
			 return;
        }  
        res.json(results);  
    });  
});


router.get("/test00", function(req, res, next) {  
    let name111 = req.query.name111;
	let type1=req.query.type1;
	let shijian1=req.query.shijian1;
	let shijian11=req.query.shijian11;
	console.log('sos: ', name111);  
    let query = "SELECT * FROM consultant JOIN production ON consultant.id = production.c_id WHERE production.is_appointed=0 and consultant.trueName = ? and production.consult_way=? and production.start_time=? and production.finish_time=?";  
     connection.query(query, [name111,type1,shijian1,shijian11], function(error, results, fields) {   
        if (error) {  
            console.error(error);  
            return res.status(500).send('Database error');   
        }  
        console.log('The solution is: ', results);  
        if (results.length > 0) {  
            res.json(results[0]); 
        } else {  
            res.json({ message: 'No data found' });  
        }  
    });  
});
router.get("/test000", function(req, res, next) {  
    let shijian = req.query.shijian;  
	console.log('sos: ', shijian);  
    let query = "SELECT * FROM consultant JOIN production ON consultant.id = production.c_id WHERE production.is_appointed=0 and production.start_time = ?";  
     connection.query(query, [shijian], function(error, results, fields) {   
        if (error) {  
            console.error(error);  
            return res.status(500).send('Database error');   
        }  
        console.log('The solution is: ', results);  
        if (results.length > 0) {  
            res.json(results[0]); 
        } else {  
            res.json({ message: 'No data found' });  
        }  
    });  
});


router.post("/ssss", function(req, res, next) {  
    // 从请求体中获取数据  
    const { u_id,c_id,p_id,create_time,nowstate,consult_way } = req.body; // 确保你的前端发送了这些字段  
  
    // 构建SQL语句（注意：这里使用了占位符来防止SQL注入）  
    const sql = "INSERT INTO appointment (u_id,c_id,p_id,create_time,state,consult_way) VALUES (?,?,?,?,?,?)";  
  
    // 执行SQL语句  
    connection.query(sql, [u_id,c_id,p_id,create_time,nowstate,consult_way], function(error, results, fields) {  
        if (error) {  
            return res.status(500).send(error.message);  
        }  
        res.status(200).send("Data inserted successfully");  
    });  
});




router.get("/certification", function(req, res, next) {  
    
    let c_id = req.query.c_id;
    console.log('sos: ', c_id);  
    
    connection.query("SELECT * FROM  apply  WHERE   apply.a_state='已审批' and apply.c_id = ? ", [c_id], function(error, results, fields) {  
        if (error) {  
            throw error;  
        }  
        console.log('The solution is: ', results);  
        res.json(results);  
    });  
});

router.get("/score", function(req, res, next) {  
    
	let c_id = req.query.c_id;
	console.log('sos: ', c_id);  
    
    connection.query("SELECT * FROM comment  WHERE c_id = ? ", [c_id], function(error, results, fields) {  
        if (error) {  
            throw error;  
        }  
        console.log('The solution is: ', results);  
        res.json(results);  
    });  
});
router.post("/send", function(req, res, next) {  
    const { u_id,messageContent } = req.body;    
    const sql = "INSERT INTO treehole (u_id,send,state) VALUES (?,?,0)";
  
   
    connection.query(sql, [ u_id,messageContent ], function(error, results, fields) {  
        if (error) {  
            return res.status(500).send(error.message);  
        }  
        res.status(200).send("Data inserted successfully");  
    });  
});
router.get("/receive", function(req, res, next) {  
    // 假设您从查询字符串中获取了一个名为"name"的参数  
	let u_id = req.query.u_id;
	console.log('sos: ', u_id);  
    //let name = req.query.name; 
    connection.query("SELECT * FROM treehole  WHERE u_id = ? ", [u_id], function(error, results, fields) {  
        if (error) {  
            throw error;  
        }  
        console.log('The solution is: ', results);  
        res.json(results);  
    });  
});
router.get("/hassent", function(req, res, next) {  
    // 假设您从查询字符串中获取了一个名为"name"的参数  
	let u_id = req.query.u_id;
	console.log('sos: ', u_id);  
    //let name = req.query.name; 
    connection.query("SELECT * FROM treehole  WHERE u_id = ? ", [u_id], function(error, results, fields) {  
        if (error) {  
            throw error;  
        }  
        console.log('The solution is: ', results);  
        res.json(results);  
    });  
});

router.post("/llll", function(req, res, next) {  
    const { u_id,login_time,device } = req.body;    
    const sql = "INSERT INTO loginmessage (ip,device,u_id,login_time) VALUES (?,?,?,?)";  
    connection.query(sql, [ '192.168.1.11',device,u_id,login_time], function(error, results, fields) {  
        if (error) {  
			console.error(error);
            return res.status(500).send(error.message);  
        }  
        res.status(200).send("Data inserted successfully");  
    });  
});



module.exports = router;