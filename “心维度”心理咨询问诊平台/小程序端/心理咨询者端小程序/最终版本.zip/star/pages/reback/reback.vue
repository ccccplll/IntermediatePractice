<template>
  <view class="container">
    <view class="form-group">
      <label>退款原因</label>
      <textarea v-model="reason" placeholder="请输入退款原因"></textarea>
    </view>
    <view class="button-group">
      <button form-type="submit" @click="formSubmit">提交</button>
      <button form-type="reset" @click="formReset">重置</button>
    </view>
  </view>
</template>

<script>
export default {
  onLoad(option) {
    console.log(option);
    this.id = option.id;
    this.fetchId();
  },
  data() {
    return {
      id: '',
      reason: '',
      u_id: '',
    };
  },
  methods: {
    fetchId() {
      let that = this;
      uni.request({
        url: 'http://localhost:3000/selectInfor',
        method: 'GET',
        data: { name: getApp().globalData.userName },
        success: (res) => {
          //console.log(res);
          that.u_id = res.data[0].id;
        },
        fail: (err) => {
          console.log(err);
        }
      });
    },
    formSubmit(e) {
      this.sendDataToServer(); // 发送数据到服务器  
      this.sendApplyToServer();
    },
    sendDataToServer() {
      console.log(this.id);
      uni.request({
        url: 'http://localhost:3000/setState',
        method: 'POST',
        data: { id: this.id },
        success: (res) => {
          console.log(res);
          uni.showToast({
            title: '提交成功',
            icon: 'success',
            duration: 1000
          });
          uni.$emit('orderStatusChanged');
          uni.navigateBack(1);
        },
        fail: (err) => {
          console.log(err);
          uni.showToast({
            title: '提交失败',
            icon: 'none',
            duration: 1000
          });
        }
      });
    },
    sendApplyToServer() {
      uni.request({
        url: 'http://localhost:3000/insertRefundApply',
        method: 'POST',
        data: {
          a_id: this.id,
          u_id: this.u_id,
          context: this.reason,
          state: '待审核',
          submit_time: this.formatDate(new Date()),
        },
        success: (res) => {
          console.log(res);
        },
        fail: (err) => {
          console.log(err);
        }
      });
    },
    formatDate(date) {
      const pad = (n) => n < 10 ? '0' + n : n;
      return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())} ${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
    },
    formReset() {
      console.log('执行退出登录操作');
      this.reason = '';
    },
  }
};
</script>

<style lang="scss">
.container {
  padding: 20px;
  background-color: #ffffff;
  border-radius: 10px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  max-width: 500px;
  margin: 20px auto;
  font-family: 'Arial', sans-serif;
}

.form-group {
  margin-bottom: 20px;
}

label {
  display: block;
  font-size: 18px;
  margin-bottom: 10px;
  color: #333;
}

textarea {
  width: 100%;
  height: 75vh;
  padding: 15px;
  border: 1px solid #ccc;
  border-radius: 5px;
  font-size: 16px;
  resize: none;
  box-sizing: border-box;
}

.button-group {
  display: flex;
  justify-content: space-between;
}

button {
  padding: 12px 25px;
  border: none;
  border-radius: 5px;
  background-color: #007aff;
  color: #fff;
  font-size: 16px;
  cursor: pointer;
  transition: background-color 0.3s, transform 0.1s;
}

button:hover {
  background-color: #005bb5;
}

button:active {
  transform: scale(0.98);
}

button[form-type="reset"] {
  background-color: #f44336;
}

button[form-type="reset"]:hover {
  background-color: #d32f2f;
}
</style>

