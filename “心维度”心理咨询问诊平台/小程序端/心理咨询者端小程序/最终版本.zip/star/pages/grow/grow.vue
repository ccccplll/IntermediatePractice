<template>
  <div class="chatbot-container">
    <h1>ChatBot</h1>
    <div class="chat-window">
      <div v-for="(message, index) in messages" :key="index" class="message">
        {{ message }}
      </div>
    </div>
	<div class="but">
		<input
		  v-model="inputValue"
		  @keyup.enter="sendMessage"
		  placeholder="输入消息"
		  class="input-box"
		/>
		<button @click="sendMessage" class="send-button">发送</button>
	</div>
  </div>
</template>

<script>
import { ref, onMounted } from 'vue';
import axios from 'axios';

export default {
  name: 'ChatBot',
  data() {
    return {
      messages: [],
      inputValue: '',
      accessToken: '',
      baseUrl: "https://aip.baidubce.com",
    };
  },
  mounted() {
    this.getToken();
  },
  methods: {
    getToken() {
      const apiKey = '0n2yNci6dPjyWXiuJUQVmYHV'; // 替换为实际的API Key
      const secretKey = 'jwF4FOi9HlRL56E4H2ID3d8WbHJHeUNF'; // 替换为实际的Secret Key
      const urlToken = `/oauth/2.0/token?client_id=${apiKey}&client_secret=${secretKey}&grant_type=client_credentials`;

      uni.request({
        url: this.baseUrl + urlToken,
        method: 'POST',
        header: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        success: (res) => {
          this.accessToken = res.data.access_token;
        },
        fail: (err) => {
          console.error('获取Token失败', err);
        }
      });
    },
    sendMessage() {
      if (this.inputValue.trim() === '') return;

      const userMessage = `用户: ${this.inputValue}`;
      this.messages.push(userMessage);

      const urlChat = `/rpc/2.0/ai_custom/v1/wenxinworkshop/chat/completions?access_token=${this.accessToken}`;
      const payload = {
        messages: [
          {
            role: 'user',
            content: this.inputValue
          }
        ]
      };

      uni.request({
        url: this.baseUrl + urlChat,
        method: 'POST',
        data: payload,
        header: {
          'Content-Type': 'application/json'
        },
        success: (res) => {
          console.log('API 响应数据:', res.data);
          console.log(res.data);
          if (res.data.result && res.data.result.length > 0) {
            const botResponse = `weHerat: ${res.data.result}`;
            this.messages.push(botResponse);
          } else {
            console.error('未找到有效的机器人响应');
          }
          this.inputValue = '';
        },
        fail: (err) => {
          console.error('请求失败', err);
        }
      });
    }
  }
};
</script>

<style lang="scss" scoped>
.chatbot-container {
  height: 100vh;
  max-width: 400px;
  margin: 0 auto;
  padding: 20px;
  background-color: #fff;
  border: 1px solid #ccc;
  border-radius: 5px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.chat-window {
  height: 600px;
  border: 1px solid #ccc;
  padding: 10px;
  overflow-y: scroll;
  margin-bottom: 10px;
}

.but{
	display: flex;
	flex-direction: row;
}

.message {
  margin-bottom: 10px;
  padding: 5px 10px;
  background-color: #fff;
  border-radius: 3px;
  box-shadow: 0 2px 2px rgba(0, 0, 0, 0.1);
}

.input-box {
  width: calc(100% - 82px);
  padding: 10px;
  margin-bottom: 10px;
  border: 1px solid #ccc;
  border-radius: 3px;
}

.send-button {
  width: 70px;
  //padding: 10px;
  height: 50px;
  background-color: #007bff;
  color: #fff;
  border: none;
  border-radius: 3px;
  cursor: pointer;
}

.send-button:hover {
  background-color: #0056b3;
}
</style>
