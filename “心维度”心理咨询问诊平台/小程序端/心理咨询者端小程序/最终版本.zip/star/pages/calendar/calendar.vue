<template>
    <view class="body">
	  <view class="father">
		<view class="test">
		 <uni-search-bar @confirm="search" :focus="true" v-model="name">
		           </uni-search-bar>
       	</view>
       	    <button class="test0" @click="search" >搜索</button>  
      </view>
      <!-- #ifndef MP-ALIPAY -->
      <view class="uni-list1" >
      		<view class="uni-list-cell-db"  >
      			<picker mode="multiSelector" @columnchange="bindMultiPickerColumnChange" :value="multiIndex" :range="multiArray" >
      				<view class="uni-input">{{multiArray[1][multiIndex[1]]}} {{multiArray[2][multiIndex[2]]}} </view>
				</picker>
      		</view>
			
			
			 
			<view class="uni-list-cell-right">
				<picker @change="bindPickerChange" :value="index" :range="array" range-key="name1">
					<view class="uni-input">{{array[index].name1}}</view>
				</picker>
			</view>
			
      </view>
      <!-- #endif -->
	  <view class="uni-list">
	  	<checkbox-group @change="checkboxChange">
	  		<label class="uni-list-cell uni-list-cell-pd" v-for="item in items" :key="item.value">
	  			<view>
	  				<checkbox :value="item.value" :checked="item.checked" />
	  			</view>
	  			<view>{{item.name}}</view>
	  		</label>
	  	</checkbox-group>
	  </view>
		
		<view class="uni-select-cy" :style="{ 'z-index': zindex }">
		  <view class="uni-select-cy-select" :class="{ active: active }" @click.stop="handleSelect">
		    <!-- 禁用mask -->
		    <view class="uni-disabled" v-if="disabled"></view>
		    <!-- 清空 -->
		    <view class="close-icon close-postion" v-if="realValue.length && !active && !disabled && showClearIcon">
		      <text @click.stop="handleRemove(null)"></text>
		    </view>
		    <!-- 显示框 -->
		    <view class="uni-select-multiple" v-show="realValue.length">
		      <view class="uni-select-multiple-item" v-for="(item, index) in realValue" :key="index">
		        {{ item }}
		        <view class="close-icon" v-if="showValueClear"><text @click.stop="handleRemove(index)"></text> </view>
		      </view>
		    </view>
		    <!-- 为空时的显示文案 -->
		    <view v-if="realValue.length == 0 && showplaceholder">{{ placeholder }}</view>
		    <!-- 禁用图标 -->
		    <view class="uni-select-cy-icon" :class="{ disabled: disabled }"><text></text></view>
		  </view>
		  <!-- 下拉选项 -->
		  <scroll-view class="uni-select-cy-options" :scroll-y="true" v-show="active">
		    <template>
		      <view
		        class="uni-select-cy-item"
		         :class="{ active: realValue.includes(item[svalue]) }"
		        v-for="(item, index) in options"
		        :key="index"
		        @click.stop="handleChange(index, item)"
		      >
		        {{item}}
		      </view>
		    </template>
		  </scroll-view>
		</view>
		
		<view class="pagecontainer">
			<view class="example-body1">
				<uni-datetime-picker v-model="datetimerange" type="datetimerange" rangeSeparator="至" />
			</view>
			 <button class="test1" @click="all">筛选</button>  
		</view>
		
    </view>
	
	<scroll-view :scroll-top="screenTop" 
	  scroll-y class="scroll-y" @scrolltoupper="upper" @scrolltolower="lower" @scroll="scroll" >
	  <view>  
	      <view v-for="(consultant, index) in consultants" :key="index" class="scroll-view-item" @click="consultantInformation(consultant)">  
	        <view class="botton-top">  
	          <view class="touxiang">  
	            <image :src="consultant.imageUrl"></image>  
	          </view>  
	          <view class="right">  
	            <view class="name">{{ consultant.name }}</view>  
	            <view class="time">{{ consultant.experience }}</view> 
				  <text class="size1">{{consultant.shijian1}} {{consultant.shijian11}}</text>
	            <view class="introduce-view">  
	              <view class="introduce">{{ consultant.introduce }}</view>  
	            </view>  
	            <view class="taf">  
	              <view class="price">{{ consultant.price }}</view>  
	              <view class="function">{{ consultant.type }}</view>  
	            </view>  
	          </view>  
	        </view>  
	        <view class="address">{{ consultant.city }}</view>  
	      </view>  
	    </view>  		
	        </scroll-view>
</template>


<script>
	 import moment from 'moment';   
   export default {
	 
	   name: 'select-cy',
	   props: {
	     // 是否显示全部清空按钮
	     showClearIcon: {
	       type: Boolean,
	       default: true,
	     },
	     // 是否显示单个删除
	     showValueClear: {
	       type: Boolean,
	       default: true,
	     },
	     zindex: {
	       type: Number,
	       default: 999,
	     },
	     // 禁用组件
	     disabled: {
	       type: Boolean,
	       default: false,
	     },
	     value: {
	       type: Array,
	       default() {
	         return [];
	       },
	     },
	     placeholder: {
	       type: String,
	       default: '请选择你的困扰',
	     },
	     showplaceholder: {
	       type: Boolean,
	       default: true,
	     },
	     slabel: {
	       type: String,
	   	  default() {
	   	   return [];
	   	  },
	     },
	     svalue: {
	       type: String,
	   	 default() {
	   	   return [];
	   	 },
	     },
	   },
   	data() {
   		return {
			consultants: [],
			
			name1:'',
			array: [{name1:'价格/时'},{name1: '100.00'},{name1: '200.00'},{name1: '300.00'},{name1: '400.00'},{name1: '500.00'}, {name1: '600.00'},{name1:'700.00'}, {name1: '800.00'},{name1:'900.00'},{name1:'1000.00'}],
			index: 0,
			
			city:'',
			 multiArray: [  
			            ['中国'],  
			            ['省份','湖北', '山东','北京','天津','上海','河北','山西','辽宁','吉林','黑龙江','江苏','浙江','安徽','福建','江西','河南','湖南','广东','广西','海南','四川','重庆','贵州','云南','西藏','陕西','甘肃','青海','宁夏','新疆','香港','澳门','台湾'], // 假设这是初始的省份列表  
			            [] // 初始时城市为空，稍后根据省份选择填充  
			        ],  
			        multiIndex: [0, 0, 0],  
			        citiesByProvince: { // 预定义的城市列表，按省份分组  
			            '湖北': ['武汉', '黄冈', '襄阳','黄石','荆州','宜昌','孝感','恩施'],  
			            '山东': ['济南', '青岛', '烟台','淄博','菏泽','枣庄','潍坊','济宁'],  
			             '北京': ['北京'],  
			             '天津': ['天津'],   
			             '上海': ['上海'],   
			             '河北': ['石家庄', '唐山', '保定', '邯郸'],  
			             '山西': ['太原', '大同', '长治', '运城'],  
			             '辽宁': ['沈阳', '大连', '鞍山', '抚顺'],  
			             '吉林': ['长春', '吉林', '四平', '通化'],  
			             '黑龙江': ['哈尔滨', '齐齐哈尔', '大庆', '牡丹江'],  
			             '江苏': ['南京', '苏州', '无锡', '常州'],  
			             '浙江': ['杭州', '宁波', '温州', '绍兴'],  
			             '安徽': ['合肥', '芜湖', '马鞍山', '安庆'],  
			             '福建': ['福州', '厦门', '泉州', '漳州'],  
			             '江西': ['南昌', '九江', '赣州', '上饶'],   
			             '河南': ['郑州', '洛阳', '开封', '许昌'],  
			             '湖南': ['长沙', '株洲', '湘潭', '衡阳'],  
			             '广东': ['广州', '深圳', '珠海', '东莞', '佛山'],  
			             '广西': ['南宁', '柳州', '桂林', '北海'],  
			             '海南': ['海口', '三亚'],  
			             '四川': ['成都', '绵阳', '德阳', '宜宾'],  
			             '重庆': ['重庆'],   
			             '贵州': ['贵阳', '遵义', '安顺', '毕节'],  
			             '云南': ['昆明', '大理', '丽江', '西双版纳'],   
			             '西藏': ['拉萨', '日喀则', '林芝'],   
			             '陕西': ['西安', '宝鸡', '咸阳', '渭南'],  
			             '甘肃': ['兰州', '天水', '嘉峪关', '张掖'],  
			             '青海': ['西宁', '海东'],  
			             '宁夏': ['银川', '石嘴山', '吴忠'],  
			             '新疆': ['乌鲁木齐', '喀什', '伊犁', '和田'],  
			             '香港': ['香港'],  
			             '澳门': ['澳门'],
						 '台湾': ['台北']
			        },
			
			datetimesingle: '',
			datetimerange: [],
			start: Date.now() - 1000000000,
			end: Date.now() + 1000000000,
			
			searchValue: '',
			
			active: true, // 组件是否激活，
			changevalue: [], // 搜索框同步
			realValue: [],
			options:['心理健康','学业发展','职场相关','人际关系','睡眠问题','情感障碍','家庭暴力','完美主义','成长创伤'],
			item:'',
			
   		}
   	},
	mounted() {
	  // 初始化
	  this.init();
	},
	watch: {
		datetimerange(newval) {
			console.log('范围选:', this.datetimerange);
		}
	},
	mounted() {
		setTimeout(() => {
			this.datetimesingle = Date.now() - 2*24*3600*1000
			this.datetimerange = ["2024-07-08 0:00:00", "2024-7-30 23:59:59"]
		},3000)
	},
	
   	methods: {
		consultantInformation(consultant){
			uni.navigateTo({  
			    url : `../consultant/consultant?message=${consultant.name}&type=${consultant.type}&shijian1=${consultant.shijian1}&shijian11=${consultant.shijian11}`
			});    
		},
		
		
		
		search() {
		 uni.navigateTo({
		    url: '../search/search?name=' +this.name
		  });  
		},
		
		
		search1() {
		 uni.request({
		 url: "http://localhost:3000/test",
		 method: 'get',
		 data:{
		  city:this.multiArray[2][this.multiIndex[2]]
		 },
		 success: res => {
		 this.city=this.multiArray[2][this.multiIndex[2]];
		 console.log('数据搜索成功',res.data);
		 console.log(this.multiArray[2][this.multiIndex[2]]);
			}
			})
		},
		
		search2() {
		 uni.request({
		 url: "http://localhost:3000/test2",
		 method: 'get',
		 data:{
		  index:this.index,
		  name1:this.array[this.index].name1
		 },
		 success: res => {
		 console.log('数据搜索成功',res.data);
		 console.log(this.name1);
			}
			})
		},
		
		search3() {
		 uni.request({
		 url: "http://localhost:3000/test3",
		 method: 'get',
		 data:{
		   item:this.realValue[0]
		 },
		 success: res => {
		 console.log('数据搜索成功',res.data);
		 console.log(this.item);
			}
			})
		},
		
		
		search4() {
		 uni.request({
		 url: "http://localhost:3000/test4",
		 method: 'get',
		 data:{
		  datetimerange:this.datetimerange
		 },
		 success: res => {
		 console.log('数据搜索成功',res.data);
		 console.log(this.datetimerange);
			}
			})
		},
		
		
		
		all() {
		 uni.request({
		 url: "http://localhost:3000/combined-search",
		 method: 'get',
		 data:{
		  city:this.multiArray[2][this.multiIndex[2]],
		  index:this.index,
		  name1:this.array[this.index].name1,
		  item:this.realValue[0],
		  datetimerange:this.datetimerange
		 },
		 success: res => {
		 if (res.data && Array.isArray(res.data)) {  
		             this.consultants = res.data.map(item => ({  
		               imageUrl: item.avatar || '',  
		               name: item.trueName || '',  
		               experience: (item.accumulatedHour || 0) + '小时经验',  
		               introduce: item.introduction || '',  
		               price: (item.price || 0) + '元/时',  
		               type: item.consult_way || '',  
		               city: item.city || '',
					   shijian1 :moment(item.start_time).format('YYYY-MM-DD HH:mm:ss') || '',
					   shijian11:moment(item.finish_time).format('YYYY-MM-DD HH:mm:ss') || ''
		             }));  
		           }
		 console.log('数据搜索成功',res.data);
		 
			}
			})
		},
			
		
		
   		bindPickerChange: function(e) {
   			console.log('picker发送选择改变，携带值为：' + e.detail.value)
   			this.index = e.detail.value
			
			console.log('价格为：' +this.array[e.detail.value].name1);
   		},
   		
		 bindMultiPickerColumnChange: function(e) {  
		        console.log('修改的列为：' + e.detail.column + '，值为：' + e.detail.value);  
		        this.multiIndex[e.detail.column] = e.detail.value;  
		  
		        if (e.detail.column === 1) { // 当省份列变化时  
		            const selectedProvince = this.multiArray[1][this.multiIndex[1]];  
		            const cities = this.citiesByProvince[selectedProvince] || []; // 根据省份获取对应的城市列表  
		            this.multiArray[2] = [].concat(cities); // 更新城市列，先放一个'城市'标签，然后跟城市列表  
		        }   
		        console.log('更改后的城市为：' + (this.multiArray[2][this.multiIndex[2]] || '未选择'));  
		    } , 
		
		change(e) {
			this.single = e
			console.log('change事件:', this.single = e);
		},
		changeLog(e) {
			console.log('change事件:', e);
		},
		maskClick(e){
			console.log('maskClick事件:', e);
		},
		close() {
		  this.active = true;
		},
		init() {
		  if (this.value.length > 0) {
		    this.changevalue = this.options.forEach((item) => {
		      this.value.forEach((i) => {
		        if (item[this.svalue] === i[this.svalue]) {
		          return item;
		        }
		      });
		    });
		    this.realValue = this.value;
		  } else {
		    this.changevalue = [];
		    this.realValue = [];
		  }
		},
		// 点击展示选项
		handleSelect() {
		  if (this.disabled) return;
		  this.active = !this.active;
		},
		// 移除数据
		handleRemove(index) {
		  if (index === null) {
		    this.realValue = [];
		    this.changevalue = [];
		  } else {
		    this.realValue.splice(index, 1);
		    this.changevalue.splice(index, 1);
		  }
		  this.$emit('change', this.changevalue, this.realValue);
		},
		// 点击组件列
		handleChange(index, item) {
		    this.realValue.push(item);
		},
		
   	}
	
   }
</script>

<style lang="scss" scoped>
	
	.scroll-Y {
	            height: 300rpx;
	    }
	    
	    .scroll-view-item {
	        height: 300rpx;
	        display: flex;
	        flex-direction: column;
	        border: 1rpx solid gainsboro;
	        &:last-child{border-bottom: 0;}
	        .botton-top{
	            width: 100%;
	            height: 258rpx;
	            display: flex;
	            flex-direction: row;
	            align-items: center;
	            //border: 1rpx solid skyblue;
	            .touxiang{
	                width: 160rpx;
	                height: 160rpx;
	                border-radius: 100%;
	                overflow: hidden;
	                margin: 25rpx;
	                //border: 1rpx solid skyblue;
	                image{
	                    width: 100%;
	                    height: 100%;
	                }
	            }
	            .right{
	                display: flex;
	                flex-direction: column;
	                align-items: flex-start;
	                height: 218rpx;
	                padding-top: 25rpx;
	                //border: 1rpx solid skyblue;
	                .name{
	                    padding: 5rpx;
	                    font-size: 40rpx;
	                    //border: 1rpx solid skyblue;
	                }
	                .time{
	                    padding: 5rpx;
	                    font-size: 28rpx;
	                    //border: 1rpx solid skyblue;
	                }
	                .introduce-view{
	                    padding: 5rpx;
	                    //font-size: 30rpx;
	                    overflow: hidden;
	                    white-space: nowrap;
	                    text-overflow: ellipsis;
	                    width: 200px;
	                    //border: 1rpx solid skyblue;
	                    .intriduce{
	                        font-size: 30rpx;
	                    }
	                }
	                .taf{
	                    padding: 5rpx;
	                    display: flex;
	                    flex-direction: row;
	                    align-items: center;
	                    justify-content: space-between;
	                    width: 130px;
	                    //border: 1rpx solid skyblue;
	                    .price{
	                        font-size: 28rpx;
	                        text-align: right;
	                        //border: 1rpx solid skyblue;
	                    }
	                    .function{
	                        font-size: 28rpx;
	                        text-align: right;
	                        //border: 1rpx solid skyblue;
	                    }
	                }
	            }
	        }
	        
	        .address{
	            //border: 1rpx solid skyblue;
	            font-size: 30rpx;
	            text-align: right;
	            padding: 6rpx;
	        }
	    }
	
.father{
	display:flex;
	align-items: center;
	justify-content: center;
}
.test{
	width:83%;
}
.test0{
	height:65rpx;
	display: flex;
	width:19%;
	font-size: 14;
	color: #7a7474;
	background-color: #fff;
	justify-content: center;
	align-items: center;
	margin-right: 2.5%;
}
.test1{
	height:65rpx;
	display: flex;
	width:19%;
	font-size: 14;
	color: #7a7474;
	background-color: #fff;
	justify-content: center;
	margin-top: 2%;
	align-items: center;
	margin-right: 2.5%;
}
.search{
  
  height:100rpx;
  display:flex;
  align-items: center;
  justify-content: center;
}
.search-input{
  height:80rpx;
  background-color: #f3f3f3;
  width:90%;
  border-radius: 40rpx;
  color: #000;
  position: relative;
  display: flex;
  align-items: center;
}
.search-content{
  position:absolute;
  left:50%;
  transform: translateX(-50%);
  display: flex;
  align-items: center;
}
.search-content image{
  width:30rpx;
  height:30rpx;
}
.uni-picker-tips {
	font-size: 12px;
	color: #666;
	margin-bottom: 15px;
	padding: 0 15px;
	/* text-align: right; */
}
.uni-list1{
			display:flex;
			//justify-content: space-around;
			flex-direction: row;
			align-items: center;
			margin-top: 2%;
			margin-bottom: 4%;
			height: 40%;
		}
.uni-list-cell-db{
	border: 1px solid #dbdbdb;
	width: 40%;
	border-radius: 8rpx;
	margin-right: 14%;
	margin-left: 2.5%;
	
}
.uni-list-cell-right{
	border: 1px solid #dbdbdb;
	width: 40%;
	border-radius: 8rpx;
	//margin-top: 2%;
	
}

.pagecontainer{
	display:flex;
	align-items: center;
	justify-content: center;
}
	

.example-body1{
	margin-top: 2%;
	background-color: #fff;
	padding: 10px;
	width:75%;
}
.uni-input{
	font-size: 16;
	color: #7a7474;
}

.search-result {
		padding-top: 10px;
		padding-bottom: 20px;
		text-align: center;
	}

	.search-result-text {
		text-align: center;
		font-size: 16;
		color:#666;
	}

	.example-body {
		/* #ifndef APP-NVUE */
		display: block;
		/* #endif */
		padding: 0px;
	}

	.uni-mt-10 {
		margin-top: 10px;
	}
	.uni-select-cy {
		margin-left: 2.5%;
		margin-right: 2.5%;
		//margin-bottom: 3%;
	  position: relative;
	  z-index: 999;
	  .uni-select-mask {
	    width: 100%;
	    height: 100%;
	  }
	  /* 删除按钮样式*/
	  .close-icon {
	    height: 100%;
	    width: 20px;
	    display: flex;
	    align-items: center;
	    justify-content: center;
	    z-index: 3;
	    cursor: pointer;
	    text {
	      position: relative;
	      background: #c0c4cc;
	      width: 13px;
	      height: 13px;
	      border-radius: 50%;
	      border: 1px solid #bbb;
	      &::before,
	      &::after {
	        content: '';
	        position: absolute;
	        left: 20%;
	        top: 50%;
	        height: 1px;
	        width: 60%;
	        transform: rotate(45deg);
	        background-color: #909399;
	      }
	      &::after {
	        transform: rotate(-45deg);
	      }
	    }
	  }
	  //所有情况的定位
	  .close-postion {
	    position: absolute;
	    right: 35px;
	    top: 0;
	    height: 100%;
	    width: 15px;
	  }
	  /* 多选盒子 */
	  .uni-select-multiple {
	    overflow-x: auto;
	    display: flex;
	    .uni-select-multiple-item {
	      background: #f4f4f5;
	      margin-right: 5px;
	      padding: 2px 4px;
	      border-radius: 4px;
	      color: #909399;
	      display: flex;
	    }
	  }
	  // select部分
	  .uni-select-cy-select {
	    user-select: none;
	    position: relative;
	    z-index: 3;
	    height: 36px;
	    padding: 0 30px 0 10px;
	    box-sizing: border-box;
	    border-radius: 4px;
	    border: 1px solid rgb(229, 229, 229);
	    display: flex;
	    align-items: center;
	    font-size: 14px;
	    color: #999;
	    .uni-disabled {
	      position: absolute;
	      left: 0;
	      width: 100%;
	      height: 100%;
	      z-index: 19;
	      cursor: no-drop;
	      background: rgba(255, 255, 255, 0.5);
	    }
	    .uni-select-cy-input {
	      font-size: 14px;
	      color: #999;
	      display: block;
	      width: 96%;
	      overflow: hidden;
	      text-overflow: ellipsis;
	      white-space: nowrap;
	      line-height: 30px;
	      box-sizing: border-box;
	      &.active {
	        color: #333;
	      }
	    }
		
	    .uni-select-cy-icon {
	      cursor: pointer;
	      position: absolute;
	      right: 0;
	      top: 0;
	      height: 100%;
	      width: 30px;
	      display: flex;
	      align-items: center;
	      justify-content: center;
	      &::before {
	        content: '';
	        width: 1px;
	        height: 100%;
	        position: absolute;
	        left: 0;
	        top: 0;
	        background-color: #e5e5e5;
	      }
	      text {
	        display: block;
	        width: 0;
	        height: 0;
	        border-width: 12rpx 12rpx 0;
	        border-style: solid;
	        border-color: #bbb transparent transparent;
	        transition: 0.3s;
	      }
	      &.disabled {
	        cursor: no-drop;
	        text {
	          width: 20rpx;
	          height: 20rpx;
	          border: 2px solid #ff0000;
	          border-radius: 50%;
	          transition: 0.3s;
	          position: relative;
	          z-index: 999;
	          &::after {
	            content: '';
	            position: absolute;
	            top: 50%;
	            left: 0;
	            width: 100%;
	            height: 2px;
	            margin-top: -1px;
	            background-color: #ff0000;
	            transform: rotate(45deg);
	          }
	        }
	      }
	    }
	    &.active .uni-select-cy-icon {
	      text {
	        transform: rotate(180deg);
	      }
	    }
	  }
	  // options部分
	  .uni-select-cy-options {
	    user-select: none;
	    position: absolute;
	    top: calc(100% + 5px);
	    left: 0;
	    width: 100%;
	    height: 500rpx;
	    border-radius: 4px;
	    border: 1px solid rgb(229, 229, 229);
	    background: #fff;
	    padding: 5px 0;
	    box-sizing: border-box;
	    z-index: 9;
	    .uni-select-cy-item {
	      padding: 0 10px;
	      box-sizing: border-box;
	      cursor: pointer;
	      line-height: 2.5;
	      transition: 0.3s;
	      font-size: 14px;
	      &.active {
	        color: #409eff;
	        background-color: #f5f7fa &hover {
	          color: #409eff;
	          background-color: #f5f7fa;
	        }
	      }
	      &:hover {
	        background-color: #f5f5f5;
	      }
	    }
	  }
	}
</style>