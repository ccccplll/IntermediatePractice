<template>
  <view class="container">
    <view class="order-info">
      <text class="title">订单信息</text>
      <view class="detail-item">
        <text>订单状态：</text>
        <text class="detail-value status unpaid">{{ order.status }}</text>
      </view>
      <view class="detail-item1">
        <text>咨询师：</text>
        <text class="detail-value1">{{ order.serverName }}</text>
		<button class="cButton" @click="consultant">kong</button>
      </view>
	  <view class="detail-item">
		<text>咨询师电话：</text>
		<text class="detail-value">{{ order.phone }}</text>
	  </view>
      <view class="detail-item">
        <text>费用：</text>
        <text class="detail-value price">{{ order.price }}</text>
      </view>
      <view class="detail-item">
        <text>服务时长：</text>
        <text class="detail-value">{{ order.time }}分钟</text>
      </view>
      <view class="detail-item2">
        <text class="server">服务时间：</text>
        <text class="detail-server">{{ order.startTime }} 至 {{ order.endTime }}</text>
      </view>
      <view class="detail-item">
        <text>订单编号：</text>
        <text class="detail-value">{{ id }}</text>
      </view>
      <button v-if="order.status === '待支付'" class="pay-button" @click="payOrder">立即支付</button>
	  <button v-if="order.status === '待完成'" class="pay-button" @click="makeCall">联系咨询师</button>
    </view>
  </view>
</template>

<script>
export default {
  data() {
    return {
      order: {},
      id: '',
	  p_id:'',
	  c_id:'',
    };
  },
  onLoad(option) {
    if (option.id) {
      this.id = option.id;
      this.fetchOrderDetails();
    }
  },
  methods: {
	makeCall() {
	  uni.showToast({
	  	title:'拨打电话中',
		icon:'loading',
		duration: 1000,
	  })
	  uni.getSetting({
	    success: (res) => {
	      if (res.authSetting['scope.makePhoneCall']) {
	        this.callNumber();
	      } else {
	        uni.authorize({
	          scope: 'scope.makePhoneCall',
	          success: () => {
	            this.callNumber();
	          },
	          fail: () => {
	            uni.openSetting({
	              success: (res) => {
	                if (res.authSetting['scope.makePhoneCall']) {
	                  this.callNumber();
	                } else {
	                  console.error('用户未授权拨打电话');
	                }
	              }
	            });
	          }
	        });
	      }
	    },
	    fail: (err) => {
	      console.error('获取设置失败：', err);
	    }
	  });
	},
	callNumber() {
	  uni.makePhoneCall({
		phoneNumber: this.order.phone,
		success: () => {
		  console.log('拨打电话成功！');
		},
		fail: (err) => {
		  console.error('拨打电话失败！', err);
		}
	  });
	},
	consultant(){
		uni.navigateTo({
			url:'/pages/indexConsultant/indexConsultant?id='+this.p_id,
		})
	},
    fetchOrderDetails() {
      uni.request({
        url: 'http://localhost:3000/getOrderDetails',
        method: 'GET',
        data: { id: this.id },
        success: (res) => {
          if (res.statusCode === 200 && res.data.length) {
            let time = res.data[0].time / 60;
            this.order = {
              status: res.data[0].state,
              serverName: res.data[0].trueName,
              price: res.data[0].price,
              time: time,
              startTime: this.formatDate(new Date(res.data[0].start_time)),
              endTime: this.formatDate(new Date(res.data[0].finish_time)),
              phone: res.data[0].phoneNumber,
            };
            this.p_id = res.data[0].p_id;
			this.c_id = res.data[0].id;
          } else {
            console.error('获取订单详情失败：', res);
          }
        },
        fail: (err) => {
          console.error('请求失败：', err);
        }
      });
    },
    formatDate(date) {
      const pad = (n) => n < 10 ? '0' + n : n;
      return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())} ${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
    },
    payOrder() {
        uni.showToast({
          title: '支付中...',
          icon: 'loading',
          duration: 2000
        });
        setTimeout(() => {
          // 模拟支付成功，更新订单状态
          uni.request({
            url: 'http://localhost:3000/payOrder',
            method: 'POST',
            data: {
              id: this.id,
              p_id: this.p_id,
			  c_id: this.c_id,
			  create_time: this.formatDate(new Date()),
            },
            success: (res) => {
              console.log('Server response:', res);
              if (res.statusCode === 200 && res.data.success) {
                uni.$emit('orderStatusChanged'); // 触发订单状态更新事件
                uni.showToast({ title: '支付成功', icon: 'success' });
				this.removeRed();
              } else {
                uni.showToast({ title: res.data.error || '支付失败', icon: 'error' });
              }
            },
            fail: (err) => {
              console.log(err);
              uni.showToast({ title: '支付失败', icon: 'error' });
            }
          });
        }, 2000);
      },
	  removeRed(){
			uni.request({
			  url: 'http://localhost:3000/updateSee',
			  method: 'POST',
			  data:{
				  c_id:this.c_id,
				  seeMessage:'已看过'
			  },
			  success: (res) => {
				console.log(res);
				},
				fail: (err) => {
				  console.log(err);
				}
			});
		},
    },
	mounted() {
	  if (this.id) {
	    this.fetchOrderDetails();
	  }
	  uni.$on('orderStatusChanged', this.fetchOrderDetails);
	},
	beforeDestroy() {
	  uni.$off('orderStatusChanged', this.fetchOrderDetails);
	}
};
</script>

<style lang="scss">
	.container {
	  padding: 0;
	  background-color: #f0f0f0;
	  font-family: 'Roboto', sans-serif;
	  width: 100vw;
	  height: 100vh;
	}
	
	.order-info {
	  margin: 10rpx;
	  background-color: #ffffff;
	  padding: 15px;
	  border-radius: 8px;
	  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
	  height: 95vh;
	}
	
	.title {
	  font-size: 20px;
	  font-weight: bold;
	  margin-bottom: 10px;
	  align-items: center;
	}
	
	.detail-item {
	  display: flex;
	  justify-content: space-between;
	  align-items: center;
	  margin: 20px 0;
	}
	
	.detail-item2{
		display: flex;
		flex-direction: column;
		margin: 20px 0;
	}
	
	.server{
		margin-bottom: 10px;
	}
	.detail-server{
		font-weight: bold;
		font-size: 14px;
		margin-left: 60rpx;
	}
	
	.detail-item1 {
	  display: flex;
	  justify-content: space-between;
	  align-items: center;
	  margin: 10px 0;
	  position: relative;
	}
	
	.detail-value {
	  font-weight: bold;
	  font-size: 16px;
	}
	
	.cButton {
	  position: absolute;
	  top: 0;
	  left: 0;
	  height: 100%;
	  width: 100%;
	  opacity: 0;
	  cursor: pointer;
	}
	
	.status.unpaid {
	  color: #ff4500;
	}
	
	.price {
	  color: #008000;
	}
	
	.pay-button {
	  margin-top: 80px;
	  background-color: #4caf50;
	  color: #ffffff;
	  border: none;
	  padding: 12px 24px;
	  font-size: 18px;
	  border-radius: 4px;
	  cursor: pointer;
	  transition: background-color 0.3s ease;
	}
	
	.pay-button:hover {
	  background-color: #45a049;
	}
	
</style>
