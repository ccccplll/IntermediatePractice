<template>
  <view class="container">
    <view class="topPage">发布帖子</view>
    <view class="top">
      <text class="topic">话题类型：</text>
      <view class="radio-group">
        <label class="radio-label" @click="selectOption('求助')">
          <view :class="['radio-circle', { 'radio-selected': radioValue === '求助' }]">
            <text class="radio-text">求助</text>
          </view>
        </label>
        <label class="radio-label" @click="selectOption('婚姻')">
          <view :class="['radio-circle', { 'radio-selected': radioValue === '婚姻' }]">
            <text class="radio-text">婚姻</text>
          </view>
        </label>
        <label class="radio-label" @click="selectOption('情感')">
          <view :class="['radio-circle', { 'radio-selected': radioValue === '情感' }]">
            <text class="radio-text">情感</text>
          </view>
        </label>
        <label class="radio-label" @click="selectOption('家庭')">
          <view :class="['radio-circle', { 'radio-selected': radioValue === '家庭' }]">
            <text class="radio-text">家庭</text>
          </view>
        </label>
        <label class="radio-label" @click="selectOption('校园')">
          <view :class="['radio-circle', { 'radio-selected': radioValue === '校园' }]">
            <text class="radio-text">校园</text>
          </view>
        </label>
      </view>
    </view>
    <view class="main-content">
      <view class="input-area">
        <textarea inputmode="text" class="input" maxlength="2000" placeholder="请输入" placeholder-class="inputtext" v-model="postContent" focus="true"></textarea>
      </view>
      <uni-file-picker limit="1" title="最多选择1张图片" @file-selected="handleFileSelected"></uni-file-picker>
      <image v-if="imageUrl" :src="imageUrl" class="uploaded-image"></image>
      <button class="publish-btn" @click="publishPost" :disabled="loading">发布帖子</button>
    </view>
  </view>
</template>

<script>
import { pathToBase64, base64ToPath } from '../../js_sdk/mmmm-image-tools/index.js';

export default {
  data() {
    return {
      radioValue: '求助', // 默认选中的值
      postContent: '', // 信息
      selectedFile: null, // 选中的文件
      imageUrl: '', // 上传的图片 URL
      id: '',
      loading: false // 添加 loading 状态
    };
  },
  async onLoad() {
    await this.fetchId();
  },
  methods: {
    async fetchId() {
      try {
        const res = await uni.request({
          url: 'http://localhost:3000/selectInfor',
          method: 'GET',
          data: { name: getApp().globalData.userName }
        });
        this.id = res.data[0].id;
      } catch (err) {
        console.log(err);
      }
    },
    selectOption(value) {
      this.radioValue = value;
    },
    handleFileSelected(event) {
      this.chooseImage();
    },
	chooseImage() {
	  uni.chooseImage({
		count: 1,
		sizeType: ['original', 'compressed'],
		sourceType: ['album'],
		success: (res) => {
		  console.log('图片路径为：', res.tempFilePaths[0]);
		  var imageSrc = res.tempFilePaths[0];
		  uni.getImageInfo({
			src: imageSrc,
			success: (path) => {
			  pathToBase64(path.path)
				.then(base64 => {
				  console.log("base64=" + base64); // 确认图片数据
				  this.imageUrl = base64;
				})
				.catch(error => {
				  console.error(error);
				});
			}
		  });
		},
		fail: (err) => {
		  console.log('chooseImage fail', err);
		}
	  });
	},
    async publishPost() {
      if (!this.postContent.trim()) {
        uni.showToast({
          title: '请输入信息',
          icon: 'none'
        });
        return;
      }

      this.loading = true;

      try {
        const res = await this.sendPostRequest(this.imageUrl);
        console.log(res);

        uni.showToast({
          title: '发布成功',
          icon: 'success'
        });
        await uni.$emit('pagecountChange');
        await uni.navigateBack(-1);

        this.postContent = '';
        this.selectedFile = null;
        this.imageUrl = '';

      } catch (error) {
        console.log(error);
        uni.showToast({
          title: '发布失败',
          icon: 'none'
        });
      } finally {
        this.loading = false;
      }
    },
    sendPostRequest(imageUrl) {
      return new Promise((resolve, reject) => {
        uni.request({
          url: 'http://localhost:3000/insertMyPage',
          method: 'POST',
          data: {
            u_id: this.id,
            pagetxt: this.postContent,
            goodcount: 0,
            publish_time: this.formatDate(new Date()),
            state: this.radioValue,
            txtcount: 0
          },
          success: (res) => {
            resolve(res);
          },
          fail: (err) => {
            console.log(err);
            reject(err);
          }
        });
      });
    },
    formatDate(date) {
      const pad = (n) => (n < 10 ? '0' + n : n);
      return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())} ${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
    }
  }
};
</script>

<style lang="scss">
.container {
  margin-top: 16px;
}

.topPage {
  width: 100vw;
  font-size: 20px;
  font-weight: bold;
  text-align: center;
  margin-bottom: 20px;
}

.top {
  padding: 5px;
  margin-bottom: 20px;
  margin-left: 10px;
  display: flex;
  flex-direction: row;
  box-shadow: 0 0 30rpx rgba(0, 0, 0, 0.05);
  border: 2px solid #fff;
  background: #fff;
}

.topic {
  font-size: 12px;
  margin-top: 5px;
}

.radio-group {
  display: flex;
  flex-wrap: wrap;
  gap: 5px;
}

.radio-label {
  font-size: 12px;
  display: flex;
  align-items: center;
  cursor: pointer;
}

.radio-circle {
  width: 40px;
  height: 20px;
  border-radius: 20%;
  padding: 0 5px;
  border: 2px solid #ccc;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: background-color 0.3s;
}

.radio-selected {
  border-color: #3399ff;
  background-color: #3399ff;
}

.radio-text {
  color: #333;
}

.radio-selected .radio-text {
  color: #fff;
}

.main-content {
  background-color: white;
  padding: 5px;
  border-radius: 8px;
  box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);
}

.input-area {
  margin-bottom: 20px;
}

.input {
  width: 100%;
  height: 500rpx;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 4px;
  font-size: 16px;
}

.inputtext {
  margin-top: 10px;
}

.publish-btn {
  width: 100%;
  padding: 10px;
  background-color: #3399ff;
  color: white;
  text-align: center;
  border: none;
  border-radius: 4px;
  font-size: 16px;
  cursor: pointer;
  margin-top: 60rpx;
}

.publish-btn:disabled {
  background-color: #ccc;
}

.uploaded-image {
  width: 100%;
  height: auto;
  margin-top: 20px;
}
</style>
