<template>  
  <view class="about-us-page"> 
  <image class="cover" src="../../static/ca6577aa0527b1a678b72e3c11eaed87.jpg" mode="scaleToFill"></image>
  
    <view class="h1">心维度心理咨询平台</view>  
	<view class="txt">
		<view class="p">&nbsp;&nbsp;&nbsp;&nbsp;在心理咨询领域中，"心维度"代表着探索和理解人们内心深处的多维情感和思维层面。它强调了内心世界的复杂性和丰富性，不仅仅局限于表面的情绪或感受，而是深入到更深层次的心理层面。</view>
		<view class="p">&nbsp;&nbsp;&nbsp;&nbsp;设计理念：每个人的内心都是一个包含多种情感和思想维度的世界，需要通过专业的探索和理解来呈现和理解。</view>    
		<view class="p">&nbsp;&nbsp;&nbsp;&nbsp;心维度心理咨询平台由蔡灿、薛文锐、邓文秀、张雪琳、周楚坤五名成员开发。无论您面临什么困难或挑战，我们都将竭诚为您提供帮助和支持。请随时联系我们，开启您的心理健康之旅！</view>  
	</view>
  </view>    
</template>  
  
<script>  
export default {  
  name: 'AboutUs',  
  // 在这里可以添加组件的逻辑，如数据、方法等  
};  
</script>  
  
<style lang="scss"> 
 .img{
	 width:40%;
	 height:15%;
	 z-index: 5;
 }
 .container {
    
 }  
.about-us-page {  
 // padding: 20px;  
  text-align: center;  
  //background-color: #E0FFFF; /* 浅灰色背景 */  
  //height: 100vh;
  width: 100%;
  height: 100vh;  
  position: relative;  
  overflow: hidden; 
  display: flex;  
  justify-content: center; 
  align-items: center; 
  flex-direction: column;
}  
  
  .txt{
	  display: flex;
	  flex-direction: column;
	  text-align: left;
	  z-index: 5;
  }
  
.h1 {  
  font-size: 22px;
  color: #000; /* 中灰色副标题 */  
  margin-top: 0rpx;
  margin-bottom: 15px;  
  text-align: center; /* 居中显示副标题 */ 
   z-index: 5;
}  
  
.p {  
   font-size: 16px;
   color: #444444; /* 深灰色文字 */  
   margin-bottom: 50rpx;
   margin-left: 10%;
   margin-right: 9%;
}  
.cover {  
    width: 100%;  
    height: 100%;  
    position: absolute;  
    top: 0;  
    left: 0;  
    z-index: 0; /* 确保背景图片不会覆盖其他内容 */  
}  
</style>