<template>  
  <view class="container"> 
    <view class="subtitle">申请咨询师</view>  
    <view class="steps">  
      <view class="step">  
        <image class="step-icon" src='../../static/shenqing.png' alt="申请咨询师图标" ></image>  
        <view class="step-text">申请咨询师</view>  
		<image class="down" src="../../static/下箭头.png"></image>
      </view>  
      <view class="step">  
        <image class="step-icon" src='../../static/bangdingshouji.png' alt="绑定手机图标"></image>  
        <view class="step-text">绑定手机</view> 
		<image class="down" src="../../static/下箭头.png"></image>
      </view>  
      <view class="step">  
        <image class="step-icon" src='../../static/tianxieziliao.png' alt="填写资料图标"></image>  
        <view class="step-text">填写资料</view>  
      </view>  
    </view>  
    <button class="apply-button" @click="applyForConsultant">我要申请成为咨询师</button>  
  </view>  
</template>

<script>
export default {
  methods: {
    applyForConsultant() {
      // 跳转到申请咨询师的页面
      uni.navigateTo({
        url: '/pages/applyConsultant/applyConsultant'
      });
    }
  }
};
</script>

  
<style>  
.container {  
  padding: 20px;  
  font-weight: 600;
  height: 100vh;
  background-color: aliceblue;
  border-radius: 10px; /* 圆角边框 */  
}  

.subtitle {  
  font-size: 22px;  
  color: #333333; /* 中灰色副标题 */  
  margin-top: 25rpx;
  margin-bottom: 25px;  
  text-align: center; /* 居中显示副标题 */  
}  

.steps {  
  display: flex;  
  flex-direction: column;  
  align-items: center;  
  text-align: center;
  margin-bottom: 30px; /* 增加步骤和按钮之间的间距 */  
}  

.down{
	margin-top: 50rpx;
	width: 50px;
	height: 50px;
}

.step {  
  display: flex;  
  flex-direction: column;
  align-items: center;  
  margin-bottom: 20px;  
}  

.step-icon {  
  width: 50px; 
  height: 50px;
}  

.step-text {  
  font-size: 16px;  
  color: #444444; /* 深灰色文字 */  
}  

.apply-button {  
  width: 200px;  
  height: 45px;  
  background-color: #1AAD19; /* 绿色按钮 */  
  color: #FFFFFF;  
  border-radius: 25px; /* 圆形按钮 */  
  text-align: center;  
  line-height: 45px; /* 使按钮文字居中对齐 */  
  font-size: 16px;  
  font-weight: bold;  
  margin-top: 20px;  
  display: block; /* 独占一行 */  
  margin-left: auto;  
  margin-right: auto; /* 水平居中按钮 */  
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2); /* 按钮阴影效果 */  
  transition: background-color 0.3s; /* 平滑的背景颜色过渡 */  
}  

.apply-button:active {  
  background-color: #128C0A; /* 点击时按钮变色 */  
}  
</style>
