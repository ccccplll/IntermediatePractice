<template>
  <view class="container">
    <view class="star">
      <label>评分：</label>
      <uni-rate :touchable="true" :value="rateValue" @change="onChange" v-model="rateValue"></uni-rate>
    </view>
    <view class="word">
      <input v-model="context" type="text" placeholder="请输入评价" class="input-field"/>
    </view>
    <view class="submit">
      <button @click="submit" class="submit-button">提交评价</button>
    </view>
  </view>
</template>

<script>
  export default {
    onLoad(option) {
      this.id = option.id;
      this.c_id = option.c_id;
    },
    data() {
      return {
        id: '',
        c_id: '',
        rateValue: 0,
        context: '',
      };
    },
    methods: {
      submit() {
        let time = this.formatDate(new Date());
        uni.request({
          url: 'http://localhost:3000/insertComment',
          method: 'POST',
          data: {
            c_id: this.c_id,
            score: this.rateValue,
            content: this.context,
            time: time,
            appoint_id: this.id,
          },
          success: (res) => {
            console.log(res);
            uni.request({
              url: 'http://localhost:3000/isComment',
              method: 'POST',
              data: { id: this.id },
              success: (res) => {
                console.log(res);
              },
              fail: (err) => {
                console.log(err);
              }
            });
            uni.showToast({
              title: '评价成功',
              icon: 'success',
              duration: 1000,
            });
            uni.$emit('orderCommented');
            uni.navigateBack(1);
          },
          fail: (err) => {
            console.log(err);
            uni.showToast({
              title: '评价失败',
              icon: 'none',
              duration: 2000,
            });
          }
        });
      },
      formatDate(date) {
        const pad = (n) => (n < 10 ? '0' + n : n);
        return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())} ${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
      },
      onChange(event) {
        this.rateValue = event.value;
      },
	  cleanup(){
	  		  uni.$emit('orderCommented');
	  }
    },
	onUnload() {
	    console.log("页面即将卸载");
	    this.cleanup();
	  },
  };
</script>

<style scoped>
.container {
  padding: 20px;
  background-color: #f9f9f9;
}

.star {
  display: flex;
  align-items: center;
  margin-bottom: 20px;
}

label {
  font-size: 18px;
  margin-right: 10px;
}

.word {
  margin-bottom: 20px;
}

.input-field {
  width: 100%;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 5px;
  font-size: 16px;
}

.submit {
  display: flex;
  justify-content: center;
}

.submit-button {
  padding: 10px 20px;
  background-color: #007aff;
  color: white;
  border: none;
  border-radius: 5px;
  font-size: 16px;
  cursor: pointer;
  transition: background-color 0.3s;
}

.submit-button:hover {
  background-color: #005bb5;
}
</style>
