<template>
	<view class="top">
		<view class="tui">
			<uni-notice-bar show-icon scrollable :text="currentNotice" />
		</view>
		<swiper indicator-dots="true" indicator-color="rgba(255,255,255,0.3)" indicator-active-color="#ffffff" circular="true" autoplay="true" interval="2000">
			<swiper-item v-for="(src,index) in randomPictures" :key="index">
				<image :src="src" mode="aspectFill" class="sw-image"></image>
			</swiper-item>
		</swiper>
	</view>
	<view class="middle">
		<view class="consult">
			<view class="navigator1" @click="calendar">
				<image src="../../static/心理咨询.png" mode="aspectFill"></image>
			</view>
			<text>心理咨询</text>
		</view>
		<view class="test">
			<navigator url="/pages/news/news">
				<image src="../../static/资讯.png" mode="aspectFill"></image>
			</navigator>
			<text>社区交流</text>
		</view>
		<view class="test">
			<navigator url="/pages/essay/essay">
				<image src="../../static/心理测评.png" mode="aspectFill"></image>
			</navigator>
			<text>心理文章</text>
		</view>
		<view class="test">
			<navigator url="/pages/tree/tree">
				<image src="../../static/pe 树洞-copy.png" mode="aspectFill"></image>
			</navigator>
			<text>我的树洞</text>
		</view>
	</view>
	<view class="botton">
		<view class="title">智能推荐</view>
		<scroll-view :scroll-top="screenTop" scroll-y class="scroll-y" @scrolltoupper="upper" @scrolltolower="lower" @scroll="scroll">
			<block v-for="(consultant, index) in consultants" :key="consultant.p_id"> 
				<navigator :url="generateConsultantUrl(consultant.p_id)"  class="scroll-view-item">
					<view class="botton-top">
						<view class="touxiang">
							<image :src="consultant.avatarUrl"></image>
						</view>
						<view class="right">
							<view class="name">{{ consultant.name }}</view>
							<view class="time">{{ consultant.experience }}小时经验</view>
							<view class="introduce-view">
								<view class="introduce">{{ consultant.introduction }}</view>
							</view>
							<view class="taf">
								<view class="price">￥{{ consultant.price }}/时</view>
								<view class="function">{{ consultant.service }}</view>
							</view>
						</view>
					</view>
					<view class="address">{{ consultant.address }}</view>
				</navigator>
			</block>
		</scroll-view>
	</view>
</template>

<script>
    export default{
		onLoad() {
			this.fetchNotices();
			this.fetchConsultants();
			this.fetchPicture();
		},
		data(){
			return{
				notices:[],
				currentNoticeIndex: 0, // 当前展示的通知在列表中的索引
				currentNotice: '', // 当前展示的通知内容
				intervalId: null ,// 用于存储定时器的 ID
				city:'',
				screenTop: 0,
				consultants: [],
				randomPictures:[],
			};
		},
		created() {
			this.fetchPicture();
			this.fetchConsultants();
			uni.$on('cityStatusChanged', this.fetchConsultants);
		},
		mounted() {
			// 初始化展示第一条通知
			this.currentNotice = this.notices[this.currentNoticeIndex];

			// 设置定时器，每小时更新一次通知内容
			this.intervalId = setInterval(() => {
			  this.currentNoticeIndex = (this.currentNoticeIndex + 1) % this.notices.length;
			  this.currentNotice = this.notices[this.currentNoticeIndex];
			}, 5000); // 3600000 毫秒 = 1 小时
	    },
	    beforeDestroy() {
			// 移除事件监听
			uni.$off('orderStatusChanged', this.fetchOrder);
			// 组件销毁时清除定时器，避免内存泄漏
			if (this.intervalId) {
			  clearInterval(this.intervalId);
			}
	    },
		methods:{
			fetchPicture(){
				uni.request({
					url: 'http://localhost:3000/getRandomPictures',
					method: 'GET',
					success: (res) => {
						console.log(res);
						this.randomPictures = res.data.map(item => item.image);
					},
					fail: (err) => {
						console.log(err);
					}
				});
			},
			generateConsultantUrl(p_id) {
			  if (!p_id) {
				console.warn('p_id is undefined or null');
				return '/pages/indexConsultant/indexConsultant?id=';
			  }
			  return `/pages/indexConsultant/indexConsultant?id=${encodeURIComponent(p_id)}`;
			},
			upper() {
			  console.log('scroll to upper');
			},
			lower() {
			  console.log('scroll to lower');
			},
			scroll(event) {
			  console.log('scrolling', event);
			},
			consultantInformation(consultant) {
			  console.log('查看顾问信息', consultant);
			  // 可以在此跳转到顾问的详情页面
			},
			fetchNotices(index = 1) {  
				uni.request({  
					url: 'http://localhost:3000/getAnnouncement',  
					method: 'GET',  
					data: { index: index },  
					success: (res) => {  
						if (res.data.length === 0 || res.data[0].context === null || res.data[0].context === '') {  
							// 如果没有更多数据，则不继续  
							return;  
						}  
						this.notices.push(res.data[0].context);  
						//console.log(res.data[0].context);
						//console.log(res);  
						// 递归调用以获取下一项  
						this.fetchNotices(index + 1);  
					},  
					fail(err) {  
						console.log(err);  
						// 根据实际情况决定是否重试或停止  
					}  
				});  
			},
			fetchConsultants() {
				this.fetchCity().then(() => {
					this.getSameCity();
					this.getDiffCity();
				});
			},
			fetchCity() {
				let name = getApp().globalData.userName;
				return new Promise((resolve, reject) => {
					uni.request({
						url: 'http://localhost:3000/getAddress',
						method: 'GET',
						data: { name: name },
						success: (res) => {
							this.city = res.data[0].city;
							resolve();
						},
						fail(err) {
							console.log(err);
							reject(err);
						}
					});
				});
			},
			getSameCity() {
				uni.request({
					url: 'http://localhost:3000/getSameCity',
					method: 'GET',
					data: { city: this.city },
					success: (res) => {
						this.consultants = [];
						res.data.forEach(item => {
							const consultant = {
								p_id:item.p_id,
								avatarUrl: item.avatar,
								name: item.trueName,
								experience: item.accumulatedHour,
								introduction: item.introduction,
								price: item.price,
								service: item.consult_way,
								address: item.city,
							};
							this.consultants.push(consultant);
							//console.log(item.p_id);
						});
					},
					fail(err) {
						console.log(err);
					}
				});
			},
			getDiffCity() {
				uni.request({
					url: 'http://localhost:3000/getDiffCity',
					method: 'GET',
					data: { city: this.city },
					success: (res) => {
						res.data.forEach(item => {
							const consultant = {
								p_id:item.p_id,
								avatarUrl: item.avatar,
								name: item.trueName,
								experience: item.accumulatedHour,
								introduction: item.introduction,
								price: item.price,
								service: item.consult_way,
								address: item.city,
							};
							this.consultants.push(consultant);
						});
					},
					fail(err) {
						console.log(err);
					}
				});
			},
			calendar(){
				uni.switchTab({
					url:"/pages/calendar/calendar"
				})
			},
		}
	}
</script>

<style lang="scss">
	.top{
		width: 100vw;
		//background: linear-gradient(45deg,#7FFFD4 0%,#7FFFD4 51%,#FFDAB9 49%,#FFDAB9 100%);
		.tui{
			width: 100vw;
			height:60rpx;
			font-size: 40rpx;
			//padding-bottom: 5rpx;
			.uni-noticebar{
				width: 100vw;
				height: 50rpx;
			}
		}
	}
	swiper{
		width:100vw;
		height:360rpx;
		border-radius: 15px;
		//margin-top: 10rpx;
		box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
		overflow: hidden;
		swiper-item{
			width: 100%;
			height:100%;
			.sw-image{
				width: 100%;
				height:100%;
			}
		}
	}
	.middle{
		display: flex;
		justify-content: space-around;
		flex-direction: row;
		margin-top: 20rpx;
		background: #fff;
		border-radius: 15px;
		box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
		padding: 20rpx;
		.consult, .test{
			display: flex;
			flex-direction: column;
			align-items: center;
			padding: 10rpx;
			text-align: center;
			navigator, .navigator1{
				width: 100rpx;
				height: 100rpx;
				border-radius: 50%;
				overflow: hidden;
				background: #f5f5f5;
				display: flex;
				justify-content: center;
				align-items: center;
				margin-bottom: 10rpx;
				image{
					width: 70%;
					height: 70%;
				}
			}
			text{
				font-size: 28rpx;
				color: #333;
			}
		}
	}
	.botton{
		margin-top: 30rpx;
		padding: 20rpx;
		background: #fff;
		border-radius: 15px;
		box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
		.title{
			font-size: 36rpx;
			font-weight: bold;
			margin-bottom: 20rpx;
			color: #333;
		}
		.scroll-y {
			height: 500rpx;
			overflow-y: scroll;
		}
		.scroll-view-item {
			display: flex;
			flex-direction: column;
			background: #fff;
			border-radius: 15px;
			box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
			margin-bottom: 20rpx;
			padding: 15rpx;
			.botton-top{
				display: flex;
				flex-direction: row;
				align-items: center;
				.touxiang{
					width: 120rpx;
					height: 120rpx;
					border-radius: 50%;
					overflow: hidden;
					margin-right: 20rpx;
					image{
						width: 100%;
						height: 100%;
					}
				}
				.right{
					flex: 1;
					.name{
						font-size: 36rpx;
						font-weight: bold;
						color: #333;
					}
					.time{
						font-size: 28rpx;
						color: #999;
						margin-top: 10rpx;
					}
					.introduce-view{
						margin-top: 10rpx;
						.introduce{
							font-size: 28rpx;
							color: #666;
							overflow: hidden;
							white-space: nowrap;
							text-overflow: ellipsis;
							width: 200px;
						}
					}
					.taf{
						display: flex;
						flex-direction: row;
						align-items: center;
						justify-content: space-between;
						margin-top: 10rpx;
						.price{
							font-size: 28rpx;
							color: #FF6347;
							font-weight: bold;
						}
						.function{
							font-size: 28rpx;
							color: #666;
						}
					}
				}
			}
			.address{
				margin-top: 10rpx;
				font-size: 28rpx;
				color: #999;
				text-align: right;
			}
		}
	}
</style>