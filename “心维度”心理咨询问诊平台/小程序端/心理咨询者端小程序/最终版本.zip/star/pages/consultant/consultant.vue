<template>  
  <view id="demo1" class="scroll-view-item" @click="consultantInformation">
       <view class="botton-top">                        
           <view class="touxiang">
               <image :src="img"></image>
           </view>
           <view class="right1">
               <view class="name">{{name111}}【成熟咨询师】</view>
               <view class="time"> 
  			      <text class="color1">{{time}}</text>
                   <text class="color1">{{money}}</text>    
  			     <view class="row" >
  				     <uni-rate size="20" :value="rateValue" :readonly="true"/>
				     <text class="white">评分:{{score}}</text>
			</view>	 
  			 </view>		
              
           </view>
             
              
      </view>    
  </view>
  		<uni-group title="个人简介" mode="card">
  			<view>
  				<view class="jiange">
                     <text class="size1">擅长领域</text>
                  </view>
                  <view class="jiange1">
                    <text>{{shanchang}}</text>
                 </view>
              </view>
  			<view>
  			  <view class="jiange">
  			     <text class="size1">咨询时间</text>
  			  </view>
  			  <view class="jiange1" >
  			      <text>{{shijian}}-{{shijian1}}</text>
  			  </view>
  			</view>
  			<view class="jiange">
  			   <text class="size1">联系方式</text>
  			</view>
  			<view class="jiange1">
  			   <text>电话：{{phone}}</text>
  			</view>
  			<view class="jiange1">
  				 <text>邮箱：{{email}}</text>
  			</view>
  			  <view class="jiange">
  			      <text class="size1">从业资质</text>
  			      <view class="certifications">
  			        <image v-for="(cert, index) in certifications" :key="index" :src="cert" class="cert-img"/>
  			      </view>
  			</view>
  		</uni-group>
  	 <uni-group title="自我介绍" mode="card">
  	  	<view class="section">
  	  	  <text class="section-content">{{ jianjie}}</text>
  	  	</view>
  	  </uni-group>
  	 <view class="bottom">
  	 	<uni-group title="Ta的评价" mode="card">
  	 		<view v-for="(comment,index) in comments" :key="index" class="comment">
  	 			<view class="comment-item">
  	 				<view class="comment-avatar">
  	 					<image :src="commentAvatar"></image>
  	 				</view>
  	 				<view class="right">
  	 					<view class="nameStar">
  	 						<view class="comName">用**{{comment.appoint_id}}</view>
  	 						<uni-rate size="20" :value="comment.score" :readonly="true"/>
  	 					</view>
  	 					<view class="commentTime">{{comment.time}}</view>
  	 					<view class="commentText">{{comment.content}}</view>
  	 				</view>
  	 			</view>
  	 		</view>
  	 	</uni-group> 
  	 </view>
  	   
 
 	<view >
             <button type="primary" class="delete"   @click="agree" >{{type1}}</button>
 	</view>
 	
 
</template>  
  
<script> 
import moment from 'moment'; 
 export default { 
    data() {  
     return {
	   comments:[],
	   commentAvatar:'',
	   rateValue:'',
	   certifications: [],
	   score:'',
	   userName:'',
	   img:'', 
	   email:'',
       name111: '',
       title: '成熟咨询师',  
       time: '',  
       money: '',  
       jianjie: '',  
       shanchang: '',  
       shijian: '', 
	   shijian1:'',
       phone: '',
	   type1:'',
	   type2:'',
	   state:'false',
	   id:'',//p_id
	   c_id:'',
	   u_id:''
     };  
   }, 
   onLoad(options) {  
           console.log('Received message:', options.message);  
           console.log('Received type:', options.type); 
			this.name111=options.message;
			this.type1=options.type;
			this.shijian=options.shijian1;
			this.shijian1=options.shijian11;
			this.information(this.name111,this.type1,this.shijian,this.shijian1);
			this.fetchRandomAvatar();
			this.fetchCommentValue();
			this.userName=getApp().globalData.userName;
			uni.request({
			url: "http://localhost:3000/mmmm",
			method: 'get',
			data:{
			 userName:this.userName
			},
			success: res => {	
			this.u_id=res.data[0].id;
			console.log('数据搜索成功',this.u_id);
			uni.request({
			    url:'http://localhost:3000/isOrdered',
			    method:'GET',
			    data: {
			      u_id: this.u_id,
			      c_id: this.c_id,
			      p_id: this.id,
			    },
			    success: (res) => {
			        if(res.data.length === 0){
			            this.state = false;
						
			        }else{
			            this.state = true;
						this.type1='已预约';
			        }
				  console.log(this.state);
			    },
			    fail: (err) => {
			        console.log(err);
			    }
			})
			}
			});
			
			
       }, 
   methods: { 
	   agree(){
		   if(this.state==false){
		   		this.type1='已预约';
				this.state=true;
				// 获取当前时间
				    var now = new Date();  
				    // 获取当前年份  
				    var year = now.getFullYear();  
				    // 获取当前月份（注意：JavaScript中的月份是从0开始的，所以需要加1）  
				    var month = now.getMonth() + 1;  
				    month = month < 10 ? '0' + month : month; // 格式化月份为两位数  
				    // 获取当前日期  
				    var day = now.getDate();  
				    day = day < 10 ? '0' + day : day; // 格式化日期为两位数  
				    // 获取当前小时  
				    var hour = now.getHours();  
				    hour = hour < 10 ? '0' + hour : hour; // 格式化小时为两位数  
				    // 获取当前分钟  
				    var minute = now.getMinutes();  
				    minute = minute < 10 ? '0' + minute : minute; // 格式化分钟为两位数  
				    // 获取当前秒  
				    var second = now.getSeconds();  
				    second = second < 10 ? '0' + second : second; // 格式化秒为两位数  
				    // 拼接日期时间字符串  
				    var dateTime = year + '-' + month + '-' + day + ' ' + hour + ':' + minute + ':' + second;  
				    console.log(dateTime); // 输出格式化后的日期时间字符串
					
					this.userName=getApp().globalData.userName;
					uni.request({
					url: "http://localhost:3000/mmmm",
					method: 'get',
					data:{
					 userName:this.userName
					},
					success: res => {	
					this.u_id=res.data[0].id;
					console.log('数据搜索成功',this.u_id);
					
					uni.request({
					    url: 'http://localhost:3000/ssss',  
					    method: 'POST', 
					    data: { 
							u_id: this.u_id,
							c_id: this.c_id,
							p_id: this.id,
							create_time: this.dateTime,
							nowstate:'待支付',
					        consult_way: this.type2
					    },  
					    headers: {  
					        'content-type': 'application/json'  
					    },  
					    success: (res) => {  
							console.log(this.u_id);
							
					        console.log('插入数据库成功');  
					        // 更新UI或进行其他操作  
					    },  
					    fail: (err) => {  
					        console.error('插入失败', err);  
					    }  
					});
					}
				});
				}
			else if(this.state==true){
				 uni.request({
				        url: 'http://localhost:3000/deleteOrder',
				        method: 'POST',
				        data: {
				          u_id: this.u_id,
				          c_id: this.c_id,
				          p_id: this.id,
				        },
				        success: (res) => {
				          console.log(res);
				          this.state = false;
				          uni.showToast({
				            title: '取消预约成功',
				            icon: 'success',
				          });
						  this.type1=this.type2;
				        },
				        fail: (err) => {
				          console.log(err);
				        }
				      });
			}
	   },
	   fetchRandomAvatar(){
	   		let src = "../../static/可爱粽子.png";
	   		this.commentAvatar = src;
	   	},
	   	fetchCommentValue(){
	   		uni.request({
	   			url:'http://localhost:3000/getCommentValue',
	   			method:'GET',
	   			data:{id:this.id},
	   			success: (res) => {
	   				let total=0;
	   				let index=0;
	   				res.data.forEach(item => {
	   					const order={
	   						appoint_id:item.appoint_id,
	   						score:item.score,
	   						time:item.time,
	   						content:item.content,
	   					};
	   					this.comments.push(order);
	   					total+=item.score;
	   					index++;
	   				});
	   				this.rateValue=total/index;
	   			},
	   			fail: (err) => {
	   				console.log(err);
	   			}
	   		})
	   	},
	   
	   
	   
	   
	   
	   
	   
     information(name111,type1,shijian,shijian1) {  
           uni.request({
           url: 'http://localhost:3000/test00?name111='+ this.name111 +'&type1=' + this.type1+'&shijian1=' + this.shijian+'&shijian11=' + this.shijian1,
           method: 'get',
             success: (res) => {  
               if (res.data) {
				 this.c_id=res.data.c_id||'';
				 this.id=res.data.p_id||'';
				 this.img=res.data.avatar||'';
				 this.email=res.data.email||'';
				 this.shijian = moment(res.data.start_time).format('YYYY-MM-DD HH:mm:ss') || '';  
				 this.shijian1 = moment(res.data.finish_time).format('YYYY-MM-DD HH:mm:ss') || '';
				 this.money=(res.data.price||0)+'元/时';
                 this.name111 = res.data.trueName || '';  
                 this.time = (res.data.accumulatedHour || 0) + '小时经验'; 
                 this.jianjie = res.data.introduction || ''; 
                 this.shanchang = res.data.strength || '';   
                 this.phone = res.data.phoneNumber || ''; 
				 this.type1 = res.data.consult_way||'';
				 this.type2 = res.data.consult_way||'';
				 this.state=res.data.is_appointed||'';
				 console.log(this.type1);
				 uni.request({
				 url: 'http://localhost:3000/certification',
				 method: 'get',
				 data:{
					c_id:this.c_id 
				 },
				   success: (res) => { 
					   this.certifications = res.data.map(item => item.image);
					  } 
				 });
				 uni.request({
				 	url:'http://localhost:3000/getCommentValue',
				 	method:'GET',
				 	data:{id:this.id},
				 	success: (res) => {
				 		let total=0;
				 		let index=0;
				 		res.data.forEach(item => {
				 			const order={
				 				appoint_id:item.appoint_id,
				 				score:item.score,
				 				time:item.time,
				 				content:item.content,
				 			};
				 			this.comments.push(order);
				 			total+=item.score;
				 			index++;
				 		});
				 		this.rateValue=total/index;
				 	},
				 	fail: (err) => {
				 		console.log(err);
				 	}
				 })
				 
				uni.request({  
				    url: 'http://localhost:3000/score',  
				    method: 'get',  
				    data: {  
				        c_id: this.c_id // 确保 this.c_id 已经被正确定义  
				    },  
				    success: (res) => { // 使用箭头函数来保持 this 的上下文  
				        if (res.data && Array.isArray(res.data)) { // 检查 res.data 是否为数组  
				            let sum = 0;  
				            let count = 0;  
				            for (let i = 0; i < res.data.length; i++) { // 遍历数组  
				                if (res.data[i].score !== undefined) { // 确保 score 属性存在  
				                    sum += res.data[i].score; // 累加分数  
				                    count++; // 计数有效项  
				                }  
				            }  
				            if (count > 0) {  
				                this.score = sum / count; // 计算平均分并赋值  
								this.rateValue = this.score;
				            } else {  
				               // console.error('No valid scores found'); // 如果没有有效分数，则输出错误 
								this.score=0;
				            }  
				        } else {  
				           // console.error('Data is not an array'); // 如果 res.data 不是数组，则输出错误  
						   this.score=0;
				        }  
				    },  
				    fail: (err) => { // 添加失败回调以处理请求错误  
				        console.error('Request failed:', err);  
				    }  
				});
				 
				 
				 
				 
				 
				 
				 
               } else {  
                 console.error('Failed to fetch data:', res);  
               }  
             },  
             fail: (err) => {  
               console.error('Request failed:', err);  
             }  
           });  
         } ,
		 
		  
       }
 
 }
</script>  
  
<style lang="scss">
.section {
  margin-bottom: 30rpx;
}

.section-title {
  font-weight: bold;
  font-size: 30rpx;
  margin-bottom: 10rpx;
}

.content {
  font-size: 26rpx;
  line-height: 36rpx;
  margin-bottom: 10rpx;
}

.certifications {
  display: flex;
  flex-wrap: wrap;
}

.cert-img {
  width: 200rpx;
  height: 200rpx;
  margin-right: 10rpx;
  margin-bottom: 10rpx;
}

.bottom {
  margin-top: 40rpx;
  background-color: #fff;
  border-radius: 10rpx;
}

.comment {
  display: flex;
  flex-direction: column;
  margin-bottom: 20rpx;
}

.comment-item {
  display: flex;
  flex-direction: row;
  border-bottom: 1px solid #ddd;
  &:last-child{border-bottom: 0;}
}

.comment-avatar{
	margin-top: 0px;
}

.comment-avatar image{
  padding-top: 0px;
  width: 80rpx;
  height: 80rpx;
  border-radius: 50%;
  margin-right: 20rpx;
}

.right {
  display: flex;
  flex-direction: column;
}

.nameStar {
  display: flex;
  flex-direction: row;
  align-items: center;
  //justify-content: space-between;
  margin-top: 10rpx;
  margin-bottom: 10rpx;
}

.comName {
  font-size: 30rpx;
  font-weight: bold;
  margin-right: 20rpx;
}

.commentTime {
  font-size: 24rpx;
  color: #333;
}

.commentText{
  margin-top: 20rpx;
  font-size: 28rpx;
  color: #333;
}
	
	
	
	
	
	
.row{
	display:flex;
	justify-content: center;
}
.white{
	color: white;
	//margin-left: 2%;
}
.jiange5{
	width:100%;
	height:150px;
	display:flex;
	justify-content: center;
	image{
		width:300px;
		height: 150px;
	}
}
 .scroll-view-item {
     height: 300rpx;
     display: flex;
     flex-direction: column;
 	  background-color:#23d0f7;
 	  border-radius: 0% 0% 20% 20%;
     //border: 1rpx solid gainsboro;
     //&:last-child{border-bottom: 0;}
     .botton-top{
         width: 100%;
         height: 258rpx;
         display: flex;
         flex-direction: row;
         align-items: center;
         //border: 1rpx solid skyblue;
         .touxiang{
             width: 160rpx;
             height: 160rpx;
             border-radius: 100%;
             overflow: hidden;
             margin: 25rpx;
             //border: 1rpx solid skyblue;
             image{
                 width: 100%;
                 height: 100%;
             }
         }
         .right1{
             display: flex;
 			width:100%;
             flex-direction: column;
             align-items: flex-start;
             height: 218rpx;
             padding-top: 25rpx;
             //border: 1rpx solid skyblue;
             .name{
                 padding: 5rpx;
                 font-size: 40rpx;
 				color:white
                 //border: 1rpx solid skyblue;
             }
             .time{
                 padding: 5rpx;
                 font-size: 26rpx;
                 //border: 1rpx solid skyblue;
             }
             .introduce-view{
                 padding: 5rpx;
                 //font-size: 30rpx;
                 overflow: hidden;
                 white-space: nowrap;
                 text-overflow: ellipsis;
                 width: 200px;
                 //border: 1rpx solid skyblue;
                 .intriduce{
                     font-size: 30rpx;
                 }
             }
             .taf{
                 padding: 5rpx;
                 display: flex;
                 flex-direction: row;
                 align-items: center;
                 justify-content: space-between;
                 width: 130px;
                 //border: 1rpx solid skyblue;
                 .price{
                     font-size: 28rpx;
                     text-align: right;
                     //border: 1rpx solid skyblue;
                 }
                 .function{
                     font-size: 28rpx;
                     text-align: right;
                     //border: 1rpx solid skyblue;
                 }
             }
         }
     }
   }
   
    
 
 
 .line{
 	  display:flex;
 	  justify-content: space-around;
 	  flex-direction: row;
 	  align-items: center;
 	  margin-top:15%;
 }
 .delete{
 	 width:45%;
 	 background-color:#23d0f7; 
	 //margin-bottom: 8%;
	 color: white;
	 //border-color: #23d0f7;
	 //border-radius: 20%;
 }
 
.container {  
  display: flex;  
  justify-content: center;  
  align-items: center;  
  height: 30%;  
  flex-direction: column; 
}  
  
.image-style {  
  width: 100%; 
  height: 180px; 
} 
 .jiange{
	 margin-top: 3%;
	 margin-bottom: 3%;
	 margin-left: 1.5%;
 }
 .jiange1{
 	 margin-top: 3%;
 	 margin-bottom: 3%;
	 margin-left: 3%;
 }
.color1{
	//background-color: #f9f28b;
	//border-color: ghostwhite;
	font-size: 23;
	color: white;
	width:30%;
	margin-top: 3%;
	border-radius: 20%;
	margin-left: 4%;
	justify-content: center;
	margin-bottom: 5%;
}
.size{
	font-size: 23px;
	margin-bottom: 3%;
}
.size1{
	font-size: 18px;
	padding-top: 3%;
}
</style>







      