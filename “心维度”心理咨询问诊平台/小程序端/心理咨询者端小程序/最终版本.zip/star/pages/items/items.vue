<template>
  <view class="container">
    <view class="search-bar">
      <input type="text" placeholder="心维度 搜索订单" class="search-input" v-model="searchQuery" @input="searchOrders"/>
    </view>
    <view class="tab-bar">
      <text class="tab-item" :class="{ active: currentFilter === 'all' }" @tap="filterOrders('all')">全部</text>
      <text class="tab-item" :class="{ active: currentFilter === 'confirmed' }" @tap="filterOrders('confirmed')">待支付</text>
      <text class="tab-item" :class="{ active: currentFilter === 'processing' }" @tap="filterOrders('processing')">待完成</text>
      <text class="tab-item" :class="{ active: currentFilter === 'completed' }" @tap="filterOrders('completed')">已完成</text>
      <text class="tab-item" :class="{ active: currentFilter === 'pending' }" @tap="filterOrders('pending')">退款/失效</text>
    </view>
    <view class="order-list">
      <block v-for="(order, index) in filteredOrders" :key="order.id">
        <navigator :url="'/pages/itemInfor/itemInfor?id=' + order.id" class="order-item" @longpress="deleteOrder(index)">
          <view class="main">
            <view class="touxiang">
              <image :src="order.avatar"></image>
            </view>
            <view class="order-info">
              <view class="name">{{ order.name }}</view>
              <view class="time">时长: {{ order.duration }}分钟</view>
              <view class="price">价格: ¥{{ order.price }}</view>
              <view class="created_at">{{ order.created_at }}</view>
            </view>
          </view>
          <view class="actions">
            <view class="order-status">
              <text v-if="order.status === 'confirmed'" class="status-confirmed">待支付</text>
              <text v-if="order.status === 'processing'" class="status-processing">待完成</text>
              <text v-if="order.status === 'completed'" class="status-completed">已完成</text>
              <text v-if="order.status === 'pending' && order.status1 === 1" class="status-pending">已失效</text>
              <text v-if="order.status === 'pending' && order.status1 === 2" class="status-pending">退款中</text>
              <text v-if="order.status === 'pending' && order.status1 === 3" class="status-pending">已退款</text>
            </view>
            <view class="buttons">
              <button v-if="order.status === 'confirmed'" @click.stop="cancel(index)">取消订单</button>
              <button v-if="canShowRefundButton(order)" @click.stop="reback(index)">申请退款</button>
              <button v-if="order.status === 'completed' && !order.isCommented" @click.stop="comment(index)">去评价</button>
              <button v-if="order.status === 'completed' && order.isCommented" disabled>已评价</button>
            </view>
          </view>
        </navigator>
      </block>
    </view>
  </view>
</template>


<script>
export default {
  onLoad(option) {
	//this.currentFilter = option.state;
  	this.fetchId();
  },
  data() {
    return {
	  currentTime: new Date(),
      searchQuery: '',
      orders: [],
      filteredOrders: [],
      currentFilter: 'all',
	  id:'',
    };
  },
  methods: {
	fetchId(){
		let that = this;
		uni.request({
			url:'http://localhost:3000/selectInfor',
			method: 'GET',
			data:{name:getApp().globalData.userName},
			success: (res) => {
				//console.log(res);
				that.id = res.data[0].id;
				that.fetchOrder();
			},
			fail: (err) => {
				console.log(err);
			}
		})
	},
	canShowRefundButton(order){
	  if (order.status !== 'processing') return false;
	  
	  const currentTime = new Date(this.currentTime);
	  const startTime = new Date(order.start_time);
	  const sixHoursBeforeStartTime = new Date(startTime.getTime() - 6 * 60 * 60 * 1000);

	  return currentTime < sixHoursBeforeStartTime;
	},
	updateTime(){
		this.currentTime = new Date();
	},
    fetchOrder() {
      uni.request({
        url: 'http://localhost:3000/getOrder',
        method: 'GET',
        data: { id: this.id },
        success: (res) => {
          this.orders = []; // 清空订单列表
          res.data.forEach(item => {
            let state;
			let state1;
            if (item.state === "已失效") {
              state = 'pending';
			  state1 = 1;
            } else if(item.state === "退款中"){
			  state = 'pending';
			  state1 = 2;
			} else if(item.state === "已退款"){
			  state = 'pending';
			  state1 = 3;
			} else if (item.state === "待支付") {
              state = 'confirmed';
			  state1 = 0;
            } else if (item.state === "待完成") {
              state = 'processing';
			  state1 = 0;
            } else if (item.state === "已完成") {
              state = 'completed';
			  state1 = 0;
            }
            let time = item.time / 60;
            const order = {
              c_id: item.c_id,
              id: item.id,
              avatar: item.avatar,
              status: state,
			  status1: state1,
              name: item.trueName,
              created_at: this.formatDate(new Date(item.create_time)),
			  start_time: item.start_time,
              duration: time,
              price: item.price,
              isCommented: item.isCommented, // 添加评价状态字段
            };
            this.orders.push(order);
          });
          this.applyFilters(); // 更新过滤后的订单
        },
        fail: (err) => {
          console.log(err);
        }
      });
    },
    formatDate(date) {
	  const pad = (n) => n < 10 ? '0' + n : n;
	  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())} ${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
	},
    filterOrders(status) {
      this.currentFilter = status;
      this.applyFilters();
    },
    searchOrders() {
      this.applyFilters();
    },
    applyFilters() {
      this.filteredOrders = this.orders.filter(order => {
        const matchesStatus = this.currentFilter === 'all' || order.status === this.currentFilter;
        const matchesSearchQuery = !this.searchQuery || (order.name && order.name.includes(this.searchQuery));
        return matchesStatus && matchesSearchQuery;
      });
    },
	deleteOrder(index) {
		 //console.log('Delete order called for index:', index); // 调试信息
		 //console.log('Order status:', this.orders[index].status); // 调试信息
		 if (this.filteredOrders[index].status === "pending" || this.filteredOrders[index].status === "confirmed" || this.filteredOrders[index].status === "completed") {
			 let i=0;
			 let j=0;
			 for(i;i<this.orders.length;i++){
			 			  if(this.orders[i].status === this.filteredOrders[index].status){
			 				  if(j==index){
			 					  this.orders.splice(i,1);
			 					  break;
			 				  }
			 				  j++;
			 			  }
			 }
		   this.filteredOrders.splice(index, 1);
		   this.applyFilters();
		   console.log('Order deleted'); // 调试信息
		 } else {
		   console.log('Order not deleted, status does not match'); // 调试信息
		 }
    },
	cancel(index) {
	  uni.request({
	    url: 'http://localhost:3000/deleteOrder1',
	    method: 'POST',
	    data: { id: this.filteredOrders[index].id },
	    success: (res) => {
	      uni.showToast({
	        title: '订单已取消',
	        icon: 'success', // 改为 'success'
	        duration: 1000
	      });
		  uni.$emit('orderStatusChanged');
	      console.log(res);
		  let sta = (this.currentFilter=='all'?index:index+1);
		  let i=0;
		  let j=0;
		  for(i;i<this.orders.length;i++){
			  if(this.orders[i].status === this.filteredOrders[index].status&&j===sta){
				  this.orders.splice(i,1);
				  break;
			  }
			  j++;
		  }
	      this.filteredOrders.splice(index, 1); // 从订单列表中移除已取消的订单
	      this.applyFilters(); // 更新过滤后的订单
	    },
	    fail: (err) => {
	      console.log(err);
	    }
	  });
	},
	reback(index) {
	    if (this.filteredOrders[index] && this.filteredOrders[index].id) {
	      uni.navigateTo({
	        url: "/pages/reback/reback?id=" + this.filteredOrders[index].id,
	        fail: (err) => {
	          console.log('Navigation failed:', err);
	        }
	      });
	    } else {
	      console.log('Order information is incomplete.');
	    }
	},
	comment(index) {
	    if (this.filteredOrders[index] && this.filteredOrders[index].id && this.filteredOrders[index].c_id) {
	      uni.navigateTo({
	        url: "/pages/comment/comment?id=" + this.filteredOrders[index].id + "&c_id=" + this.filteredOrders[index].c_id,
	        success: () => {
	          this.filteredOrders[index].isCommented = true; // 更新评价状态
	          this.applyFilters(); // 更新过滤后的订单
	        },
	        fail: (err) => {
	          console.log('Navigation failed:', err);
	        }
	      });
	    } else {
	      console.log('Order information is incomplete.');
	    }
	  },
	},
	mounted() {
		this.updateTime();
		setInterval(this.updateTime,1000);
	  //this.fetchOrder(); // 在mounted生命周期中调用fetchOrder方法
	  // 注册事件监听
	  uni.$on('orderStatusChanged', this.fetchOrder);
		uni.$on('orderCommented', this.fetchOrder);
	},
	beforeDestroy() {
	  // 移除事件监听
	  uni.$off('orderStatusChanged', this.fetchOrder);
		uni.$off('orderCommented', this.fetchOrder);
	},
};
</script>

<style>
.container {
  padding: 10px;
  background-color: #f5f5f5;
}

.search-bar {
  margin-bottom: 20px;
}

.search-input {
  width: 100%;
  padding: 10px;
  border: 1px solid #ccc;
  background-color: #fff;
  border-radius: 5px;
}

.tab-bar {
  display: flex;
  justify-content: space-around;
  margin-bottom: 20px;
}

.tab-item {
  flex: 1;
  text-align: center;
  padding: 10px;
  color: #666;
  border-bottom: 2px solid transparent;
  transition: border-color 0.3s, color 0.3s;
  font-size: 24rpx;
}

.tab-item.active {
  color: #007aff;
  border-bottom: 2px solid #007aff;
}

.order-list {
  margin-top: 20px;
}

.order-item {
  display: flex;
  flex-direction: column;
  background-color: #fff;
  padding: 15px;
  margin-bottom: 15px;
  border-radius: 10px;
  box-shadow: 0 1px 3px rgba(0,0,0,0.1);
}

.main {
  display: flex;
  align-items: center;
}

.touxiang {
  margin-right: 10px;
}

.touxiang image {
  width: 60px;
  height: 60px;
  border-radius: 50%;
}

.order-info {
  flex: 1;
}

.name {
  font-size: 18px;
  font-weight: bold;
  margin-bottom: 5px;
}

.time,
.price,
.created_at {
  font-size: 14px;
  color: #666;
}

.actions {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-top: 10px;
}

.order-status {
  flex: 1;
}

.status-confirmed {
  color: #ff9800;
}

.status-processing {
  color: #03a9f4;
}

.status-completed {
  color: #4caf50;
}

.status-pending {
  color: #f44336;
}

.buttons {
  display: flex;
}

.buttons button {
  margin-left: 10px;
  padding: 0px 15px;
  font-size: 14px;
  color: #fff;
  background-color: #007aff;
  border: none;
  border-radius: 20px;
  box-shadow: 0 3px 6px rgba(0,0,0,0.1);
  transition: background-color 0.3s, transform 0.2s;
}

.buttons button:first-child {
  margin-left: 0;
}

.buttons button:hover {
  background-color: #005bb5;
  transform: translateY(-2px);
}

.buttons button:active {
  background-color: #003f8c;
  transform: translateY(0);
}

.buttons button:disabled {
  background-color: #ccc;
  cursor: not-allowed;
}
</style>
