<template>
    <view class="container">
        <view class="uni-list">
            <view class="uni-list-cell" hover-class="uni-list-cell-hover" v-for="(value, key) in listData" :key="key" @click="goDetail(value)">
                <view class="uni-media-list">
                    <image class="uni-media-list-logo" :src="value.cover"></image>
                    <view class="uni-media-list-body">
                        <view class="uni-media-list-text-top">{{ value.title }}</view>
                        <view class="author" @click="jumptoCon">{{ value.author_name }}</view>
                        <view class="uni-media-list-text-bottom">
                            <text>点赞数：{{ value.goodNum }}</text>
                            <text>{{ formatDate(value.published_at) }}</text>
                        </view>
                    </view>
                </view>
            </view>
        </view>
    </view>
</template>

<script>
    
export default {
    data() {
        return {
            listData: [],
        };
    },
    onLoad() {
        this.getAllEssay();
    },
    methods: {
        goDetail(value) {
            uni.navigateTo({
                url: `../essayDetail/essayDetail?id=${value.id}`,
            });
        },
        getAllEssay() {
            uni.request({
                url: 'http://localhost:3000/getAllEssay',
                method: 'GET',
                success: (res) => {
                    console.log(res);
                    this.listData = res.data.map(item => ({
                        id: item.id,
                        title: item.title,
                        author_name: item.trueName,
                        cover: item.img_src,
                        published_at: item.time,
                        goodNum: item.good,
                        content: item.content
                    }));
                },
                fail: (err) => {
                    console.log(err);
                }
            });
        },
        jumptoCon() {
            // Define your logic for navigating to the author's page
        },
        formatDate(dateString) {
            const date = new Date(dateString);
            return `${date.getFullYear()}-${date.getMonth() + 1}-${date.getDate()} ${date.getHours()}:${date.getMinutes()}`;
        }
    }
};
</script>

<style lang="scss">
.container {
    padding: 40upx;
    background-color: #f2f2f2;
}

.uni-list {
    display: flex;
    flex-direction: column;
    gap: 30upx;
}

.uni-list-cell {
    border-radius: 12upx;
    background-color: #fff;
    box-shadow: 0 4upx 12upx rgba(0, 0, 0, 0.1);
    overflow: hidden;
}

.uni-media-list {
    display: flex;
    flex-direction: row;
}

.uni-media-list-logo {
    width: 220upx;
    height: 180upx;
    border-top-left-radius: 12upx;
    border-bottom-left-radius: 12upx;
    object-fit: cover;
}

.uni-media-list-body {
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    padding: 20upx;
}

.uni-media-list-text-top {
    font-size: 32upx;
    color: #333;
    font-weight: bold;
    margin-bottom: 10upx;
}

.author {
    font-size: 28upx;
    color: #409eff;
    margin-bottom: 10upx;
    cursor: pointer;
}

.uni-media-list-text-bottom {
    display: flex;
    justify-content: space-between;
    font-size: 24upx;
    color: #999;
	width: 200px;
}
</style>
