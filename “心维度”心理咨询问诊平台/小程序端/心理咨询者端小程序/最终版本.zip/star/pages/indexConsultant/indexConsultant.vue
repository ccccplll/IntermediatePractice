<template>
  <view class="container">
	<view class="top">
		<image :src="details.avatar" class="avatar-img"></image>
		<view class="info-section">
		  <view class="details">
			<text class="name">{{ details.name }}【{{ details.title }}】</text>
		    <text class="time">{{ details.time }}小时经验</text>
		    <text class="price">{{ details.price }}元/时</text>
			<view class="star">
				<text class="pingfen">评分：{{rateValue}}</text>
				<uni-rate size="20" :value="rateValue" :readonly="true"/>
			</view>
		  </view>
		</view>
	</view>
	<view class="middle">
		<uni-group title="个人简介" mode="card">
			<view class="section">
			  <text class="section-title">擅长领域</text>
			  <text class="section-content">{{ details.strength }}</text>
			</view>
			<view class="section">
			  <text class="section-title">咨询时间</text>
			  <text class="section-content">{{ details.startTime }} - {{ details.finishTime }}</text>
			</view>
			<view class="section">
			  <text class="section-title">联系方式</text>
			  <text class="section-content">电话：{{ details.phone }}</text>
			  <text class="section-content">邮箱：{{ details.email }}</text>
			</view>
			<view class="section">
			  <text class="section-title">从业资格</text>
			  <view class="certifications">
				  <image v-for="(cert, index) in certifications" :key="index" :src="cert" class="cert-img"/>
			  </view>
			</view>
		</uni-group>
		<uni-group title="自我介绍" mode="card">
			<view class="section">
			  <text class="section-content">{{ details.introduction }}</text>
			</view>
		</uni-group>
	</view>
	<view class="bottom">
		<uni-group title="Ta的评价" mode="card">
			<view v-for="(comment,index) in comments" :key="index" class="comment">
				<view class="comment-item">
					<view class="comment-avatar">
						<image :src="commentAvatar"></image>
					</view>
					<view class="right">
						<view class="nameStar">
							<view class="comName">用**{{comment.appoint_id}}</view>
							<uni-rate size="20" :value="comment.score" :readonly="true"/>
						</view>
						<view class="commentTime">{{comment.time}}</view>
						<view class="commentText">{{comment.content}}</view>
					</view>
				</view>
			</view>
		</uni-group> >
	</view>
    <view class="button-container">
      <button 
        class="action-button" 
        v-if="!isBooked" 
        @click="handleBooking">{{ details.way === '语音咨询' ? '语音咨询' : '线下咨询' }}</button>
      <button 
        class="action-button booked" 
        v-if="isBooked" 
        @click="handleCancelBooking">已预约</button>
    </view>
  </view>
</template>


<script>
export default {
  data() {
    return {
      p_id: '',
      u_id: '',
      isBooked: false,
      details: {}, 
	  rateValue:'',
	  certifications:[],
	  comments:[],
	  commentAvatar:'',
    };
  },
  onLoad(option) {
    this.p_id = option.id;
    this.fetchConsultantDetail();
	this.fetchPicture();
	this.fetchRandomAvatar();
	this.fetchCommentValue();
	this.getUserID(getApp().globalData.userName, () => {
	  this.isOrdered();
	});
  },
  methods: {
	isOrdered(){
		uni.request({
			url:'http://localhost:3000/isOrdered',
			method:'GET',
			data: {
			  u_id: this.u_id,
			  c_id: this.details.id,
			  p_id: this.p_id,
			},
			success: (res) => {
				if(res.data.length === 0){
					this.isBooked = false;
				}else{
					this.isBooked = true;
				}
			},
			fail: (err) => {
				console.log(err);
			}
		})
	},
    fetchConsultantDetail() {
      uni.request({
        url: 'http://localhost:3000/getConsultantDetail',
        method: 'GET',
        data: { p_id: this.p_id },
        success: (res) => {
          console.log(res);
          const data = res.data[0];
          this.details = {
            id: data.id,
            avatar: data.avatar,
            name: data.trueName,
            title: '成熟咨询师',
            time: data.accumulatedHour,
            price: data.price,
            introduction: data.introduction,
            strength: data.strength,
            startTime: this.formatDate(new Date(data.start_time)),
            finishTime: this.formatDate(new Date(data.finish_time)),
            phone: data.phoneNumber,
            email: data.email,
            way: data.consult_way,
          };
        },
        fail: (err) => {
          console.log(err);
          uni.showToast({
            title: '数据获取失败',
            icon: 'none',
          });
        },
      });
    },
    formatDate(date) {
      const pad = (n) => (n < 10 ? '0' + n : n);
      return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())} ${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
    },
	fetchPicture(){
		uni.request({
			url:'http://localhost:3000/getCertificationP',
			method:'GET',
			data:{p_id:this.p_id},
			success: (res) => {
				res.data.forEach(item => {
					this.certifications.push(item.image);
				});
			},
			fail: (err) => {
				console.log(err);
			}
		})
	},
	fetchRandomAvatar(){
		let src = "../../static/可爱粽子.png";
		this.commentAvatar = src;
	},
	fetchCommentValue(){
		uni.request({
			url:'http://localhost:3000/getCommentValue',
			method:'GET',
			data:{p_id:this.p_id},
			success: (res) => {
				let total=0;
				let index=0;
				res.data.forEach(item => {
					const order={
						appoint_id:item.appoint_id,
						score:item.score,
						time:item.time,
						content:item.content,
					};
					this.comments.push(order);
					total+=item.score;
					index++;
				});
				if(total > 0){
					this.rateValue=total/index;
				}else{
					this.rateValue=0;
				}
			},
			fail: (err) => {
				console.log(err);
			}
		})
	},
    handleBooking() {
      if (getApp().globalData.userName) {
        this.getUserID(getApp().globalData.userName, () => {
          this.insertOrder();
        });
      } else {
        uni.showToast({
          title: '用户名未定义',
          icon: 'none',
        });
      }
    },
    handleCancelBooking() {
      console.log("Canceling consultation");
      this.deleteOrder();
    },
    getUserID(name, callback) {
      uni.request({
        url: 'http://localhost:3000/selectInfor',
        method: 'GET',
        data: { name: name },
        success: (res) => {
          this.u_id = res.data[0].id;
          callback();
        },
        fail: (err) => {
          console.log(err);
        }
      });
    },
    insertOrder() {
      let now = new Date();
      let current = this.formatDate(now);
      uni.request({
        url: 'http://localhost:3000/insertOrder',
        method: 'POST',
        data: {
          u_id: this.u_id,
          c_id: this.details.id,
          p_id: this.p_id,
          createTime: current,
          state: '待支付',
          consult_way: this.details.way,
        },
        success: (res) => {
          console.log(res);
          this.isBooked = true;
          uni.showToast({
            title: '预约成功',
            icon: 'success',
          });
        },
        fail: (err) => {
          console.log(err);
        }
      });
    },
    deleteOrder() {
      uni.request({
        url: 'http://localhost:3000/deleteOrder',
        method: 'POST',
        data: {
          u_id: this.u_id,
          c_id: this.details.id,
		  p_id: this.p_id,
        },
        success: (res) => {
          console.log(res);
          this.isBooked = false;
          uni.showToast({
            title: '取消预约成功',
            icon: 'success',
          });
        },
        fail: (err) => {
          console.log(err);
        }
      });
    },
  },
};
</script>

<style lang="scss">
.container {
  display: flex;
  flex-direction: column;
  padding: 0rpx;
  //background-color: #23d0f7;
  min-height: 100vh;
}

.top {
  display: flex;
  flex-direction: row;
  align-items: center;
  padding: 20rpx;
  background-color: #23d0f7;
  //background-image: linear-gradient(180deg, #23d0f7, #fff);
  border-radius: 0 0 20% 20%;
}

.avatar-img {
  width: 160rpx;
  height: 160rpx;
  border-radius: 50%;
  overflow: hidden;
  margin-right: 20rpx;
  margin-bottom: 40rpx;
  margin-left: 30rpx;
}

.info-section {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  margin-left: 10rpx;
  //width: 100%;
}

.details {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  color: #fff;
  text-align: center;
}

.name {
  font-size: 40rpx;
  font-weight: bold;
  margin-bottom: 10rpx;
}

.time, .price {
  font-size: 24rpx;
  margin-bottom: 10rpx;
}

.star {
  display: flex;
  align-items: flex-start;
  justify-content: center;
}

.pingfen{
	font-size: 28rpx;
	margin-right: 10rpx;
}

.middle {
  margin-top: 40rpx;
}

.section {
  display: flex;
  flex-direction: column;
  padding: 10rpx;
  //border-bottom: 1px solid #ddd;
}

.section-title {
  font-size: 32rpx;
  font-weight: bold;
  margin-bottom: 20rpx;
}

.section-content {
  font-size: 28rpx;
  color: #333;
}

.certifications {
  display: flex;
  flex-wrap: wrap;
}

.cert-img {
  width: 200rpx;
  height: 200rpx;
  margin: 5rpx;
}

.bottom {
  margin-top: 40rpx;
  background-color: #fff;
  border-radius: 10rpx;
}

.comment {
  display: flex;
  flex-direction: column;
  margin-bottom: 20rpx;
}

.comment-item {
  display: flex;
  flex-direction: row;
  border-bottom: 1px solid #ddd;
  &:last-child{border-bottom: 0;}
}

.comment-avatar{
	margin-top: 0px;
}

.comment-avatar image{
  padding-top: 0px;
  width: 80rpx;
  height: 80rpx;
  border-radius: 50%;
  margin-right: 20rpx;
}

.right {
  display: flex;
  flex-direction: column;
}

.nameStar {
  display: flex;
  flex-direction: row;
  align-items: center;
  //justify-content: space-between;
  margin-top: 10rpx;
  margin-bottom: 10rpx;
}

.comName {
  font-size: 30rpx;
  font-weight: bold;
  margin-right: 20rpx;
}

.commentTime {
  font-size: 24rpx;
  color: #333;
}

.commentText{
  margin-top: 20rpx;
  font-size: 28rpx;
  color: #333;
}

.button-container {
  position: fixed;
  bottom: 0;
  width: 100%;
  display: flex;
  justify-content: center;
  padding: 10rpx;
  background-color: #fff;
  border-top: 1px solid #ddd;
}

.action-button {
  width: 300rpx;
  height: 80rpx;
  background-color: #4caf50;
  color: #fff;
  border: none;
  border-radius: 40rpx;
  text-align: center;
  line-height: 80rpx;
  font-size: 32rpx;
}

.action-button.booked {
  background-color: #aaa;
}
</style>