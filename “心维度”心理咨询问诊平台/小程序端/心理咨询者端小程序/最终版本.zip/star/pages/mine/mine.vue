<template>
	<view class="container">
		<view class="top">
		  <navigator url="/pages/basicInfor/basicInfor">
		    <image src="../../static/个人信息  1.png" mode="aspectFill"></image>
		  </navigator>
		  <view class="touxiang">
		    <view class="n1" @click="chooseImage">
		      <image :src="avatarUrl"></image>
		    </view>
		    <view class="name">{{ name }}</view>
		    <view class="address">{{ address }}</view>
		  </view>
		</view>
		<view class="middle">
		  <view class="test">
		    <navigator url="/pages/test/test">
		      <image src="../../static/心理测评.png" mode="aspectFill"></image>
		    </navigator>
		    <text>心理测评</text>
		  </view>
		  <view class="consult">
		    <view class="navigator1" @click="calendar">
		      <image src="../../static/心理咨询.png" mode="aspectFill"></image>
		    </view>
		    <text>心理咨询</text>
		  </view>
		  <view class="order">
		    <navigator url="/pages/items/items">
		      <image src="../../static/订单.png" mode="aspectFill"></image>
		    </navigator>
		    <text>我的订单</text>
		  </view>
		  <view class="grow">
		    <navigator url="/pages/grow/grow">
		      <image src="../../static/成长日记.png" mode="aspectFill"></image>
		    </navigator>
		    <text>AI助手</text>
		  </view>
		</view>
		<view class="bottom">
		  <view class="list">
		    <view class="row">
		      <view class="left">
		        <image src="../../static/耳机.png" mode="aspectFill"></image>
		        <view class="text">申请咨询师</view>
		      </view>
		      <view class="right">
		        <image src="../../static/右箭.png" mode="aspectFill"></image>
		      </view>
		      <button @click="apply">申请咨询师</button>
		    </view>
		    <view class="row">
		      <view class="left">
		        <image src="../../static/设置.png" mode="aspectFill"></image>
		        <view class="text">设置</view>
		      </view>
		      <view class="right">
		        <image src="../../static/右箭.png" mode="aspectFill"></image>
		      </view>
		      <button @click="setup">设置</button>
		    </view>
		    <view class="row">
		      <view class="left">
		        <image src="../../static/联系客服.png" mode="aspectFill"></image>
		        <view class="text">联系客服</view>
		      </view>
		      <view class="right">
		        <image src="../../static/右箭.png" mode="aspectFill"></image>
		      </view>
		      <button open-type="contact">联系客服</button>
		    </view>
		    <view class="row">
		      <view class="left">
		        <image src="../../static/投诉反馈.png" mode="aspectFill"></image>
		        <view class="text">投诉反馈</view>
		      </view>
		      <view class="right">
		        <image src="../../static/右箭.png" mode="aspectFill"></image>
		      </view>
		      <button @click="reflect">投诉反馈</button>
		    </view>
		    <view class="row">
		      <view class="left">
		        <image src="../../static/关于.png" mode="aspectFill"></image>
		        <view class="text">关于</view>
		      </view>
		      <view class="right">
		        <image src="../../static/右箭.png" mode="aspectFill"></image>
		      </view>
		      <button @click="about">关于</button>
		    </view>
		  </view>
		</view>
	</view>
</template>

<script>
export default {
  data() {
    return {
      avatarUrl: '../../static/top_个人信息.png', // 初始化为空字符串
      name: '',
      address: '',
    };
  },
  onLoad() {
    // 页面加载时从本地存储中获取头像地址
    this.avatarUrl = uni.getStorageSync('avatarUrl') || '../../static/top_个人信息.png';
    this.name = getApp().globalData.userName;
    this.setAddress();
  },
  created() {
    this.setAddress();
    uni.$on('cityStatusChanged1', this.setAddress);
  },
  methods: {
    setAddress() {
      const that = this;
      uni.request({
        url: 'http://localhost:3000/getAddress',
        method: 'GET',
        data: { name: getApp().globalData.userName},
        success(res) {
          console.log(res);
          that.address = res.data[0].city; // 使用 that 以确保上下文正确
        },
        fail(err) {
          console.log(err);
        }
      });
    },
    chooseImage() {
      uni.chooseImage({
        count: 1,
        success: (res) => {
          const tempFilePaths = res.tempFilePaths;
          if (tempFilePaths.length > 0) {
            this.avatarUrl = tempFilePaths[0]; // 更新页面上的头像显示
            console.log(this.avatarUrl);
            // 将新的头像地址保存到本地存储中
            uni.setStorageSync('avatarUrl', this.avatarUrl);
          }
        }
      });
    },
    calendar() {
      uni.switchTab({
        url: "/pages/calendar/calendar"
      });
    },
    apply() {
      uni.navigateTo({
        url: "/pages/applyConsultant/applyConsultant"
      });
    },
    setup() {
      uni.navigateTo({
        url: "/pages/setup/setup"
      });
    },
    reflect() {
      uni.navigateTo({
        url: "/pages/reflect/reflect"
      });
    },
    about() {
      uni.navigateTo({
        url: "/pages/about/about"
      });
    }
  }
}
</script>

<style lang="scss" scoped>
.container{
	//background-color: aliceblue;
	height: 100vh;
}

.top {
  //background-image: linear-gradient(180deg, powderblue, #fff);
  background-image: linear-gradient(180deg, aliceblue, #fff);
  //background-color: aliceblue;
  display: flex;
  flex-direction: column;
  padding: 5px 5px;
  navigator {
    width: 35px;
    height: 35px;
    border-radius: 20%;
    overflow: hidden;
    right: 0;
    bottom: 0;
    image {
      width: 100%;
      height: 100%;
    }
  }
  .touxiang {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    .n1 {
      width: 150rpx;
      height: 150rpx;
      border-radius: 100%;
      overflow: hidden;
      image {
        width: 100%;
        height: 100%;
      }
    }
    .name {
      font-size: 40rpx;
      color: #000;
      padding: 5px 0;
    }
    .address {
      font-size: 28rpx;
      color: #aaa;
    }
  }
}
.middle {
  width: 90%;
  margin: 50rpx auto;
  border-radius: 20rpx;
  box-shadow: 0 0 30rpx rgba(0, 0, 0, 0.2);
  display: flex;
  justify-content: space-around;
  padding: 20rpx;
  background: #fff;
  .order, .test, .consult, .grow {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    navigator, .navigator1 {
      width: 80rpx;
      height: 80rpx;
      border-radius: 20%;
      overflow: hidden;
      background: #f5f5f5;
      display: flex;
      justify-content: center;
      align-items: center;
      margin-bottom: 10rpx;
      image {
        width: 100%;
        height: 100%;
      }
    }
    text {
      font-size: 28rpx;
      color: #333;
      text-align: center;
    }
  }
}
.bottom {
  width: 690rpx;
  margin: 50rpx auto;
  border: 1px solid #eee;
  border-radius: 10rpx;
  box-shadow: 0 0 30rpx rgba(0, 0, 0, 0.05);
  background-color: #fff;
  .list {
    .row {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 0 30rpx;
      height: 100rpx;
      position: relative;
      border-bottom: 1px solid #eee;
      //&:last-child{border-bottom: 0;}
      .left {
        display: flex;
        align-items: center;
        image {
          width: 30px;
          height: 30px;
          border-radius: 20%;
          overflow: hidden;
        }
        .text {
          padding-left: 20rpx;
          font-size: 28rpx;
          color: #aaa;
        }
      }
      .right {
        display: flex;
        align-items: center;
        image {
          width: 25px;
          height: 25px;
          border-radius: 20%;
          overflow: hidden;
        }
      }
      button {
        position: absolute;
        top: 0;
        left: 0;
        height: 100rpx;
        width: 100%;
        opacity: 0;
      }
    }
  }
}
</style>
