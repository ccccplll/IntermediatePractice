<template>  
  <view class="login-container">  
  <image class="full-screen-image" src="../../static/loginBackground.jpeg" mode="scaleToFill"></image>
    <view class="login-header">  
      <text class="title">登录</text>  
    </view>  
    <view class="login-body">  
      <input type="text" class="input-item" placeholder="请输入用户名" v-model="username" />  
      <input type="password" class="input-item" placeholder="请输入密码" v-model="password" />  
      <button class="login-btn" @click="login">登录</button>  
    </view>  
    <view class="register" @click="register">去注册</view>
  </view>  
</template>  
  
<script> 
 import moment from 'moment'; 
export default {  
  data() {  
    return {  
      username: '',  
      password: '', 
	   u_id: '',
	   login_time:'',
	   device:'',
	   dateTime:''
    };  
  },  
  methods: {  
    login() {  
      const that = this;  // 保存上下文
      uni.request({
        url: 'http://localhost:3000/getPassword',
        method: 'POST', // 通常使用POST
        data: { userName: that.username },
        success(res) {
          console.log(res);
          if (res.data && res.data.length > 0) {
            if (res.data[0].password !== that.password) {
              uni.showToast({
                title: '密码错误',
                icon: 'none',
                duration: 2000
              });
            } else {
              const app = getApp(); // 获取App实例
              if (app.globalData) {  
                app.globalData.userName = that.username; // 更新全局变量  
              }  
              uni.$emit('cityStatusChanged');
			  
			  uni.request({
			  url: "http://localhost:3000/mmmm1",
			  method: 'get',
			  data:{
			   username:that.username
			  },
			  success: res => {	
			  that.u_id=res.data[0].id;
			  console.log('数据搜索成功',that.u_id);
			  
			  // 获取当前时间
			      var now = new Date();  
			      // 获取当前年份  
			      var year = now.getFullYear();  
			      // 获取当前月份（注意：JavaScript中的月份是从0开始的，所以需要加1）  
			      var month = now.getMonth() + 1;  
			      month = month < 10 ? '0' + month : month; // 格式化月份为两位数  
			      // 获取当前日期  
			      var day = now.getDate();  
			      day = day < 10 ? '0' + day : day; // 格式化日期为两位数  
			      // 获取当前小时  
			      var hour = now.getHours();  
			      hour = hour < 10 ? '0' + hour : hour; // 格式化小时为两位数  
			      // 获取当前分钟  
			      var minute = now.getMinutes();  
			      minute = minute < 10 ? '0' + minute : minute; // 格式化分钟为两位数  
			      // 获取当前秒  
			      var second = now.getSeconds();  
			      second = second < 10 ? '0' + second : second; // 格式化秒为两位数  
			      // 拼接日期时间字符串  
			      var dateTime = year + '-' + month + '-' + day + ' ' + hour + ':' + minute + ':' + second;  
			      
			  	  
			     console.log(dateTime); // 输出格式化后的日期时间字符串
			  
			  
			  
			  uni.request({
				  
			  				    url: 'http://localhost:3000/llll',  
			  				    method: 'POST', 
			  				    data: { 
			  						u_id: that.u_id,
									login_time: dateTime,
									device: 'Android'
			  				    },  
			  				    header: {  
			  				        'content-type': 'application/json'  
			  				    },  
			  				    success: (res) => {  
			  						console.log(that.u_id);
									console.log(that.login_time);
			  				        console.log('插入数据库成功');  
			  				        // 更新UI或进行其他操作  
			  				    },  
			  				    fail: (err) => {  
			  				        console.error('插入失败', err);  
			  				    }  
			  				});
			  			}
			  		});
			  
              // 假设登录成功，你可以在这里进行页面跳转等操作  
              uni.switchTab({ url: '/pages/index/index' });  
            }
          } else {
            uni.showToast({
              title: '用户名错误',
              icon: 'none',
              duration: 2000
            });
          }
        },
        fail(err) {
          console.log(err);
        }
      });
    },
    register() {
      uni.navigateTo({
        url: '/pages/register/register',
      })
    }
  },  
};  
</script>  
  
<style scoped> 
.login-body{
	
	z-index: 2;
}
.full-screen-image {  
    width: 100%;  
    height: 100%;  
    position: absolute;  
    top: 0;  
    left: 0;  
    z-index: 0; /* 确保背景图片不会覆盖其他内容 */  
}  

.login-container {  
  display: flex;  
  flex-direction: column;  
  align-items: center;  
  justify-content: center;  
  height: 100vh;  
  background-color: #f2f2f2;  
}  
  
.login-header {  
  margin-bottom: 20px; 
   z-index:2;
}  
  
.title {  
  font-size: 24px;  
  font-weight: bold;  
  color: #333;  
}  
  
.input-item {  
  margin-bottom: 15px;  
  padding: 10px;  
  border: 1px solid #ccc;  
  border-radius: 5px;  
  font-size: 16px;  
  z-index: 2;
  background-color: #fff;
}  
  
.login-btn {  
  padding: 10px 20px;  
  background-color: #007aff;  
  color: #fff;  
  border: none;  
  border-radius: 5px;  
  font-size: 16px;  
}  
  
.register {  
  margin-top: 20px;  
  color: #007aff;  
  font-size: 16px;  
  cursor: pointer;  
  z-index: 2;
}
</style>
