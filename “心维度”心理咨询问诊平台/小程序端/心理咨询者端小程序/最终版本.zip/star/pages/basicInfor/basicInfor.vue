<template>  
  <view class="container">  
    <form @submit="formSubmit" @reset="formReset">  
      <view class="form-group1">  
        <label>昵称</label>  
        <input v-model="formData.name" type="text" placeholder="请输入昵称" />  
      </view>  
	  <view class="form-group1">
		  <label>年龄</label>
		  <input v-model="formData.age" type="number" placeholder="请输入年龄"/>
	  </view>
      <view class="form-group2">  
        <label>性别</label>  
        <radio-group @change="radioChange">  
          <label class="radio-label">  
            <radio :value="'男'" :checked="sex == '男'" /> 男  
          </label>  
          <label class="radio-label">  
            <radio :value="'女'" :checked="sex == '女'" /> 女  
          </label>  
        </radio-group>  
      </view>  
      <view class="form-group1">  
        <label>手机号</label>  
        <input type="text" v-model="formData.phoneNumber" placeholder="请输入手机号" />  
      </view>  
	  <view class="form-group1">
		  <label>邮箱</label>
		  <input v-model="formData.email" type="text" placeholder="请输入邮箱地址"/>
	  </view>
      <view class="form-group1">  
        <label>地址</label>  
        <input type="text" v-model="formData.city" placeholder="请输入城市" />  
      </view>  
      <view class="form-group3">  
        <label>简介</label>  
        <textarea v-model="formData.introduction" placeholder="点击添加简介"></textarea>  
      </view> 
	   <view class="button">
		   <button form-type="submit">确认</button>
		   <button form-type="reset">重置</button>
	   </view>
    </form>  
  </view>  
</template>  
  
<script>  
export default {  
  onLoad() {
  	this.formData.name = getApp().globalData.userName;
	this.priName = this.formData.name;
	//const name = encodeURIComponent(this.formData.name); // 对 name 进行 URL 编码
	uni.request({
		url:'http://localhost:3000/selectInfor?name='+encodeURIComponent(this.formData.name),
		method:'GET',
		success: (res) => {
			console.log(res.data[0]);
			if(res.data){
				Object.assign(this.formData,res.data[0]);
				console.log('传递成功', res.data);
			}  else{
				console.log('没有接收到数据');
			}
		},
		fail: (err) => {
			console.error('传递失败', err); 
		}
	});
  },
  data() {  
    return {  
	  priName:'',
      formData: {  
        name: '', 
		age: '',
		city: '',
        sex: '',  
		email: '',
        phoneNumber: '',  
        //introduction: '',  name, age, city, sex, email, phoneNumber
      },  
    };  
  },  
  methods: {  
	radioChange(evt){
		console.log(evt);
		this.formData.sex = evt.detail.value;
		console.log(this.formData.sex);
	},
    formSubmit(e) {  
		e.preventDefault(); // 阻止表单默认提交行为  
	    this.sendDataToServer();  // 发送数据到服务器  
    },  
	sendDataToServer() {  
	  const { priName, formData } = this;  
	  const dataToSend = {};  
	  for (const key in formData) {  
	    if (formData[key] !== '' && formData[key] !== null && formData[key] !== undefined) {  
	      dataToSend[key] = formData[key];  
	    }  
	  }  
	  const app = getApp(); // 获取App实例  
	  if (app.globalData) {  
		app.globalData.userName = this.formData.name; // 更新全局变量  
      }  
	  const requestData = {  
	    priName,  
	    ...dataToSend,  
	  };  
	  uni.request({  
	    url: 'http://localhost:3000/updateUser',  
	    method: 'POST',  
	    header: {  
	      'content-type': 'application/json',  
	    },  
	    data: requestData,  // 不需要 JSON.stringify  
	    success: (res) => {  
	      console.log('更新成功', res.data);  
	      // 更新UI或进行其他操作  
		  uni.$emit('cityStatusChanged');
		  uni.$emit('cityStatusChanged1');
	    },  
	    fail: (err) => {  
	      console.error('更新失败', err);  
	    }  
	  });  
	},
    formReset() {  
      // 退出登录操作  
      console.log('执行退出登录操作');  
      // 这里可以添加退出登录的逻辑，如清除用户信息等  
    },  
  },  
};  
</script>  
  
<style lang="scss">  
.container {  
  padding: 20px;  
}  
  
.form-group1 {  
  margin-bottom: 20px;  
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: first baseline;
}  
.form-group2{
	margin-bottom: 20px;
	display: flex;
	flex-direction: row;
	align-items: center;
	justify-content: first baseline;
	radio-group{
		display: flex;
		flex-direction: row;
		align-items: center;
		justify-content: space-between;
	}
}
.form-group3{
	margin-bottom: 20px;
	display: flex;
	flex-direction: row;
	align-items: center;
	justify-content: first baseline;
}

label {  
 width: 150rpx;
  display: block;  
  margin-bottom: 5px;  
}  
  
input,  
textarea {  
  width: 100%;  
  padding: 10px;  
  border: 1px solid #ccc;  
  border-radius: 5px;  
}  
  
.radio-label {  
  display: flex;  
  align-items: center;  
  //margin-bottom: 10px;  
}  
  
.button{
	height: 80rpx;
	display: flex;
	flex-direction: row;
	align-items: center;
	justify-content: space-between;
	//background-color: #409eff;
	button{
	  width: 35%;
	  height: 100rpx;
	  background-color: #409eff;  
	  color: #fff;  
	  border: none;  
	  border-radius: 5px;  
	  cursor: pointer;  
	  text-align: center;
	  font-size: 36rpx;
	}  
}
</style>