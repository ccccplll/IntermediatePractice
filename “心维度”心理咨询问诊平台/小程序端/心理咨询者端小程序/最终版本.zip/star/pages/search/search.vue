<template>
			<scroll-view :scroll-top="screenTop"
			  scroll-y class="scroll-y" @scrolltoupper="upper" @scrolltolower="lower" @scroll="scroll" >
			  <view>  
			      <view v-for="(consultant, index) in consultants" :key="index" class="scroll-view-item" @click="consultantInformation(consultant)">  
			        <view class="botton-top">  
			          <view class="touxiang">  
			            <image :src="consultant.imageUrl"></image>  
			          </view>  
			          <view class="right">  
			            <view class="name">{{ consultant.name }}</view>  
			            <view class="time">{{ consultant.experience }}</view>  
						 <text class="size1">{{consultant.shijian1}} {{consultant.shijian11}}</text>
			            <view class="introduce-view">  
			              <view class="introduce">{{ consultant.introduce }}</view>  
			            </view> 
						 
			            <view class="taf">  
			              <view class="price">{{ consultant.price }}</view>  
			              <view class="function">{{ consultant.type }}</view>  
			            </view>  
			          </view>  
			        </view>  
			        <view class="address">{{ consultant.city }}</view>  
			      </view>  
			    </view>  		
			        </scroll-view>	
				
	</template>
	
	<script>
		import moment from 'moment'; 
		 export default {
			 data() {
			 	return {
			 		 consultants: [], // 用于存储从服务器获取的数据  
			 		
			 		}
			 		},
			onLoad({name}) {
					this.nameee = name; 
					console.log('onLoad called',this.nameee);
				    this.information(this.nameee); // 组件挂载后立即获取数据  
				  } ,	
		    methods:{
				consultantInformation(consultant){
					 uni.navigateTo({
					    url:`../sos/sos?message=${consultant.shijian1}`
						
					  });  
								  console.log("到底是哪啊");
				},
				
					information(nameee) { 
						uni.request({
						         url: 'http://localhost:3000/?nameee='+this.nameee,
						         method: 'get',
						         success: res => {
									 if (res.data && Array.isArray(res.data)) {  
									             this.consultants = res.data.map(item => ({  
									               imageUrl: item.avatar || '',  
									               name: item.trueName || '',  
									               experience: (item.accumulatedHour || 0) + '小时经验',  
									               introduce: item.introduction || '',  
									               price: (item.price || 0) + '元/时',  
									               type: item.consult_way || '',  
									               city: item.city || '', 
												   shijian1 :moment(item.start_time).format('YYYY-MM-DD HH:mm:ss') || '',
												   shijian11:moment(item.finish_time).format('YYYY-MM-DD HH:mm:ss') || ''
									             }));  
									           }
						         console.log('数据搜索成功',res.data);
								 }
		
						            })	
							
							
					},
					}
					}
	</script>


<style lang="scss">
	.scroll-Y {
	            height: 300rpx;
	    }
	    
	    .scroll-view-item {
	        height: 300rpx;
	        display: flex;
	        flex-direction: column;
	       // border: 1rpx solid gainsboro;
	        //&:last-child{border-bottom: 0;}
	        .botton-top{
	            width: 100%;
	            height: 258rpx;
	            display: flex;
	            flex-direction: row;
	            align-items: center;
	            //border: 1rpx solid skyblue;
	            .touxiang{
	                width: 160rpx;
	                height: 160rpx;
	                border-radius: 100%;
	                overflow: hidden;
	                margin: 25rpx;
	                //border: 1rpx solid skyblue;
	                image{
	                    width: 100%;
	                    height: 100%;
	                }
	            }
	            .right{
	                display: flex;
	                flex-direction: column;
	                align-items: flex-start;
	                height: 218rpx;
	                padding-top: 25rpx;
	                //border: 1rpx solid skyblue;
	                .name{
	                    padding: 5rpx;
	                    font-size: 40rpx;
	                    //border: 1rpx solid skyblue;
	                }
	                .time{
	                    padding: 5rpx;
	                    font-size: 28rpx;
	                    //border: 1rpx solid skyblue;
	                }
	                .introduce-view{
	                    padding: 5rpx;
	                    //font-size: 30rpx;
	                    overflow: hidden;
	                    white-space: nowrap;
	                    text-overflow: ellipsis;
	                    width: 200px;
	                    //border: 1rpx solid skyblue;
	                    .intriduce{
	                        font-size: 30rpx;
	                    }
	                }
	                .taf{
	                    padding: 5rpx;
	                    display: flex;
	                    flex-direction: row;
	                    align-items: center;
	                    justify-content: space-between;
	                    width: 130px;
	                    //border: 1rpx solid skyblue;
	                    .price{
	                        font-size: 28rpx;
	                        text-align: right;
	                        //border: 1rpx solid skyblue;
	                    }
	                    .function{
	                        font-size: 28rpx;
	                        text-align: right;
	                        //border: 1rpx solid skyblue;
	                    }
	                }
	            }
	        }
	        
	        .address{
	            //border: 1rpx solid skyblue;
	            font-size: 30rpx;
	            text-align: right;
	            padding: 6rpx;
	        }
	    }
 
</style>
