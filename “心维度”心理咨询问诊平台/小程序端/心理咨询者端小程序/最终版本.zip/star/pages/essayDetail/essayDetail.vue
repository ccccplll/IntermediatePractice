<template>
    <view>
        <view class="banner">
            <image class="banner-img" :src="banner.cover"></image>
            <view class="banner-title">{{banner.title}}</view>
        </view>
        <view class="article-meta">
            <text class="article">作者：{{banner.author_name}}</text>
            <text class="article">时间：{{banner.published_at}}</text>
        </view>
		<view class="essay" space="emsp">&nbsp;&nbsp;&nbsp;&nbsp;{{banner.content}}</view>
    </view>
</template>
<script>
    export default {
        data() {
            return {
				banner:'',
				id:'',
			}
        },
        onLoad(event) {
            console.log(event);
			this.id = event.id;
            this.fetchEssay();
        },
        methods: {
			fetchEssay(){
				uni.request({
					url:'http://localhost:3000/getOneEssay',
					method:'GET',
					data:{id:this.id},
					success: (res) => {
						this.banner = {
							id:this.id,
							cover:res.data[0].img_src,
							title:res.data[0].title,
							author_name:res.data[0].trueName,
							published_at:this.formatDate(new Date(res.data[0].time)),
							content:res.data[0].content,
						};
						//详情标题
						uni.setNavigationBarTitle({
						    title: this.banner.title
						});
					}
				})
			},
			formatDate(dateString) {
			    const date = new Date(dateString);
			    return `${date.getFullYear()}-${date.getMonth() + 1}-${date.getDate()} ${date.getHours()}:${date.getMinutes()}`;
			}
        }
    }
</script>
<style lang="scss">
.banner {
    height: 360upx;
    overflow: hidden;
    position: relative;
    background-color: #ccc;
}

.banner-img {
    width: 100%;
}

.banner-title {
    max-height: 84upx;
    overflow: hidden;
    position: absolute;
    left: 30upx;
    bottom: 30upx;
    width: 90%;
    font-size: 32upx;
    font-weight: 400;
    line-height: 42upx;
    color: white;
    z-index: 11;
}

.essay {
    margin: 30upx; /* Increased margin for better readability */
    font-size: 28upx; /* Adjusted font size for content */
    color: #333; /* Darkened text color for better contrast */
    line-height: 40upx; /* Improved line height for better spacing */
}

.article {
    margin: 20upx; /* Adjusted margin for meta information */
    color: #aaa; /* Lightened meta text color */
    font-size: 24upx;
}
</style>
