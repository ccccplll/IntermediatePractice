const express = require('express');
const multer = require('multer');
const bodyParser = require('body-parser');
const path = require('path');
const cors = require('cors'); // 引入 cors 模块
const app = express();
const port = 3001;

// 设置 multer 存储配置
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    cb(null, `${Date.now()}-${file.originalname}`);
  }
});

const upload = multer({ storage: storage });

// 使用 bodyParser 中间件
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// 使用 cors 中间件，允许所有来源的跨域请求
const corsOptions = {
  origin: 'http://localhost:3000', // 允许特定来源的跨域请求，多个来源可以用逗号分隔
  methods: ['GET', 'POST'], // 允许的 HTTP 方法
  allowedHeaders: ['Content-Type'], // 允许的头部信息
  credentials: true, // 允许发送 cookie
};

app.use(cors(corsOptions));

// 处理文件上传请求
app.post('/uploadFile', upload.single('file'), (req, res) => {
  if (req.file) {
    res.json({
      success: true,
      url: `http://localhost:${port}/uploads/${req.file.filename}`
    });
  } else {
    res.status(400).json({ success: false, message: '上传失败' });
  }
});

// 静态文件服务，用于访问上传的文件
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
