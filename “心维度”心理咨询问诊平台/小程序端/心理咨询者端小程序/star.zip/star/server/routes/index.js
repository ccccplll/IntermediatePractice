var express = require('express');
var router = express.Router();
var connection=require('../database/sql.js');

router.get("/", function(req, res, next) {  
    // 假设您从查询字符串中获取了一个名为"name"的参数  
    let name = req.query.name; 
    connection.query("SELECT * FROM Consultant WHERE true_name = ?", [name], function(error, results, fields) {  
        if (error) {  
            throw error;  
        }  
        console.log('The solution is: ', results);  
        res.json(results);  
    });  
});

router.get("/test", function(req, res, next) {  
    // 假设您从查询字符串中获取了一个名为"city"的参数  
    let city = req.query.city; 
    connection.query("SELECT * FROM Consultant WHERE city = ?", [city], function(error, results, fields) {  
        if (error) {  
            throw error;  
        }  
        console.log('The solution is: ', results);  
        res.json(results);  
    });  
});

router.get("/test2", function(req, res, next) {  
    // 假设您从查询字符串中获取了一个名为"name"的参数  
    let name1 = req.query.name1; 
    connection.query("SELECT * FROM predecide WHERE price = ?", [name1], function(error, results, fields) {  
        if (error) {  
            throw error;  
        }  
        console.log('The solution is: ', results);  
        res.json(results);  
    });  
});





module.exports = router;
