<template>  
  <view class="container">  
    <form @submit.prevent="onSubmit">  
      <view class="form-group">  
        <label>姓名</label>  
        <input type="text" placeholder="请输入姓名" />  
      </view>  
      <view class="form-group">  
        <label>性别</label>  
        <radio-group>  
          <label class="radio-label">  
            <radio :value="'男'" /> 男  
          </label>  
          <label class="radio-label">  
            <radio :value="'女'" /> 女  
          </label>  
        </radio-group>  
      </view>  
      <view class="form-group">  
        <label>手机号</label>  
        <input type="text" v-model="formData.phone" placeholder="请输入手机号" />  
      </view>  
      <!-- 注意：地址和简介部分在图片中被遮挡，这里仅作为示例保留结构 -->  
      <view class="form-group" v-if="false">  
        <label>地址</label>  
        <input type="text" v-model="formData.address" placeholder="请选择地区" />  
      </view>  
      <view class="form-group" v-if="false">  
        <label>简介</label>  
        <textarea v-model="formData.introduction" placeholder="点击添加简介"></textarea>  
      </view>  
      <button type="button" @click="logout">退出登录</button>  
    </form>  
  </view>  
</template>  
  
<script setup>  
/*export default {  
  data() {  
    return {  
      formData: {  
        name: '',  
        gender: '',  
        phone: '',  
        address: '',  
        introduction: '',  
      },  
    };  
  },  
  methods: {  
    onSubmit() {  
      // 处理表单提交逻辑  
      console.log(this.formData);  
      // 这里可以添加提交表单到服务器的逻辑  
    },  
    logout() {  
      // 退出登录操作  
      console.log('执行退出登录操作');  
      // 这里可以添加退出登录的逻辑，如清除用户信息等  
    },  
  },  
};  */
</script>  
  
<style>  
.container {  
  padding: 20px;  
}  
  
.form-group {  
  margin-bottom: 20px;  
}  
  
label {  
  display: block;  
  margin-bottom: 5px;  
}  
  
input,  
textarea {  
  width: 100%;  
  padding: 10px;  
  border: 1px solid #ccc;  
  border-radius: 5px;  
}  
  
.radio-label {  
  display: flex;  
  align-items: center;  
  margin-bottom: 10px;  
}  
  
button {  
  padding: 10px 20px;  
  background-color: #409eff;  
  color: #fff;  
  border: none;  
  border-radius: 5px;  
  cursor: pointer;  
}  
</style>