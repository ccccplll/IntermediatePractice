<template>  
  <view class="container">  
    <view class="search-bar">  
      <input type="text" placeholder="心维度 搜索订单" class="search-input" v-model="searchQuery" />  
    </view>  
    <view class="tab-bar">  
      <text class="tab-item" @tap="filterOrders('all')">全部</text>  
      <text class="tab-item" @tap="filterOrders('pending')">待确认</text>  
      <text class="tab-item" @tap="filterOrders('processing')">待完成</text>  
      <text class="tab-item" @tap="filterOrders('completed')">已完成</text>  
    </view>  
    <view class="order-list">  
      <block v-for="(order, index) in filteredOrders" :key="order.id">  
        <navigator :url="'/orderDetail/' + order.id" class="order-item">  
          <view class="order-status">  
            <text v-if="order.status === 'pending'" class="status-pending">待确认</text>  
            <text v-if="order.status === 'processing'" class="status-processing">待完成</text>  
            <text v-if="order.status === 'completed'" class="status-completed">已完成</text>  
          </view>  
          <view class="order-info">  
            <text>订单{{ index + 1 }}</text>  
          </view>  
        </navigator>  
      </block>  
    </view>  
  </view>  
</template>  
  
<script>  
export default {  
  data() {  
    return {  
      searchQuery: '',  
      orders: [  
        { id: 1, status: 'processing' },  
        { id: 2, status: 'pending' },  
        { id: 3, status: 'completed' }  
      ],  
      filteredOrders: []  
    };  
  },  
  methods: {  
    filterOrders(status) {  
      this.filteredOrders = this.orders.filter(order => order.status === status || status === 'all');  
    }  
  },  
  mounted() {  
    this.filterOrders('all'); // 默认显示全部订单  
  }  
};  
</script>  
  
<style>  
.container {  
  padding: 10px;  
}  
  
.search-bar {  
  display: flex;  
  align-items: center;  
  margin-bottom: 10px;  
}  
  
.search-input {  
  flex: 1;  
  padding: 5px;  
  border-radius: 5px;  
  border: 1px solid #ccc;  
}  
  
.tab-bar {  
  display: flex;  
  justify-content: space-around;  
  margin-bottom: 10px;  
}  
  
.tab-item {  
  padding: 5px 10px;  
  border-radius: 5px;  
  cursor: pointer;  
  user-select: none;  
}  
  
.tab-item:active {  
  background-color: #eee;  
}  
  
.order-list {  
  display: flex;  
  flex-direction: column;  
}  
  
.order-item {  
  display: flex;  
  justify-content: space-between;  
  align-items: center;  
  padding: 10px;  
  border-bottom: 1px solid #eee;  
}  
  
.order-status {  
  width: 80px;  
  text-align: center;  
}  
  
.status-pending {  
  color: #007AFF;  
}  
  
.status-processing {  
  color: #FFA500;  
}  
  
.status-completed {  
  color: #00C853;  
}  
  
.order-info {  
  flex: 1;  
}  
</style>