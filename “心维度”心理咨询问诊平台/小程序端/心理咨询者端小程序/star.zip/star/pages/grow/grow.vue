<template>
	<view>
		<view ref="chartContainer" class="chart-container"></view>
	</view>
</template>

<script setup>
	/*import * as echarts from 'echarts'  // 引入ECharts库

	export default {
		data() {
			return {
				
			}
		},
		mounted() {
		  this.initChart()
		},
		methods: {
		  initChart() {
		    const chartContainer = this.$refs.chartContainer  // 获取图表容器 DOM
		    this.chart = echarts.init(chartContainer)  // 创建ECharts实例并传入图表容器
			const option = {
			      title: {
			        text: '柱状图示例' // 标题文本
			      },
			      xAxis: {
			        type: 'category', // x轴类型为类目轴
			        data: ['项目1', '项目2', '项目3', '项目4'] // x轴类目数据
			      },
			      yAxis: {
			        type: 'value' // y轴类型为数值轴
			      },
			      series: [{
			        type: 'bar', // 图表类型为柱状图
			        data: [120, 200, 150, 80] // 柱状图数据
			      }]
			    }
			this.chart.setOption(option) // 将配置应用到图表实例
		  }
		}
	}*/
</script>

<style>
.chart-container{
	width: 100vw;
	height: 300rpx;
}
</style>
