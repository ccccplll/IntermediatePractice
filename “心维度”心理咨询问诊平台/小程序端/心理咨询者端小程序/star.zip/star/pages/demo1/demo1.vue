<template>
	<view class="tui">
	<uni-notice-bar show-icon scrollable
			text="uni-app 版正式发布，开发一次，同时发布iOS、Android、H5、微信小程序、支付宝小程序、百度小程序、头条小程序等7大平台。" />
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		}
	}
</script>

<style lang="scss">
.tui{
			width: 100vw;
			height:60rpx;
			//font-size: 40rpx;
			padding: 5rpx;
			uni-notice-bar{
				width: 100vw;
				height: 50rpx;
			}
		}
</style>
