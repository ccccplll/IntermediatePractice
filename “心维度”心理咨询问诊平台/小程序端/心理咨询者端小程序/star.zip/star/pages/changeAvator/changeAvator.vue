<template>  
  <view class="profile-settings">  
    <view class="header">  
      <text class="title">心维度</text>  
    </view>  
    <view class="profile-content">  
      <image class="avatar" src="/static/avatar.png" mode="aspectFit"></image>  
      <input class="nickname-input" type="text" placeholder="请输入昵称" v-model="nickname" />  
    </view>  
  </view>  
</template>  
  
<script>  
export default {  
  data() {  
    return {  
      nickname: ''  
    };  
  }  
};  
</script>  
  
<style>  
.profile-settings {  
  display: flex;  
  flex-direction: column;  
  align-items: center;  
  justify-content: center;  
  height: 100vh;  
  padding: 20px;  
}  
  
.header {  
  text-align: center;  
  margin-bottom: 20px;  
}  
  
.title {  
  font-size: 20px;  
  font-weight: bold;  
  color: #007AFF; /* 假设蓝色背景文字的颜色 */  
}  
  
.profile-content {  
  display: flex;  
  flex-direction: column;  
  align-items: center;  
}  
  
.avatar {  
  width: 100px;  
  height: 100px;  
  border-radius: 50%; /* 圆形头像 */  
  margin-bottom: 10px;  
}  
  
.nickname-input {  
  width: 200px;  
  height: 30px;  
  border: 1px solid #ccc;  
  border-radius: 5px;  
  padding: 5px;  
  margin-top: 10px;  
}  
</style>