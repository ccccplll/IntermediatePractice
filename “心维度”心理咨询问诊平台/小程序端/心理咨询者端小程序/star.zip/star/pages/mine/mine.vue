<template>
	<view class="top">
		<navigator url="/pages/basicInfor/basicInfor">
			<image src="../../static/个人信息  1.png" mode="aspectFill"></image>
		</navigator>
		<view class="touxiang">
			<navigator url="/pages/changeAvator/changeAvator">
				<image src="../../static/top_个人信息.png"></image>
			</navigator>
			<view class="name">用户596</view>
			<view class="address">武汉</view>
		</view>
	</view>
	<view class="middle">
		<view class="test">
			<navigator url="/pages/test/test">
				<image src="../../static/心理测评.png" mode="aspectFill"></image>
			</navigator>
			<text>心理测评</text>
		</view>
		<view class="consult">
			<navigator url="/pages/demo1/demo1">
				<image src="../../static/心理咨询.png" mode="aspectFit"></image>
			</navigator>
			<text>心理咨询</text>
		</view>
		<view class="order">
			<navigator url="/pages/items/items">
				<image src="../../static/订单.png" mode="aspectFit"></image>
			</navigator>
			<text>订单</text>
		</view>
		<view class="grow">
			<navigator url="/pages/grow/grow">
				<image src="../../static/成长日记.png" mode="aspectFit"></image>
			</navigator>
			<text>状态曲线</text>
		</view>
	</view>
	<view class="bottom">
		<view class="list">
			<view class="row" v-for="item in 5">
				<view class="left">
					<image src="../../static/耳机.png" mode="aspectFill"></image>
					<view class="text">申请倾听者</view>
				</view>
				<view class="right">
					<image src="../../static/右箭.png" mode="aspectFill"></image>
				</view>
				<button open-type="contact">联系客服</button>
			</view>
		</view>
	</view>
</template>

<script setup>
	
</script>

<style lang="scss">
	.top{
		background-image: linear-gradient(180deg,powderblue,#fff);
		display: flex;
		flex-direction: column;
		padding: 5px 5px;
		navigator{
			width: 35px;
			height: 35px;
			border-radius: 20%;
			overflow: hidden;
			right: 0;
			bottom: 0;
			image{
				width: 100%;
				height: 100%;
			}
		}
		.touxiang{
			display: flex;
			flex-direction: column;
			align-items: center;
			justify-content: center;
			navigator{
				width: 150rpx;
				height: 150rpx;
				border-radius: 50%;
				overflow: hidden;
				image{
					width: 100%;
					height: 100%;
				}
			}
			.name{
				font-size: 40rpx;
				color: #000;
				padding: 5px 0;				
			}
			.address{
				font-size: 28rpx;
				color: #aaa;
			}
		}
	}
	.middle{
		width: 690rpx;
		margin: 50rpx auto;
		border-radius: 20rpx;
		box-shadow: 0 0 30rpx rgba(0, 0, 0 ,0.05);
		display: flex;
		flex-direction: row;
		align-items: flex-end;
		justify-content: space-around;
		border:2px solid skyblue;
		background: #fff;
		.order{
			flex-direction: column;
			padding: 10rpx 10px;
			justify-content: center;
			navigator{
				width: 35px;
				height: 35px;
				border-radius: 20%;
				overflow: hidden;
				image{
					width: 100%;
					height: 100%;
				}
			}
			text{
				width: 30px;
				height: 10px;
				font-size: 30rpx;
				margin: 20rpx;
				padding-top: 20rpx;
			}
		}
		.test{
			flex-direction: column;
			padding: 0 10px;
			navigator{
				width: 50px;
				height: 50px;
				border-radius: 20%;
				overflow: hidden;
				image{
					width: 100%;
					height: 100%;
				}
			}
			text{
				width: 50px;
				height: 10px;
				font-size: 30rpx;
				padding: 5rpx;
			}
		}
		.consult{
			flex-direction: column;
			padding: 0 10px;
			navigator{
				width: 50px;
				height: 50px;
				border-radius: 20%;
				overflow: hidden;
				margin-top: 10rpx;
				image{
					width: 100%;
					height: 100%;
				}
			}
			text{
				width: 50px;
				height: 10px;
				font-size: 30rpx;
				padding: 10rpx;
			}
		}
		.grow{
			flex-direction: column;
			padding: 10rpx 10px;
			justify-content: center;
			navigator{
				width: 35px;
				height: 35px;
				border-radius: 20%;
				overflow: hidden;
				image{
					width: 100%;
					height: 100%;
				}
			}
			text{
				width: 50px;
				height: 10px;
				font-size: 30rpx;
				padding: 5rpx;
			}
		}
	}	
	
	.bottom{
		width: 690rpx;
		margin: 50rpx auto;
		border:1px solid #eee;
		border-radius: 10rpx;
		box-shadow: 0 0 30rpx rgba(0, 0, 0 ,0.05);
		.list{
			.row{
				display: flex;
				justify-content: space-between;
				align-items: center;
				padding: 0 30rpx;
				height: 100rpx;
				position: relative;
				border-bottom: 1px solid #eee;
				&:last-child{border-bottom: 0;}
				.left{
					display: flex;
					align-items: center;
					image{
						width: 30px;
						height: 30px;
						border-radius: 20%;
						overflow: hidden;
					}
					.text{
						padding-left: 20rpx;
						font-size: 28rpx;
						color: #aaa;
					}
				}
				.right{
					display: flex;
					align-items: center;
					image{
						width: 25px;
						height: 25px;
						border-radius: 20%;
						overflow: hidden;
					}
				}
				button{
					position: absolute;
					top: 0;
					left: 0;
					height: 100rpx;
					width: 100%;
					opacity: 0;
				}
			}
		}
	}
	
</style>
