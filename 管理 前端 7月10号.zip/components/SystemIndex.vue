<template>  

  <div class="admin-dashboard">  
  <img src="../assets/logo.png"/>
  <div class = "title-style">欢迎登录“心维度”后台管理系统</div>
      <footer class="footer">  
        <p>© 2024 心维度后台管理系统</p>  
      </footer>  
  </div>  
</template>
<style scoped>  
.admin-dashboard {  
  /* 页面样式 */  
  max-width: 1200px;  
  margin: 0 auto;  
  padding: 20px;  
}  
.footer {  
  /* 页脚样式 */  
  text-align: center;  
  padding: 10px 0;  
  background-color: #f8f9fa;  
  margin-top: 20px;  
}  
.title-style{
	text-align: center;
	padding: 30px 0;  
	background-color: #ffffff;  
	margin-top: 20px;  
}
</style>