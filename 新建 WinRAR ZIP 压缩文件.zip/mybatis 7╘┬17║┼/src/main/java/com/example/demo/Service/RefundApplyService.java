package com.example.demo.Service;

import com.example.demo.mapper.TestQuestionMapper;
import org.springframework.beans.factory.annotation.Autowired;

public class RefundApplyService {
    @Autowired
    private TestQuestionMapper testQuestionMapper;
}
