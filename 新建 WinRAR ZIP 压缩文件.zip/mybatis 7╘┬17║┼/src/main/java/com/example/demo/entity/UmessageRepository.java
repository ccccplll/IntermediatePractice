package com.example.demo.entity;

import org.springframework.data.jpa.repository.JpaRepository;

public interface UmessageRepository extends JpaRepository<Umessage, Integer> {
}
