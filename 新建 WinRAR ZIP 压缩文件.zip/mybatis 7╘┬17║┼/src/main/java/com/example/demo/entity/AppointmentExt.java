package com.example.demo.entity;

import lombok.Data;

@Data
public class AppointmentExt extends Appointment{
    private String uname;
    private String cname;

}
